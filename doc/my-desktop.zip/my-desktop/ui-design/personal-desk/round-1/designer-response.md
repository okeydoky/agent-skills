# Round 1 — designer response to blind findings

Written from `findings-blind.md` only (I have not opened `review.md`). I looked at the reviewer's renders
`now0850.png`, `w1280.png` and `w700.png` and checked each claim against the round-1 code. No file other
than this one was changed.

Summary of positions:

| Finding | Position | Short answer |
|---|---|---|
| R1-01 overlap truncation | agree | Real, and structural at this column width. Fixed by R1-08. |
| R1-02 half-screen widths | agree | The mid layout was never designed, only allowed to happen. |
| R1-03 wall reading order | partial | Reading order is a real problem. The "cards jump columns" part is not what the code does. |
| R1-04 breaks at 1280 | agree | Real; I only tuned 1440. |
| R1-05 row verbs and `/` | partial | `/` dead on a row is a bug. The verb collision is by design but under-signalled. |
| R1-06 "now" three times, declined after 17 | partial | Declined placement is wrong. The repetition is mostly intended, one instance can go. |
| R1-07 notepad bar | agree | Quiet is fine, unlabeled is not. |
| R1-08 agenda as the one calendar | agree, with two additions | It gains more than it loses. I would adopt it. |

---

## R1-01 — Day timeline truncates overlapping events

**Why it was designed this way.** The direction sketch asked for a time-proportional day, and I kept it
because length-as-duration lets free time show as empty paper. Overlaps were handled by giving the later
event the right 62 % of the column from its start time. The scale steps down (72 → 64 → 56 px per hour)
as more hours remain, so the strip and to-do list still fit at 1440×900.

**Is the problem real: agree.** `now0850.png` shows "15:00 no reply Prod…". At 56 px per hour a 30-minute
event gets one 15 px line, the overlap column is about 170 px, and the mono time plus "no reply" use
roughly 110 px of it. I tuned against the 10:50 state where the scale is 64 px and the same event gets two
lines; that hid it from me. The reviewer's point that the cut item is the one needing a decision is
correct, and the tooltip is not an acceptable answer for a glance surface.

**Proposed fix.** Adopt R1-08 (agenda list), which removes the cause: every event gets a full-width row
and wraps. If the proportional timeline were kept instead, the minimum repair would be: fix the scale at
64 px per hour regardless of hours remaining, and move the response word out of the text line (the dotted
or dashed rule already carries it, the word would go to the tooltip). I do not recommend that path: it
still truncates at 1280 and at mid widths, and it puts the strip below the fold in the morning.

---

## R1-02 — Half-screen widths (641–1120 px) get the weakest layout

**Why it was designed this way.** I picked 640 px from "half of a 1280 laptop, a third of a 1920 monitor"
and treated everything wider as "the desk still fits". The mid layout is three CSS overrides, not a design.

**Is the problem real: agree.** `w700.png` is not usable: the headline wraps, Now/Next takes six lines,
notes are about 190 px wide, and no to-do is on screen. My breakpoint reasoning ignored the most common
laptop widths (1366 and 1536, whose halves are 683 and 768). At 960 the stacked To do below a 450 px
timeline hides the due list, which is one of the two things the page promises at a glance.

**Proposed fix.**
- Raise the notepad breakpoint to **≤ 820 px**. Halves of 1366, 1536 and 1600 displays become notepad mode,
  which is the layout built for a window beside another window. The masthead "Notepad" toggle stays for
  forcing it wider; add its inverse (see R1-07).
- Define **821–1199 px** as a real two-column layout: left column is Today (headline, Now/Next, Day as an
  agenda list, To do directly under it); right column is Notes in one column. The rail collapses to the Go
  field plus the shortcuts as a wrapping line of text links above Today (groups show their last-used
  environment, the full group opens inline as now). With the agenda list from R1-08 the Day block is about
  200 px for the remaining events, so the Due group is on screen at 960×900.
- State the rule in the notes: below 1200 the rail gives way first, then Day and To do stack, then
  (≤ 820) everything but capture and notes gives way.

---

## R1-03 — Notes wall has no stable reading order

**Why it was designed this way.** I wanted a wall (two columns of slips) and wanted it never to reshuffle.
So each note is assigned a column once, at creation, and keeps it; a new note goes to the column holding
fewer notes.

**Is the problem real: partial.**
- Agree on reading order. The seeded wall reads 10:12 / 09:41 / Thu / Thu on the left and 09:52 / Thu on
  the right. Newest-first holds inside each column but not across them, and a new note lands wherever the
  count is lower, which in the seed is the right column, away from where the eye leaves the capture field.
  "Where did my note go" is a fair complaint for the most frequent write action.
- Disagree on one detail: cards do not change column on add, promote or delete. `col` is stored on the
  note and never recomputed; a promoted note's receipt and a returned note keep the original column. What
  the reviewer saw is other cards moving *up* within a column. The practical effect on triage (the next
  card is not where you expect) is similar, so I am not leaning on this.
- Agree that about 25 characters per line is too narrow.

**Proposed fix.** One column in the wide view too, strictly newest first, so a saved note always appears
directly under the capture slip and the keyboard order equals the visual order.
- Slip width becomes the full Notes column (about 400 px at 1440), roughly 55 characters per line.
- To keep six to eight notes above the fold, a screenshot in the wide view is a thumbnail at the right of
  the text (about 132 × 80 px, top-left crop, hairline edge); click opens it full size as now. Notepad mode
  keeps full-width screenshots, because there the image is the point.
- The receipt gets a comfortable width, so Due and Project fit on one line each.
- Lost: the "wall" look. I think that is acceptable; the slips are still the only surfaces on the page.

---

## R1-04 — Layout breaks down at 1280 px wide

**Why it was designed this way.** All tuning was done at 1440×900, the size the brief's screenshots use.
Column ratios are fractions with no minimums, so at 1280 every track loses width at once.

**Is the problem real: agree.** In `w1280.png` "TO DO" wraps to two lines (the label became a flex row
when I added key hints, and the first span is allowed to wrap), "To-do →" leaves the slip on three cards
(I set the footer to `nowrap` to stop the time wrapping, which pushed the action out), and note text is
14–18 characters per line. These are defects, and the missing rule for 1121–1440 is a real gap for an
implementer.

**Proposed fix.**
- R1-03 (single notes column) and R1-08 (agenda) remove the two narrowest tracks, so the grid becomes
  rail · Today (Day | To do) · Notes with these floors: rail 160, Day 300, To do 300, Notes 340. That needs
  1100 px of content plus gaps, so it holds from 1200 up.
- Slip footer: time and "delete" on the left, "To-do →" right, footer allowed to wrap as a last resort so
  the action can never leave the surface.
- Labels: `white-space: nowrap` on the label word; key hints are dropped first when space is short.
- Notes: state the three ranges (≥ 1200 full, 821–1199 two-column, ≤ 820 notepad) and what gives way.
- Add 1280×720 to the required screenshot set.

---

## R1-05 — Row verbs collide with type-anywhere; `/` is dead on a row

**Why it was designed this way.** The selector's graft asked for `j/k/t/x/u` on a focused row without
breaking type-anywhere. My rule was: a selected row means keys are commands; no selected row means keys
are text. A row handler therefore swallows every key.

**Is the problem real: partial.**
- `/` not reaching Go from a row: agree, this is a bug. The row handler returns before the global `/`
  rule. It contradicts my own "one key to Go from anywhere".
- Verb collision: partly. By code, a non-verb letter on a selected row does nothing; it does not start a
  note (the reviewer's "db went into the note field" followed the dead `/`, I could not reproduce letters
  leaking from a still-focused row). So the state is consistent, but it is modal, and the only signal is a
  2 px hairline and a hint in the column label. Someone who clicked a row with the mouse and then starts
  typing a note beginning with "t" would promote a note. That is a fair daily-use risk, though undoable.

**Proposed fix.**
- `/` always goes to Go, from rows too.
- Selection mode is entered only by keyboard (↓ or Tab). A mouse click on a row does not leave it in
  command mode: after a click that is not on a control, focus returns to the body so typing starts a note.
- On a selected row, a printable key that is not a verb leaves selection and starts the note with that
  character, so only the six verb letters are ever intercepted, and only after the user deliberately
  entered selection with the keyboard.
- Keep the hint in the column label; add "esc to type" to it.

---

## R1-06 — "Now" stated three times; declined event sits after 17:00

**Why it was designed this way.** The Now/Next sentences are the answer in words; the timeline was meant
as confirmation, so the current event appears in both on purpose. The clock beside the date is the page's
clock; the time on the now-line labels the line. Declined events were moved under the timeline because the
selector asked that they never claim an overlap column.

**Is the problem real: partial.**
- Declined placement: agree. Under the 17 line it reads as an evening item. I solved "never claims a
  column" by taking it out of time order, which trades one defect for another.
- Repetition: partly. Sentence plus position is intended and I would keep it. The time printed twice
  (headline and now-line label) is redundant.

**Proposed fix.** With the agenda list (R1-08): the declined event sits in its chronological row, struck
and grey, taking one line and no column. The current event's row carries the accent rule and bold subject;
the now-marker is a short accent tick between rows with no time label, so the time appears once, beside
the date. If the proportional timeline were kept, the declined line would be positioned at its start time,
right-aligned, over free space only, and the now-line label would be dropped.

---

## R1-07 — Notepad status line controls are quiet and partly unlabeled

**Why it was designed this way.** The brief says "a slim strip for next event at most", so I kept the bar
to one line of plain text and made the summary itself the Day toggle to save a control. The number after
"To do" is the due count in accent, falling back to the open count in grey.

**Is the problem real: agree.** A number that changes meaning with its colour is not readable. The summary
does not look pressable. And when the mode is forced at full width, the only exit is inside the Go panel,
which the user has no reason to open.

**Proposed fix.**
- "To do · 3 due" (accent on "3 due"); when nothing is due, "To do · 8".
- The three controls get the same underline treatment as other text actions (`.tbtn`), with a small mono
  `+` / `–` as on group rows, so they read as expandable.
- Summary keeps the times and lets only the subject truncate; it gets the same `+`.
- When forced (`mode=notepad` or the masthead toggle): "Full view" as the last item in the bar. When the
  mode comes from window width, no such item (widening the window is the exit).

---

## R1-08 — Bold alternative: the agenda list as the one calendar rendering

**Why the proportional timeline was chosen.** It came with the direction ("a time-proportional day
timeline with a now-line"), it makes free time visible as empty space, and the selection explicitly
declined B's agenda list to protect it. So this reopens a settled point, and needs evidence. I think the
evidence is there: `now0850.png`, `w1280.png` and `w700.png` show the timeline failing on the brief's own
required cases (overlap, long subject) at the time of day and window sizes that matter most, and the fixes
I can find for it each cost something else (strip below the fold, a third scale rule, hidden response
words).

**Assessment against the rubric.**

| Criterion | Gained | Lost |
|---|---|---|
| 1 Task-flow (25) | Every subject readable at a glance, including the long one and the "no reply" one. Morning view no longer the worst view. | Nothing operational; the calendar is read-only. |
| 2 Notepad (20) | Wide and narrow show the same thing, so switching modes loses nothing even visually. Frees width for R1-02. | — |
| 3 Hierarchy & calm (15) | About 200–260 px instead of 450–500, so To do and Notes get the space; declined in order; no hour labels appearing and disappearing. | Duration and gaps are no longer visible as length. "How much free time do I have this afternoon" becomes reading times. |
| 4 Restraint & distinctiveness (15) | A ruled list of mono times and subjects is arguably more "ledger" than a timeline. | The timeline was the one graphic gesture on the page; without it the home view is all lists. Some distinctiveness goes. |
| 5 Extensibility (15) | One list grammar (mono key, text, grey word, rule style) shared by Day, To do, Earlier and Investments rows. | — |
| 7 Feasibility (5) | Removes overlap columns, adaptive scale, clamp maths and label collision handling: the only fiddly part of the build. | — |

**My view: adopt it, with two additions that keep what the timeline was good at.**

1. **Gaps as lines.** Between two rows separated by 30 minutes or more, print one mono grey line, for
   example `free 1 h 15`. That keeps free time legible at a glance, which is the real loss, and it is one
   more line of type, not a new component. The Now sentence already says "Free until 12:00" for the
   current gap.
2. **Overlap as a word.** A row that overlaps the previous one gets `overlaps` in mono grey after the
   time, and the Now sentence keeps its "+1 overlapping". Rule styles stay as in the narrow agenda (solid,
   dashed, dotted, none + struck for declined, accent for current).

Kept from round 1: the "EARLIER · n" fold (elapsed rows collapse to one line by default, since dimmed past
rows would otherwise be the first thing read in the afternoon), the Now/Next sentences, and the tooltip.

Dropped: `--gut`, the hour grid, the adaptive scale, the overlap layout, the now-line, the declined
footnote list.

What I would watch for in the next round: with the Day block this short, the Today zone could look
top-heavy and empty below at 1440. The intended use of the freed space is R1-03 (wider notes) and letting
To do sit beside Day with both starting at the same line, not adding anything new.
