# Round 1 review — Personal Desk ("Ledger")

Reviewer: independent, round 1. Judged from the supplied screenshots (`round-1/shots/`), extra headless-Edge
renders (in my scratch folder, names given per finding so they can be reproduced from the hash), and a live
session driving the mockup (typing notes, saving, promoting, checking off, Go field, keyboard cursor).

Tasks walked: Launch, Capture, Triage — wide (1920 / 1440 / 1280), mid (960 / 700), narrow (480), light and dark.

## Strengths — keep

1. **Capture is truly zero-ceremony.** Typing anywhere lands in the note field, Enter saves, focus stays in
   the field for the next note, the draft survives mode changes, and the same field exists on every route
   (Investments has "Note to self"). Live-tested: two notes saved in a row without touching the mouse.
2. **Promote = one gesture with an in-place receipt.** "To-do →" converts instantly; the receipt sits where
   the note was, offers Due / Project as one-click chips plus Undo, and the new to-do is marked `new` in the
   list. First sentence becomes the title; the full note and screenshot stay attached under the to-do
   (`promoted-light.png`). Nothing modal anywhere in the triage path.
3. **Go rail.** `/` then `db p` + Enter, aliases revealed only when the field has focus (`go-focus`),
   last-used environment shown beside a collapsed group as a one-click link ("Azure · Portal"), sections as
   launch targets (`go-section`). Launch is one or two actions by mouse or keyboard.
4. **Notepad mode is a mode, not a stack.** One status line (now / until / next + To do count + Go), capture
   first, notes single-column with legible screenshots; To do / Day / Go open as panels *below* the capture
   field so capture never moves (`notepad-*.png`). The narrow Day agenda list is the clearest calendar
   rendering in the whole design.
5. **Visual language.** Hairlines, one warm accent used only for "now / overdue / primary gesture", mono for
   times and numbers, tinted paper slips as the only filled surface. No slop tells; dark theme is a real
   peer of light. The Investments strip + route look native and prove the "section = label + hairline + rows"
   rule.

## Findings

### R1-01 — Day timeline truncates overlapping events to a few characters
- **Severity:** medium
- **Rubric criterion:** 3 Visual hierarchy & calm (also requirement 2: overlaps, long subjects)
- **Observation:** With the whole day ahead (`#state=x&now=08:50`, my render `now0850.png` at 1440 and
  `now0850s.png` at 1280) the overlapping 15:00 event renders as "15:00 no reply Prod…" (1440) and
  "15:00 no reply Pro…" (1280); "Daily standup — Data…" is also cut at 1280. In the default 10:50 state the
  same event only fits because the hour scale happens to be taller (64 px/h instead of 56 px/h), and at
  700 px wide it is clipped mid-word (`w700.png`). The Day column is ~270–320 px wide, an overlap gets
  roughly half of that, and the mono time + response word consume most of the line.
- **Problem:** The morning glance is the core of the Launch task, and that is exactly when the timeline is
  fullest and scales down. The event that gets cut is the "no reply" one — the single item on the day that
  still needs a decision — and there is no visible way to read its full subject.
- **Suggestion:** Give the overlapped event the full column width, shown indented one step under the event
  it overlaps (a second rule to the left marks the overlap) instead of a half-width side column; allow two
  lines before truncating; put the response word after the subject, not before it. Never let the time/
  response prefix be the only thing that survives.
- **Rationale:** Subjects are the payload; position and rule style can carry "overlaps" and "tentative/no
  reply" without spending text width.

### R1-02 — Half-screen widths (641–1120 px) get the weakest layout
- **Severity:** medium
- **Rubric criterion:** 2 Notepad mode & capture quality; 3 Visual hierarchy
- **Observation:** Notepad mode starts at ≤ 640 px. Above that a "mid" layout applies up to 1120 px. At
  960 px (`mid-960-light.png`) To do drops below the full-height timeline, so no to-do is visible without
  scrolling. At 700 px (`w700.png`) the rail, Day and Notes are all still side by side: the date heading
  wraps to two lines, "Lakehouse pipeline design review" takes three, timeline subjects are clipped, and
  To do is far below the fold.
- **Problem:** Half of a 1366–1536 px laptop screen is 683–768 px and half of a 1920 px monitor is 960 px —
  the most common split-screen sizes for this user. In those windows they get neither the purpose-built
  notepad nor a usable Today view; due to-dos (one of the two things the page should surface at a glance)
  are hidden, and notes beside another window are squeezed to ~190 px.
- **Suggestion:** Two changes. (a) Raise the notepad breakpoint to about 760–800 px so a half laptop screen
  enters notepad mode (the layout already reads well up to 608 px content width, see `mode=notepad`).
  (b) In the remaining mid range, collapse the rail to the Go field plus a single wrapped row of links above
  the header, and place the Due group above the timeline (or Day and To do side by side with Notes below).
- **Rationale:** The brief leaves the breakpoint to the designer but asks for it to be justified by the
  split-screen use; real half-screen widths are the justification.

### R1-03 — Notes wall has no stable reading order; newest note does not land next to the capture field
- **Severity:** medium
- **Rubric criterion:** 1 Task-flow efficiency (Capture, Triage); 2 capture quality
- **Observation:** Live at 1440 px: I saved two notes. Both appeared at the top of the **right** column
  while the top-left slot (directly under the start of the capture field) kept the older 10:12 note. The
  seeded wall is the same: left column 10:12 / 09:41 / Thu 15:05 / Thu 11:20, right column 09:52 /
  Thu 16:42 — neither row-wise nor column-wise chronological. Cards are assigned to whichever column is
  shorter, so cards also change column when a note is added, promoted or deleted.
- **Problem:** "Where did my note go?" and "what are my latest notes?" both require scanning two columns and
  reading timestamps. During triage, cards jump columns after every promote, so the user loses their place.
  The wall is also only ~168 px of text per card (about 25 characters per line; "To-do →" overflows the
  card edge at 1280, see R1-04).
- **Suggestion:** Make order deterministic and newest-first from the capture field: either a single column
  of full-width slips (as notepad mode does — it already looks better), or strict row-major placement
  (newest top-left, next top-right) with no re-balancing. If one column, cap screenshot height (~160 px,
  click to zoom) to keep five or six notes on screen.
- **Rationale:** A predictable landing spot is part of "near-zero friction"; the single-column slip is
  already designed and removes a layout algorithm from the implementation.

### R1-04 — Layout breaks down at 1280 px wide
- **Severity:** medium
- **Rubric criterion:** 3 Visual hierarchy & calm; 4 Aesthetic restraint
- **Observation:** At 1280×720 (`w1280.png`, a standard laptop viewport at 150 % scaling) the "TO DO" label
  wraps onto two lines ("TO" / "DO"), the "To-do →" action sticks out past the right edge of note cards
  (Thu 15:05, Thu 11:20, Thu 16:42 cards; the last one runs past the page margin), note text is ~14–18
  characters per line, the capture hint wraps, and to-do titles wrap to two or three lines.
- **Problem:** The five-track grid (rail, Day, To do, two note columns) is tuned for 1440+. On a common
  laptop size the primary promote control looks broken and the page stops feeling calm. An implementer has
  no rule for what gives way between 1120 and 1440.
- **Suggestion:** State the rule and show it: below ~1360 px the wall becomes one column (ties in with
  R1-03), the section label never wraps (`white-space: nowrap`; move the keyboard hint line under it), and
  the slip footer keeps "To-do →" inside the card (shrink/hide the timestamp first).
- **Rationale:** 1280 px is inside the "desktop" range the brief targets; the mockup should hold there.

### R1-05 — Single-letter row verbs collide with type-anywhere capture; `/` is dead while a row has focus
- **Severity:** low
- **Rubric criterion:** 1 Task-flow efficiency (keyboard paths)
- **Observation:** Live: with a to-do row focused, pressing `/` did not move focus to Go, and the next
  letters ("db") went into the note field. With a note row focused, `t` promotes it; with a to-do row
  focused, `x` completes it. Any other letter starts a note.
- **Problem:** While the row cursor is active the same keystroke means "verb" or "start a note" depending on
  the letter, so a note beginning with t/x/u silently acts on the focused row instead (undoable, but
  surprising). `/` not working from a row breaks the "always one key to Go" promise.
- **Suggestion:** While a row has focus, letters are verbs only (no type-through); Esc leaves the cursor and
  restores type-anywhere; `/` always goes to Go. Say so in the hint line.
- **Rationale:** One meaning per key per state.

### R1-06 — "Now" is stated three times and the declined event sits after 17:00
- **Severity:** low
- **Rubric criterion:** 3 Visual hierarchy & calm
- **Observation:** `home-light.png`: the current time appears beside the date, on the timeline marker, and
  the current event appears in the NOW line and again, bold, in the timeline 180 px below. The declined
  "11:00–11:30 Vendor demo" is listed under the 17 hour line, after the last event of the day.
- **Problem:** Mild redundancy in the area the eye lands on first; the declined item reads as an evening
  event until the time is parsed.
- **Suggestion:** Keep the NOW/NEXT header as the only bold statement; in the timeline show the running
  event at normal weight with only the accent rule. Separate declined items with a small "Declined · 1"
  fold (same pattern as "Earlier · 2") rather than appending them to the hour grid.
- **Rationale:** Reuses an existing pattern and removes a false time cue.

### R1-07 — Notepad status line controls are quiet and partly unlabeled
- **Severity:** low
- **Rubric criterion:** 6 Discoverability
- **Observation:** `notepad-light.png`: "To do 3" and "Go" are grey text at the right of the status line;
  the "3" is unexplained (it is the due count); the calendar summary is also the Day toggle but looks like
  plain text and is truncated ("Delta Live Ta…"). Nothing on screen says how to get back to the full view
  when notepad mode was forced with the "Notepad" link at full width (`mode=notepad`).
- **Problem:** The three panels are the only way to reach to-dos, the day and shortcuts in this mode, and
  they are easy to miss.
- **Suggestion:** Underline the three toggles like the other text controls, label the count ("3 due"), and
  show a "Full view" link when the mode is forced at a wide width.
- **Rationale:** Matches the text-control convention used everywhere else.

### R1-08 — Bold alternative: use the agenda list as the one calendar rendering, in wide mode too
- **Severity:** medium (bold alternative — may be rejected)
- **Rubric criterion:** 3 Visual hierarchy & calm; 7 Implementation feasibility; 5 Extensibility
- **Observation:** The narrow Day panel (`notepad-day-light.png`) is a plain agenda: one row per event, time
  range in mono, full subject, response word, rule style for tentative / no reply, past rows dimmed, the
  running row accented, declined struck through in its chronological place. It shows all eight events,
  including the long subject, in ~260 px of height with no truncation. The wide proportional timeline
  needs ~500 px for five events, changes scale with the time of day, hides hour labels on collision,
  truncates overlaps (R1-01) and parks the declined event out of order (R1-06).
- **Problem:** The wide view spends its largest block on a rendering that is less legible than the narrow
  one, and the design carries two calendar components with different rules.
- **Suggestion:** Make the agenda list the calendar everywhere. Keep "Earlier · N" folding; add a quiet gap
  row where free time is ≥ 30 min ("free 1 h 15") and an "overlaps" indent for concurrent events; keep
  the accent rule and a "now" hairline between rows. Give the freed height to To do (Due group visible at
  every width) or let Day and To do stack in one column so Notes can widen.
- **Rationale:** One component, no layout algorithm, no truncation, the same look in both modes — and it
  resolves R1-01, R1-06 and much of R1-02/R1-04 structurally. Cost: the at-a-glance sense of duration and
  gaps is carried by text rows rather than by height.
