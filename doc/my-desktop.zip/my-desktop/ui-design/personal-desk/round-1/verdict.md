# Round 1 verdict — Personal Desk ("Ledger")

Judge: neutral, round 1. Based on `brief.md`, `decision-log.md`, `review.md`, `designer-response.md`, the
round-1 shots (`home-light`, `mid-960-light`, `notepad-light`, `notepad-day-light`) and the reviewer's
renders (`now0850`, `w1280`, `w700`, `forcenp`). Every observation the reviewer made that I checked is
visible in the renders as described.

## Summary table

| ID | Final severity | Verdict | One-line reason |
|---|---|---|---|
| R1-01 | medium | ACCEPT designer's fix (resolved by R1-08) | Truncation is structural at a ~300 px column; patching the timeline still fails at 1280 and mid widths. |
| R1-02 | medium | ACCEPT merged | Notepad breakpoint 820 px (designer's number) plus a designed two-column mid range; both parties agree and the renders confirm. |
| R1-03 | medium | ACCEPT merged | One column, strictly newest first (both agree); screenshots as a full-width capped strip (reviewer), not a side thumbnail (designer). |
| R1-04 | medium | ACCEPT merged | Defects at 1280 are real; designer's floors accepted in principle but the arithmetic does not hold at 1200–1359, so Day and To do stack there. |
| R1-05 | low | ACCEPT merged | `/` always goes to Go and selection is keyboard-entered only (designer); inside selection keys are verbs only, Esc exits (reviewer). |
| R1-06 | low | ACCEPT designer's fix; one sub-point is a user call | Declined in chronological place and the time printed once; bold on the running row is taste. |
| R1-07 | low | ACCEPT merged | Same fix from both: labelled count, underlined toggles, "Full view" when forced. |
| R1-08 | medium | ACCEPT merged (reviewer's proposal + designer's additions, overlap shown by indent) | One calendar component, no truncation, about half the height; the settled timeline is reopened on concrete evidence. |

## Per-finding detail

### R1-01 — overlap truncation · medium · ACCEPT designer's fix (via R1-08)
`now0850.png` shows "15:00 no reply Prod…" at 1440 and `w700.png` clips mid-word. Medium is right: the
requirement (overlaps, long subjects) is handled but degraded in the morning glance, daily. The reviewer's
patch (full-width indented overlap, two lines, response word after subject) is correct in content, and all
three of its points are carried into the agenda rows. The designer's "keep the timeline, fix the scale at
64 px" fallback is rejected: it leaves the 1280 and mid-width failures and pushes To do down.

### R1-02 — half-screen widths · medium · ACCEPT merged
`w700.png` and `mid-960-light.png` confirm: no to-do on screen, wrapped headline, ~190 px notes. Medium,
bordering high (criterion 2, weight 20), but notepad mode itself works, so medium stands. Breakpoint: 820
rather than 760–800, because half of a 1600 display is exactly 800 and a boundary should not sit on a
common window size. Mid range: the designer's two-column layout is the more complete answer and satisfies
the reviewer's requirement that the Due group is on screen. Notepad content stays capped at its current
608 px measure (see `forcenp.png`), so the wider breakpoint costs nothing in line length.

### R1-03 — notes order · medium · ACCEPT merged
The seeded wall order (left 10:12 / 09:41 / Thu / Thu, right 09:52 / Thu) is visible in `home-light.png`.
The designer's correction (cards do not change column, they shift up) is accepted and does not change the
conclusion. Both propose one column, newest first: accepted. On screenshots the two differ. Decided for
the reviewer's capped full-width strip on rubric grounds, not taste: (a) a 132 px side thumbnail takes back
the text measure this finding is fixing (about 30 characters per line again in a 340 px column);
(b) criterion 2 asks that the mode switch loses nothing, and one slip component with a height cap differs
from notepad mode by one property, where the thumbnail is a second layout; (c) criterion 7. Cost accepted:
fewer notes above the fold than the designer's six to eight; the column scrolls and is newest-first.

### R1-04 — breaks at 1280 · medium · ACCEPT merged
`w1280.png` shows "TO / DO" wrapped, "To-do →" outside three slips, the capture hint wrapped. Medium: a
standard laptop viewport, and no rule exists for the implementer. Accepted: reviewer's no-wrap label and
in-card footer, designer's floors and stated ranges. Correction to the designer: floors 160 + 300 + 300 +
340 = 1100 plus three gaps (~140) plus page margins (88) need about 1330 px of viewport, not 1200. So
the side-by-side Day | To do arrangement starts at 1360 (the reviewer's figure), and from 1200 to 1359 Day
stacks above To do. This is affordable only because the agenda (R1-08) is short.

### R1-05 — row verbs and `/` · low · ACCEPT merged
`/` dead on a row is a bug by the designer's own account. For the verb collision the designer's
"non-verb key leaves selection and types" keeps the exact ambiguity the reviewer flagged (the outcome
depends on the first letter). Build: `/` always focuses Go; selection is entered only by keyboard (↓ or
Tab), a mouse click on a row never leaves the page in command mode; while a row is selected, keys are
verbs only and other letters do nothing; Esc leaves selection and restores type-anywhere; the label hint
adds "esc to type".

### R1-06 — "now" repeated, declined after 17 · low · ACCEPT designer's fix
Declined placement is wrong (both agree) and is solved by the agenda: struck, grey, in chronological
place, as `notepad-day-light.png` already shows. The reviewer's "Declined · 1" fold is not needed once the
row costs one line. The current time is printed once (beside the date); the now-marker carries no time
label. Whether the running row is also bold is a user call (below).

### R1-07 — notepad status line · low · ACCEPT merged
Both propose the same thing. Build: "To do · 3 due" (accent on "3 due"), falling back to "To do · 8";
the three toggles underlined like other text controls; the summary keeps its times and truncates only the
subject; "Full view" as the last item only when the mode is forced. The designer's `+` / `–` markers are
optional: include them only if the bar still fits on one line at 480 px.

### R1-08 — agenda list as the one calendar · medium · ACCEPT merged
This reopens a point the selection settled, which the log allows only on concrete new evidence. The
evidence is there: three renders show the timeline failing the brief's own required cases (overlap, long
subject) at the time of day and window sizes that matter most, and the narrow agenda in
`notepad-day-light.png` shows all eight events untruncated in about 260 px. On the rubric: gains on
criteria 1, 2, 3, 5 and 7 (65 + 20 points of weight touched positively), one real loss on criterion 4
(the timeline was the page's only graphic gesture) and a partial loss on 3 (duration as length). The
designer, who has the most reason to defend the timeline, reaches the same conclusion, and I checked that
agreement against the renders rather than taking it as given. The loss is mitigated by the gap rows.

Overlap marking: reviewer proposes an indent, designer proposes the word "overlaps". Decided for the
indent: the row already carries a time and often a response word, a second grey word is what crowded the
timeline in the first place, and position reads faster than text on a glance surface. The Now sentence
keeps "+1 overlapping" in words.

Must be preserved (acceptance conditions for round 2):
- Now / Next sentences unchanged, including "Free until …" and "+1 overlapping".
- "Earlier · N" fold for elapsed events, collapsed by default, in both modes.
- Response states distinguishable without reading: rule style (solid accepted/organizer, dashed tentative,
  dotted no reply, none + struck for declined) plus the response word after the subject.
- Free time legible at a glance (gap rows), since that is what the timeline was good at.
- All eight demo events readable in the 08:50 state at every width, the long subject in full.
- Empty-day state; UTC-authored data shown in local time.
- A "now" indication that does not depend on an event running.

## Consolidated build specification for round 2

Covers R1-01, 02, 03, 04, 06, 08. Where this differs from either party's text, this text wins.

### A. Width ranges (viewport width)

| Range | Layout | What has given way |
|---|---|---|
| ≥ 1360 | Rail (160–200) · Today · Notes. Inside Today, Day and To do side by side, both starting on the same line. | Nothing. |
| 1200–1359 | Rail · Today · Notes. Inside Today, Day stacked above To do in one column. | Day / To do side-by-side. |
| 821–1199 | Two columns: Today (headline, Now/Next, Day, To do directly under it) · Notes. The rail collapses to the Go field plus one wrapping line of text links above Today; a group shows its last-used environment and opens inline. | The rail as a column. |
| ≤ 820 | Notepad mode, content capped at the current ~608 px measure. | Everything except capture and notes (panels on demand). |

Floors: rail 160, Day 280, To do 280, Notes 340 (one column at every width). The order of giving way is
stated in the design notes in one sentence: Day/To do side-by-side first, then the rail, then everything
but capture and notes. Forced notepad ("Notepad" in the masthead, `mode=notepad`) stays available at any
width and shows "Full view" (R1-07).

Fixed rules at every width: section labels never wrap (`white-space: nowrap` on the label word; key hints
are dropped first); a slip's "To-do →" is always inside the slip (the footer may wrap, the timestamp
shrinks or hides first); the date headline stays on one line.

Checks the round-2 shots must pass:
- 1280×720, default state: no wrapped label, no control outside a slip, Due heading and at least two due
  items visible without scrolling.
- 1280×720 and 1440×900, `now=08:50`: all eight events readable, at least the first due item visible.
- 960×900 and 700×900: Due group visible at 960; 700 is notepad mode.
- Add 1280×720, 1366×768, 960×900 and 820/821 boundary renders to the required screenshot set.

### B. Calendar rendering (one component, both modes)

- One row per event: mono time range, subject, response word after the subject (grey mono, only for
  tentative / no reply / declined). Left rule carries the response state as listed above; the running
  event's rule is the accent.
- Subject wraps to at most two lines, then ellipsis with the full text in a tooltip. The time column is
  fixed width, so the subject is never the part that gives way to a prefix.
- Order is chronological by start. Declined events sit in their chronological place, struck and grey, and
  are ignored when computing overlaps and gaps.
- Overlap: an event that starts before the previous non-declined event ends is indented one step
  (12–16 px) under it, with its own rule. No extra word.
- Gaps: between non-declined events 30 minutes or more apart, one quiet row, mono grey, no rule, e.g.
  `free 1 h 15`. Upcoming gaps only (none inside the Earlier fold). If three gap rows make the 08:50 view
  read as noisy, the designer may raise the threshold to 45 minutes and must say so in the notes.
- Elapsed events collapse into "Earlier · N" (collapsed by default, expands in place, rows dimmed).
- Now: when an event is running, its row has the accent rule. When in a gap, a short accent tick sits
  between the rows at the current position. No time label on either; the time appears once, beside the
  date.
- Removed: hour grid, adaptive px-per-hour scale, overlap columns, hour-label collision handling, the
  declined footnote list, the labelled now-line.
- The freed height goes to To do and Notes only. Nothing new is added to fill the Today zone; if it looks
  top-heavy at 1440 that is a round-2 review question, not a licence to add content.

### C. Notes ordering

- One column at every width, strictly newest first; a saved note appears directly under the capture slip.
  No column assignment, no balancing. Keyboard order equals visual order.
- Slip is the full width of the Notes column. Promote receipt and returned (Undo) notes keep the position
  of the note they replace.
- Screenshots in the wide and mid layouts: full slip width, height capped at about 140 px, cropped from
  the top-left, hairline edge, click opens full size. Notepad mode keeps uncapped full-width screenshots.
- Footer: time and "delete" left, "To-do →" right, per section A.

### D. Batched low items (R1-05, R1-06, R1-07)
As specified in the per-finding detail above.

## User call items

1. **R1-06, weight of the running event's row.** Reviewer: normal weight, accent rule only, so the
   Now/Next header is the single bold statement. Designer: accent rule plus bold subject, as the narrow
   agenda already renders it. No rubric tiebreaker (both are calm; it is emphasis taste). Default for
   round 2 unless the user says otherwise: the designer's (matches the existing narrow rendering).

No other items are user calls. The R1-03 screenshot treatment and the R1-08 overlap marker were decided on
rubric grounds as explained.

## Count

Accepted: **0 high, 5 medium** (R1-01, R1-02, R1-03, R1-04, R1-08), plus 3 low batched (R1-05, R1-06,
R1-07). Another refinement round is required.
