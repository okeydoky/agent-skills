# Personal Desk — "Ledger", round 1

Standalone design note for `round-1/design.html`. Screenshots are in `round-1/shots/`
(`<state>-light.png` / `<state>-dark.png` at 1440×900, `notepad-*` at 480×900).

## The idea

The page is looked at far more often than it is operated, so it is set like a printed ledger page: three
columns of type separated by whitespace and hairlines, nothing boxed, nothing that moves unless asked.

Two rules carry the whole design:

1. **The page is print; only notes are objects.** A note is the only thing with a surface (a flat tinted
   slip, no border, no shadow). Shortcuts, events, to-dos and every future section are type on paper.
2. **Accent means "this needs you now", and nothing else.** One colour, one meaning.

Round 1 keeps both rules and adds what phase 1 lacked: a keyboard path through every top task, an instant
promote, a day that starts at now, and designed rare paths (shortcut editing, empty states, capture on
every route).

## Layout

Full view (> 1120 px). Page margin 44 px, column gap 48 px.

| Zone | Width | Content |
|---|---|---|
| Masthead | full | wordmark · text nav (Today, Investments, Settings) · on routes without the wall, a one-line note field and status · Notepad toggle · Theme toggle. One hairline below. |
| Go | 160 px | "Type to go" field, shortcuts as text links, groups inline |
| Today | 2.4fr | headline (date + clock), **Now / Next** sentences, hairline, then two sub-columns: **Day** and **To do** |
| Notes | 1.4fr | capture slip, then a two-column wall of slips |
| Strips | full, page foot | one line per secondary section |

At 1440×900 with the demo day everything, including the Investments strip and the whole to-do list, is
above the fold (`home-light.png`).

- Medium (641–1120 px): same zones; Day and To do stack; the wall is one column (`mid-960-light.png`).
- Notepad mode (≤ 640 px or forced): a different page, described below.

## Visual tokens

One token set; the dark theme re-declares the same names. Theme follows the OS; a toggle cycles
auto → light → dark and is stored; `#theme=` overrides.

| Token | Light | Dark | Use |
|---|---|---|---|
| `--paper` | `#FAFAF6` | `#121211` | page |
| `--ink` | `#171715` | `#ECEBE4` | primary text, live event rules, checked boxes, last-used dot |
| `--ink2` | `#5B5B54` | `#A6A59C` | secondary text, times |
| `--ink3` | `#8A897F` | `#737269` | labels, hints, aliases, folded/declined events |
| `--line` | `#E3E2D9` | `#2A2A27` | hairlines |
| `--line2` | `#CCCBC0` | `#3D3D38` | stronger hairline, image edge, field underline |
| `--slip` | `#F0EFE5` | `#1E1E1B` | note surface, the only surface |
| `--slip-in` | `#E6E5DA` | `#292925` | reserved (unused after the slip glyph was dropped) |
| `--accent` | `#C5411C` | `#FF6A3D` | "needs you now" |

Where accent appears: NOW label and clock, now-line and dot, current event rule, the Due heading and late
dates, the capture slip edge, the keyboard selection hairline, the focused field underline, the top edge of
a promote receipt, the arrow in "To-do →", a drop target's underline, and the chosen word in a picker.
Links are never accent. Investments shows direction with + and −, never colour.

Type: **Instrument Sans** 400/500/600 for everything read; **IBM Plex Mono** 400/500 for times, dates,
figures, labels, aliases and hints. Fallbacks `system-ui, Segoe UI` and `ui-monospace, Cascadia Mono,
Consolas`. Scale: 11 mono label/hint · 13 event · 14 notes and rail children · 14.5–15 to-dos and links ·
17 Now/Next · 30 headline. Screenshots in dark theme are dimmed to 86 % brightness.

Spacing: 4 px base; 48 between columns, 28–30 between blocks, 15 between to-do groups, 10 between slips.
Radius: 0 on slips, 3 px on checkboxes. No shadows anywhere.

Metadata is always words in mono grey (aliases, "note + image", "tentative", key hints). There are no icons.

## Key interactions

### Launch: Go
- Shortcuts are plain text links, one click each. A group is a row with a count (`3 +`); clicking the name
  or the count expands it inline and the open state persists.
- **Last-used environment** (graft 2): an ink dot marks it inside an open group. A *collapsed* group prints
  it beside the name ("Azure • Portal") as a direct link, so the usual environment is one click even when
  the group is closed.
- **Go field** (grafts 1, 5): `/` focuses it from anywhere. Type a name, part of a name, or an alias;
  Enter opens the first hit, which is marked "Enter".
  - `ol` → Outlook. `db` → Databricks, last-used environment first. `db p` → Databricks Prod.
    `prod` → Databricks Prod. `inv` → the Investments section, `set` → Settings.
  - **Aliases stay hidden at rest.** They print in mono grey at the right of each row only while the Go
    field has focus (`go-focus-*.png`), so the resting rail is plain names. Rejected: always-visible
    aliases (noise all day for something learned in a week) and B's always-focused omnibar (it would merge
    launch and capture and replace this design's separate capture slip).
- Rejected for groups: hover fly-outs (hidden, fragile), a favicon grid (dashboard look, ten brand colours
  on a monochrome page), group click opening a default environment (Prod by accident).

### Launch: shortcut editing (rare path, fully designed)
"Edit" under the rail (also in Settings) turns the rail into an editable list in place
(`edit-shortcuts-*.png`):
- every row gets a `::` handle (drag to reorder within its level) and its alias printed;
- clicking a name opens three underlined fields under it (Name, URL, Alias; a group has Name and Alias; an
  environment has Name, URL and Key, the letter typed after the group alias) plus Up, Down, Remove;
- "+ link" inside each group, "+ Add link", "+ Add group", "Done" at the foot;
- Remove is undoable from the Undo line. Changes save as typed.
- Rejected: a modal manager or a separate settings table. The rail is the thing being edited, so it is
  edited where it stands, with the same type and no new surface.

### Launch: the day
- **Now / Next** in sentences, the largest text after the date: "Now *subject* until 11:30 · 40 min left",
  "Next 12:00 *subject* in 1 h 10 min · tentative". Declined events never count. No current event reads
  "Free until 12:00". These lines never truncate, so a long subject is always readable here.
- **Day starts at now** (graft 8). Elapsed events fold into one mono grey line, "EARLIER · 2 +"; clicking it
  lists them as plain grey lines with full subjects (`earlier-*.png`). The proportional timeline runs from
  the current hour to the end of the last event, at 72, 64 or 56 px per hour depending on how many hours
  remain, so the afternoon gets the space the morning no longer needs.
- An event is a 2 px rule whose length is its duration, with text beside it. No filled blocks.
  - Response: accepted/organizer solid rule; tentative dashed + the word "tentative"; no reply dotted +
    "no reply".
  - **Declined events leave the timeline** (drop item). They print as struck grey lines with the word
    "declined" under it, or inside Earlier once elapsed. They never take an overlap column and the slot
    reads as free, which it is.
  - Current event: accent rule, bold subject. Now: accent time in the hour gutter, a dot on the rule, and a
    hairline that runs behind event text, never through it.
  - Long subjects wrap and clamp to the lines the duration allows; full text in the tooltip.
  - 15-minute events take one line and show only their start time.
  - Overlap: the earlier event keeps full width for the lines above the overlap; the later one starts at
    38 % from its start time. Events that start together fall back to equal columns.
- Empty day: "Nothing scheduled today" and one line in Day. After the last event: "Nothing else today."
- Times are local, 24-hour. Demo events are authored as UTC strings in both real formats
  (`…T21:30:00.0000000Z`, `…+00:00`) and pass through one parser that trims the 7-digit fraction.

### Capture
- The capture slip is the first object in Notes, always present. **Enter saves, Shift+Enter adds a line,
  Ctrl+Enter saves as a to-do** (graft 4). "Save note" and "Save as to-do" appear as words once there is
  content, for the mouse.
- **Enter saves, decided.** The selection left this open. Notes here are separate post-its (settled at
  intake), so the unit of capture is one thought and the commonest note is one line; Enter-saves makes
  that zero-ceremony and matches the to-do line beside it. Multi-line notes cost one modifier. The opposite
  choice would tax every short note to serve the long ones. Settings lists the alternative
  ("new line") as a stubbed preference so the implementer keeps it switchable.
- **Type anywhere, on every route** (graft 9): with no field focused, any printable key starts a note.
  **Ctrl+V with an image, on every route**, adds it to the draft as a removable thumbnail.
  - On home the keystroke lands in the capture slip.
  - On Investments or Settings it lands in a one-line note field in the masthead; after Enter the masthead
    prints "Saved to notes · Undo" (`investments-capture-*.png`). A pasted image prints
    "1 screenshot in the note · Enter saves".
  - In notepad mode the capture slip itself stays under the bar on every route
    (`notepad-investments-*.png`).
- One draft, persisted: it survives reload, route change and mode change.
- `#project @due` typed in a note are read when it becomes a to-do; the hint line previews the result.
- Notes are edited in place by clicking the text. Screenshots open full size on click. "delete" is a grey
  word beside the time on the left, away from "To-do →" on the right, shown on hover (always in notepad
  mode), and undoable.
- A new note goes to the shorter wall column and keeps its column, so the wall never reshuffles.

### Triage: promote (graft 7)
- Every slip prints **"To-do →"**. One click, or `t` on a selected slip, creates the to-do at once.
- The slip becomes a **receipt** in the same place (`receipt-*.png`, `notepad-receipt-*.png`): "→ TO DO ·
  where it went", the title (editable), "note + image attached", Due as words (none · today · tomorrow ·
  Mon n · other…), Project as words (existing · + new), Undo, Close. Ignoring it is a valid finish.
- **Adaptation to Ledger:** C's receipt was a filled green card with pills. Here it is still a slip, marked
  only by an accent hairline on its top edge, with word pickers. And because nothing on this page moves by
  itself, the receipt has **no timer**: it stays until the next wall action, Close, or leaving the page.
  The phase-1 nine-second undo line is gone for the same reason.
- **The note leaves the wall and travels with the to-do.** The wall is an inbox; promoted notes that stayed
  would silt it up. The to-do row says "note + image" in mono grey (graft 6); opening the row shows the
  original slip with its screenshot; "Return to notes" reverses the promotion at any time.
- Title = first sentence of the note (tokens removed), up to 110 characters.
- **Drag "To-do →" onto a project heading** (graft 10) to file it there in one gesture; onto "Due" to make
  it due today. The only feedback is an accent underline on the target heading (`drag-*.png`). The handle
  is the action word itself, so slips stay selectable text and no drag chrome exists. Limits, accepted:
  only headings currently on screen are targets, and it is not offered in notepad mode.
- Rejected: a form before creation (phase 1; one action slower and it made promote feel like a decision),
  dragging whole slips (conflicts with text selection, needs drop zones).

### Triage: to-dos
- **Due** group first (late + today, project in grey after the title), then one group per project, then
  "No project". Dates right-aligned in mono: "1 d late" in accent, "today" bold, later dates grey.
- "Add a to-do" line with **`#project @due`** (graft 4): `Tag clusters #cost @fri`. `#` matches a project
  by prefix or creates one; `@` takes today, tom, a weekday, `+3`, a day number or an ISO date. The parsed
  result prints under the line in mono grey before Enter (`token-*.png`).
- Checking strikes the row in place for the session; on next load it folds into "DONE EARLIER · n".
- Clicking a title opens the row inline: editable title, the same word pickers, the source note on its
  slip, Return to notes, Delete (undoable).

### Keyboard triage (graft 3)
- **The selection is real focus on a row.** `↓` with nothing focused selects the first to-do (the first
  note in notepad mode); `↓` in an empty capture or add field does the same; Tab also reaches rows.
- While a row is selected, letters are verbs, not text: `j`/`k` or arrows move, `←`/`→` switch between
  to-dos and notes, `u` undoes, Esc leaves.
  - To-do: `x` or Space done, Enter opens, Del deletes.
  - Note: `t` makes it a to-do (selection stays on the receipt), Enter edits, Del deletes.
- With no row selected, letters still start a note. That is the whole collision rule.
- The selection is a 2 px accent hairline at the row's left, never a filled row. Key hints print at the
  right of the column label only while that column has the selection (`cursor-todo-*.png`,
  `cursor-note-*.png`). No status bar. The full list is in Settings › Keyboard.
- **Undo** is one level and covers promote, return, deletes, and shortcut removal. It is offered as `u`,
  on the receipt, and as a mono line under the capture slip ("Note deleted · Undo") that stays until the
  next change.

### Notepad mode
- Breakpoint **640 px**: half of a 1280 px laptop and a third of a 1920 px monitor. A half of 1920 (960 px)
  keeps the desk in its medium layout; "Notepad" in the masthead forces the mode at any width.
- Order, always: one-line sticky bar → **capture slip** → (one optional panel) → notes stream.
  - Bar: clock, "until 11:30 · next 12:00 *subject*", "To do *n due*", "Go".
  - Capture is auto-focused on entering the mode and **never moves**: panels (agenda, to-dos, shortcuts +
    routes + theme) now open *below* it (`notepad-todos-*.png`).
  - Stream: single column, newest first, full-width screenshots.
- Promote, receipt, Undo, tokens and the keyboard selection work the same. Routes open under the capture
  slip with a "← Notes" link.

### Empty states
One quiet sentence each, in secondary ink, no illustration: no events ("No events. The day is yours."),
no to-dos ("Nothing to do. Add one above, or send a note here with To-do →."), no notes ("No notes. Type
anywhere, or paste a screenshot."), no shortcuts ("No shortcuts yet." + Add shortcuts). See `empty-day`,
`no-todos`, `no-notes`, `empty-all`.

## Rules for adding a section

1. A section is **a route** with one word in the masthead nav **and an alias in Go** (`inv` + Enter). Home
   stays Go · Today · Notes.
2. It may place **one strip** on home: one line at the page foot, label in the rail's column, about five
   figures, the whole line links to the route.
3. Inside its route it uses only: the 30 px headline, mono caps labels, hairline-ruled tables or lists,
   mono figures. **No surfaces**, no shadows, no new colours.
4. Accent means "needs you now". Direction of a number is a sign, not a colour.
5. Capture is global: typing or pasting on the route goes to the notes draft through the masthead line. A
   section never adds its own input to home; to feed to-dos it promotes notes.
6. In notepad mode it opens under the capture slip, is listed in the Go panel, and its strip is hidden.

The Investments stub follows these: nav word, alias, one strip, a figures row, a hairline table, an ink
sparkline whose only accent is the latest point.

## Demo states (URL hash)

Combine with `&`. Any `state=` boots from fresh sample data and never writes storage. Without `state=` the
page persists notes, to-dos, projects, shortcuts, draft, open groups, last-used and theme in
`localStorage`.

| Hash | Shows |
|---|---|
| `state=home` | default desk |
| `state=group-open` | both groups open, Databricks › Prod under the pointer |
| `state=go-focus` | Go focused: aliases visible |
| `state=go` | `db p` typed, Databricks Prod marked Enter |
| `state=go-section` | `inv` typed, Investments section as the hit |
| `state=edit-shortcuts` | rail in edit mode, Databricks › Prod open for editing |
| `state=draft` | capture with text, tokens and a pasted screenshot |
| `state=receipt` (alias `promote`) | a note just promoted, receipt with defaults |
| `state=receipt-filled` | receipt with due tomorrow and a project chosen |
| `state=promoted` | receipt closed, the new to-do open with its note and screenshot |
| `state=todo-open` | an older to-do open, back-linked note and screenshot |
| `state=cursor-todo` · `state=cursor-note` | keyboard selection on a to-do / a note, key hints in the label |
| `state=token` | "Add a to-do" with `#cost @fri` and its preview |
| `state=drag` | a project heading as drop target |
| `state=earlier` | Earlier fold expanded |
| `state=note-deleted` | Undo line after deleting a note |
| `state=done` | two to-dos checked in place |
| `state=empty-day` · `no-notes` · `no-todos` · `empty-all` | empty states |
| `state=route-capture` | Investments with a note typed in the masthead and "Saved to notes · Undo" |
| `route=investments` · `route=settings` | secondary routes |
| `theme=dark` · `theme=light` | force theme |
| `mode=notepad` | force notepad mode at any width |
| `panel=day` · `panel=todos` · `panel=go` | notepad mode with that panel open |
| `now=HH:MM` | move the pinned clock (default 10:50, Fri 13 Nov 2026); try `now=08:10`, `now=15:10`, `now=17:30` |
| `reset=1` | discard stored data and reseed |

Notepad mode needs no hash: size the window to 640 px or narrower.

## Changes from previous round (phase 1 → round 1)

| Item | What changed |
|---|---|
| Graft 1, aliases and group-scoped typing | Go matches aliases and `group key`; aliases print in mono grey only while Go has focus. Aliases are editable in shortcut edit mode. |
| Graft 2, last-used marker | Ink dot on the environment; a collapsed group prints its last-used environment as a one-click link. `db` + Enter opens it. |
| Graft 3, keyboard triage | Rows take real focus; `j k x t u`, Enter, Del, arrows. Accent hairline as cursor; hints in the column label only while selected. Entry is `↓`, so type-anywhere is untouched. |
| Graft 4, tokens and Ctrl+Enter | `#project @due` in "Add a to-do" with a mono preview; Ctrl+Enter (or "Save as to-do") in capture, tokens honoured. |
| Graft 5, sections as launch targets | `inv`, `set` in Go; added to section rule 1. |
| Graft 6, words not glyph | "note + image" / "note" / "image" in mono grey on the to-do row. Slip glyph removed. |
| Graft 7, instant promote + receipt | Promote is one action; the slip becomes a receipt with pickers and Undo. Adapted: slip surface with an accent top hairline, word pickers, no timer. |
| Graft 8, fold elapsed events | "EARLIER · n" line; timeline starts at the current hour, scale adapts to the hours left. |
| Graft 9, capture on every route | Type or paste anywhere; masthead note line and "Saved to notes · Undo" on routes; capture slip stays in notepad mode on routes. |
| Graft 10, drag onto a project | Done quietly: drag the words "To-do →" onto a heading; accent underline only. Not in notepad mode. |
| Drop: promote-form explainer | Gone with the form. |
| Drop: declined in an overlap column | Declined events print as struck grey lines under the timeline (or in Earlier). |
| Drop: fixed 08–18 at 60 px/h | Replaced per graft 8; strip and full to-do list fit at 1440×900. |
| Drop: notepad panels above capture | Capture is fixed under the bar; panels open below it. |
| Drop: "delete" beside "To-do →" | Moved to the left beside the time; every delete is undoable. |
| Open question: Enter | Enter saves, Shift+Enter new line, Ctrl+Enter to-do. Reasoning above; alternative kept as a stubbed setting. |
| Full fidelity | Shortcut add/edit/reorder/remove built; empty states for day, notes, to-dos, shortcuts; editable to-do title; one-level undo; timeline text 12.5 → 13 px; now-line no longer crosses event text; timed undo removed. |

## Known stubs and mockup notes

- Shortcut links open in a new tab here; the real start page should navigate in place.
- The clock is pinned; the real app re-renders Now/Next, the fold and the now-line each minute.
- Pasted images are downscaled to 1100 px JPEG in `localStorage`; the real app should store blobs on disk
  or in IndexedDB.
- Settings: theme, shortcut editing and reset are live; calendar source, clock format and the Enter
  preference are described only. Investments data is static.
- Undo is a single snapshot, not a history.
- Dragging "To-do →" uses native HTML drag and drop; the drag state in the shots is simulated.
- The 480 px shots were taken through a 480 px iframe because headless Edge will not lay out a window
  narrower than about 500 px.
- Not verified by interaction in a real browser session this round: native drag and drop, the date picker
  popup, and real clipboard paste. They are implemented with standard APIs; the screenshots cover the
  resulting states only.
