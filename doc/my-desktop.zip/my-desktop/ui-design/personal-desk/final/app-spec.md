# Personal Desk — application specification (phase 1)

Handoff to the implementation session, together with `final/design.html` (interactive mockup),
`final/design-notes.md` (the UI: principles in Part A, specification in Part B) and `final/shots/`.

**How to read this.** This document specifies the app *behind* the UI: stack, data, persistence, API,
calendar ingestion, extensibility, non-functional requirements and acceptance tests. Everything visual or
interactive is specified in the design notes and is referenced as **DN §x** (for example DN B5 = the
interaction spec). Where the two disagree on behaviour, the design notes win for the UI and this document
wins for data and the server. Settled decisions are in `decision-log.md`; do not re-open them.

---

## 1. Purpose, user, scope

| | |
|---|---|
| Purpose | A browser start page that answers "what is my day" and is the user's one inbox for quick notes, screenshots and to-dos. |
| User | One data engineer, on one Windows machine, all workday, often with the window split-screened beside a meeting, doc or notebook. |
| Top tasks | **Launch** (glance at the day, open a site or a group environment in 1–2 actions) · **Capture** (in notepad mode, jot a note and paste a screenshot with zero ceremony; it is there tomorrow) · **Triage** (turn a note into a to-do, set due and tags, work the list). |

### Phase 1 scope (in)

- Shortcuts with groups and environments, aliases, Go field, last-used environment, inline editing.
- Day: read-only agenda for today from an ingested event feed; NOW / NEXT; Earlier fold; gaps; overlaps.
- Notes: capture with `#tag` tokens, pasted screenshots, edit in place, copy text, delete with Undo.
- To-dos: add, promote from a note (with receipt), due dates, check/uncheck, Done fold, open/edit,
  return to notes, delete with Undo; by-due (default) and by-tag views.
- Tags: one vocabulary for notes and to-dos (tags **replace** projects), filter (union), rename/merge/remove.
- Notepad mode (≤ 820 px or forced), keyboard map, light/dark/auto theme.
- Settings route (theme, edit shortcuts, edit tags, export/import, calendar feed status).
- Section registry and contract (§9) in the shell, with **no sections registered**. Investments is out of
  scope for phase 1 (see Non-goals).
- Local server, SQLite persistence, image files, backups, export/import.

### Non-goals (phase 1)

- Auth, multi-user, sharing, sync across machines, mobile/phone layouts, remote hosting.
- Editing calendar events; a built-in calendar connector (Graph/Outlook). Only the ingestion interface ships.
- To-do priorities, sub-tasks, recurrence, reminders, notifications.
- **Investments section — out of scope for phase 1.** No route, nav word, Go alias, home strip, stub or
  sample data. It is the expected first section of a later phase, added through §9.
- Replacing the browser's *new-tab* page (needs an extension; see §12 open questions). Start/home page only.
- Full-text search across notes (Go matches shortcuts, sections and `#tag` prefixes only, per DN B5).

---

## 2. Deployment model and stack

### Deployment

| Aspect | Requirement |
|---|---|
| Where | Only on the user's Windows 10/11 machine. Never exposed to the network. |
| Browser | Current Chrome and Edge. Set as startup/home page: `http://127.0.0.1:4711/`. |
| Binding | `127.0.0.1` only (not `0.0.0.0`, not `::`). Port configurable, default `4711`. |
| Users | Single user, no auth, no accounts. |
| Start | Windows Task Scheduler task "At log on" running `pythonw.exe -m desk` (no console window). A PowerShell script `scripts/install-startup.ps1` creates/removes the task. If the port is already bound (second instance), exit with code 0 and a log line. |
| Data dir | `%LOCALAPPDATA%\PersonalDesk\` (override with `--data-dir`). Holds DB, images, calendar inbox, backups, logs, `config.toml`. Code and data are separate so the app can be updated by replacing the code folder. |
| Offline | Everything works offline: the app makes **no** remote calls. Fonts are self-hosted. Only the calendar feed's freshness depends on whatever pushes data in (§6). |

### Recommended stack: Python 3.12+ standard library only + plain ES-module front end

| Layer | Choice | Why |
|---|---|---|
| Server | Python `http.server.ThreadingHTTPServer` + a ~150-line router | Zero third-party runtime dependencies; a data engineer's machine already has Python; trivial to run under `pythonw`. Traffic is one user on localhost, so a stdlib server is ample. |
| Storage | `sqlite3` (stdlib), WAL mode, `PRAGMA foreign_keys=ON` | Transactional, one file, easy backup with `VACUUM INTO`. |
| Config | `tomllib` (stdlib) reading `config.toml` | No dependency. |
| Images | Files on disk, content-addressed (see §3.6) | |
| Export | `zipfile` + `json` (stdlib) | |
| Front end | Plain HTML + CSS + vanilla JS as native ES modules, **no build step**, no framework | The mockup is already vanilla JS; the UI is small and typographic; incremental DOM updates per zone are enough. Nothing to compile, nothing to upgrade. |
| Tests | `unittest` (stdlib) for server; Playwright (dev-only dependency) for end-to-end acceptance tests | Runtime stays dependency-free. |

Acceptable alternative if Python is unwanted: Node 22+ with built-in `node:http` and `node:sqlite`, same layout
and contract. Do not mix: pick one.

Image upload uses a raw request body (`Content-Type: image/png` etc.), not multipart, so no multipart parser
is needed (the stdlib `cgi` module is gone in 3.13).

### Project layout

```
personal-desk/
  desk/                         Python package (server)
    __main__.py                 CLI: --port, --data-dir, --seed-demo, --dev
    server.py                   HTTP server, router, Host/Origin/header checks, static files, CSP
    db.py                       connection, PRAGMAs, migration runner
    migrations/0001_init.sql    numbered, forward-only SQL migrations
    api/                        shortcuts.py notes.py todos.py tags.py settings.py undo.py
                                calendar.py images.py export.py sections.py bootstrap.py
    calendar_ingest.py          parse + normalise + store feeds; inbox folder poller
    images.py                   validation, hashing, storage, GC
    maintenance.py              daily backup, soft-delete purge, image GC
    sections/
      __init__.py               section registry (§9); empty in phase 1
  web/
    index.html                  shell; theme preference injected by the server (no flash)
    css/tokens.css  css/app.css
    fonts/                      Instrument Sans + IBM Plex Mono, woff2, OFL licences
    js/
      main.js  api.js  store.js  sync.js  router.js  keyboard.js  clipboard.js
      parse.js                  #tag / @due token parser, first-sentence title (single source)
      calendar.js               local-time maths: today window, now/next, folds, gaps, overlaps
      zones/  go.js day.js todos.js notes.js capture.js notepad.js tags.js settings.js
      sections/registry.js      empty in phase 1
  scripts/  install-startup.ps1  push-calendar.example.ps1
  tests/    server/ (unittest)   e2e/ (Playwright)   fixtures/seed-demo.json
```

---

## 3. Data model

SQLite. All IDs are `TEXT` (32-char lowercase hex from `uuid4`), generated by the server. All timestamps
are `INTEGER` epoch **milliseconds UTC**. Calendar dates without time (to-do due) are `TEXT 'YYYY-MM-DD'`
interpreted as a **local** date. Every mutable row has `created_at`, `updated_at`; rows that can be undone
after delete have `deleted_at` (soft delete).

### 3.1 Shortcuts and groups

One self-referencing table; nesting is at most one level (group → environment).

`shortcut`

| Field | Type | Constraints / meaning |
|---|---|---|
| `id` | TEXT PK | |
| `kind` | TEXT | `'link'` or `'group'`. A row with `parent_id` set is an *environment* and must be `'link'`. |
| `parent_id` | TEXT NULL FK → shortcut.id | Only a `group` may be a parent. Depth ≤ 1 (enforced in app + trigger). |
| `name` | TEXT NOT NULL | 1–60 chars, trimmed. |
| `url` | TEXT NULL | Required for links, NULL for groups. Scheme must be `http` or `https` (rejects `javascript:`, `data:`, `file:`). ≤ 2048 chars. |
| `alias` | TEXT NULL | Top-level link or group: alias, `[a-z0-9]{1,8}`, unique (case-insensitive) among top-level rows and not equal to a section alias (§9). Environment: **key letter(s)**, `[a-z0-9]{1,3}`, unique within its group; NULL = first letter of name (DN B4). |
| `position` | INTEGER NOT NULL | Display order within its parent; dense 0..n-1, rewritten on reorder. |
| `is_open` | INTEGER 0/1 | Groups only: expanded state (persists, DN B4 `groupsOpen`). |
| `last_used_child_id` | TEXT NULL | Groups only: environment opened most recently (DN B4 `lastUsed`). Set NULL if that child is removed. |
| `created_at`, `updated_at`, `deleted_at` | INTEGER | Remove = soft delete (undoable). A removed group soft-deletes its children in the same operation. |

### 3.2 Notes

`note`

| Field | Type | Constraints / meaning |
|---|---|---|
| `id` | TEXT PK | |
| `text` | TEXT NOT NULL DEFAULT '' | Plain text, `\n` line breaks, ≤ 20 000 chars. Captured text has `#tags` already extracted by the client (DN B5 Capture). A note must have text or ≥ 1 image. |
| `status` | TEXT | `'active'` (on the wall) or `'promoted'` (attached to a to-do, hidden from the wall and from note counts/filters). |
| `todo_id` | TEXT NULL FK → todo.id | Set when `status='promoted'`; unique. |
| `created_at` | INTEGER | The note's time shown in its footer; the wall sorts by this, **strictly newest first**. Never changes, so "Return to notes" puts it back in its time position. |
| `updated_at`, `deleted_at` | INTEGER | Delete = soft delete (undoable). |

`note_image` (ordered images in a note; the draft also uses images, see §4)

| Field | Type | Constraints |
|---|---|---|
| `note_id` | TEXT FK → note.id ON DELETE CASCADE | |
| `image_id` | TEXT FK → image.id | |
| `position` | INTEGER | Order within the note. PK (`note_id`, `position`). |

### 3.3 To-dos

`todo`

| Field | Type | Constraints / meaning |
|---|---|---|
| `id` | TEXT PK | |
| `title` | TEXT NOT NULL | 1–500 chars, single line. |
| `due` | TEXT NULL | `'YYYY-MM-DD'`, local date. |
| `done_at` | INTEGER NULL | NULL = open. Checking sets it, unchecking clears it. |
| `created_at`, `updated_at`, `deleted_at` | INTEGER | Delete = soft delete (undoable); its source note is soft-deleted with it. |

The source note is reached through `note.todo_id` (one-to-one, optional). No `position`: to-do order is
computed (DN B5 To-dos): by due — `DUE` = late (oldest first) then today; `LATER` = dated by date, then
undated newest first (`created_at` desc); Done fold. "Done this session stays in place" is a **client**
rule: a to-do with `done_at` ≥ the page's load time renders struck in place; older ones render in the fold.

### 3.4 Tags (replace projects)

`tag`

| Field | Type | Constraints |
|---|---|---|
| `id` | TEXT PK | |
| `name` | TEXT NOT NULL UNIQUE | `^[a-z0-9_-]{1,32}$` (the client lower-cases and strips other characters, DN B4). |
| `position` | INTEGER | Creation order = TAGS list order and by-tag heading order. Never reordered in phase 1. |
| `created_at`, `updated_at` | INTEGER | |

`item_tag` (many-to-many, polymorphic so future sections can be tagged without a schema change — §9)

| Field | Type | Constraints |
|---|---|---|
| `tag_id` | TEXT FK → tag.id ON DELETE CASCADE | |
| `item_type` | TEXT | `'note'`, `'todo'`, or a type registered by a section. Validated in app against the registry. |
| `item_id` | TEXT | |
| PK | (`tag_id`, `item_type`, `item_id`) | Index on (`item_type`, `item_id`). Tags on an item are a **set**; order is meaningless (display sorts alphabetically, DN B3). |

Rules:
- A tag is created implicitly the first time an item is saved with a new word (no separate "create tag" call).
- A tag with zero uses stays in the vocabulary (the TAGS list hides it unless it is in the active filter,
  DN B5); it disappears only via "Remove tag".
- **Counts** (TAGS list) = active notes + open to-dos carrying the tag. Promoted notes, done to-dos and
  soft-deleted items are not counted. Done to-dos are still matched by the filter (Done fold).
- Rename to a free name: update `tag.name`. Rename to an **existing** name: **merge** — re-point all links
  to the target (`INSERT OR IGNORE`), delete the old tag. Remove: delete links, then the tag. No item is
  ever deleted by a tag operation. All three are undoable (§5.8).

### 3.5 Promote-to-to-do semantics

Decided in the design (DN B5 Notes › Promote, decision-log Phase 2 "instant promote with receipt and
Undo"). Server behaviour, in one transaction:

| Step | Behaviour |
|---|---|
| Title | First line of the note text, cut at the first sentence end (`.`, `?`, `!` followed by whitespace) if at least 12 chars precede it, trailing `.` dropped, ≤ 110 chars. Image-only note: `Screenshot, HH:MM` (note's local time). Computed by the **client** (`parse.js`, mirrors the mockup's `firstLine`) and sent; server only validates. |
| Due | From an `@due` token in the note's first line if present (client-parsed), else the explicit value sent (receipt Due words, drag onto `DUE` = today), else NULL. |
| Tags | The to-do gets a **copy** of the note's tags, plus an extra tag when promoted by dragging onto a rail tag, plus the stamped tag when exactly one tag is filtered (DN B5 Tags). After promote, the note's and the to-do's tag sets are independent. |
| Source note | **Kept intact, not copied:** `status='promoted'`, `todo_id` set. It leaves the wall, keeps its text, images, own tags and `created_at`, and is shown inside the to-do ("note + image", open to-do view). Rationale: the to-do carries its context; the wall stays an inbox of unprocessed notes; nothing is duplicated; the step is reversible. |
| Return to notes | Inverse: note `status='active'`, `todo_id=NULL`, the to-do is soft-deleted. The note reappears at its original time position with its own tags. |
| Save as to-do (Ctrl+Enter in capture) | Creates the note *and* promotes it in one call (same result as capture then promote). |
| Delete the to-do | Soft-deletes the to-do and its source note together; Undo restores both. |
| Undo of promote | Restores the note to the wall and soft-deletes the to-do. |

### 3.6 Images

**Decision: files on disk, content-addressed, metadata in SQLite.** Justification: keeps the DB small and
fast to back up; files are immutable so the browser can cache them forever; the user can inspect/restore
them by hand; identical pastes de-duplicate for free. Blobs would bloat every DB backup and every
bootstrap-adjacent page read.

`image`

| Field | Type | Constraints |
|---|---|---|
| `id` | TEXT PK | = SHA-256 of the stored bytes (hex). |
| `mime` | TEXT | `image/webp`, `image/png` or `image/jpeg`. SVG and GIF are rejected. |
| `width`, `height` | INTEGER | Stored so the client reserves space (no layout shift) and can decide `cropped · open` before load. |
| `bytes` | INTEGER | |
| `created_at` | INTEGER | |
| `last_referenced_at` | INTEGER | Updated when attached to a note or the draft; used by GC. |

Storage path: `images/<first 2 hex>/<id>.<ext>`.

| Rule | Value |
|---|---|
| Client processing on paste | Downscale to **1100 px wide** max (DN B5 Capture), keep aspect, encode WebP quality 0.9 (`canvas.toBlob`); keep PNG if the WebP is larger. See open question Q6. |
| Server limits | ≤ **5 MB** per upload after client processing (413 above); ≤ 8 000 px either side; magic bytes must match `Content-Type` (415 otherwise); ≤ **10 images per note** (422). |
| Serving | `GET /img/<id>` with stored `Content-Type`, `Cache-Control: public, max-age=31536000, immutable`, `X-Content-Type-Options: nosniff`. |
| Orphan GC | Daily and at startup: delete image files and rows that no note (any status, including soft-deleted) and no draft references, **and** whose `last_referenced_at` is older than **30 days**. The 30-day grace exceeds backup retention (14 days, §4), so a restored backup never points at a collected file. |
| Purge | Soft-deleted notes, to-dos and shortcuts are hard-deleted after **30 days**; their images then become orphans and follow the GC rule. |

### 3.7 Settings and UI preferences

`setting` (key/value, JSON values)

| Key | Type / default | Scope |
|---|---|---|
| `theme` | `'auto' \| 'light' \| 'dark'`, default `'auto'` | Server. Injected into `index.html` as `<html data-theme-pref=…>` so the first paint has the right theme. |
| `todo_view` | `'due' \| 'tag'`, default `'due'` | Server (remembered preference, decision-log R2 user call). |
| `calendar.stale_after_min` | int, default `120` | Server (§6). |
| `draft_image_ids` | — | Not here; the draft is per browser (§4). |

### 3.8 Supporting tables

| Table | Purpose |
|---|---|
| `calendar_event` | `id`, `source`, `subject`, `start_utc` (ms), `end_utc` (ms), `response`, `ingest_id`. Index on (`start_utc`, `end_utc`). |
| `calendar_ingest` | `id`, `source`, `received_at`, `generated_at`, `window_start_utc`, `window_end_utc`, `event_count`, `status` (`ok`/`rejected`), `error`. |
| `undo_log` | `token`, `label`, `created_at`, `inverse` (JSON ops), `guard` (JSON `{entity: updated_at}`), `consumed_at`. |
| `meta` | `revision` (integer bumped on every write; used for cross-tab change detection, §4). Schema version is `PRAGMA user_version`. |

---

## 4. Persistence

### What lives where

| State | Where | Notes |
|---|---|---|
| Shortcuts, group open state, last-used environment | Server (SQLite) | |
| Notes, images, to-dos, tags, links | Server | |
| Theme, `todo_view` | Server (`setting`) | One preference across Chrome and Edge. |
| Calendar events and feed status | Server | |
| **Note draft** (text + pasted image ids) | **Per browser**: `localStorage['desk.draft'] = {text, imageIds[]}` | Survives reload, route and mode (DN B4). Images are uploaded on paste (so the draft only holds ids). Written on every input; other tabs of the same browser follow via the `storage` event, so two open start-page tabs share one draft. |
| Tag filter, `keep` set, route, notepad panel, forced-notepad flag, row selection, receipt, `Copied`, folds, open to-do | **In memory, per tab, never persisted** (DN B4 "UI state"). | Tag filter explicitly does not persist. |
| Undo | Server `undo_log`; the tab holds only the latest token | One level in the UI (DN B5). |

### Many tabs, one store

As the start page, several tabs of the app are usually open at once. Requirements:
- After every successful write, the tab posts `{type:'changed', rev}` on `BroadcastChannel('desk')`; other
  tabs refetch the affected slice.
- On `visibilitychange` → visible and on `focus`, a tab calls `GET /api/v1/rev`; if `revision` differs from
  what it rendered, it refetches `bootstrap` and re-renders without losing its UI state (filter, open
  editors, focus, draft).
- Writes are last-write-wins (single user). An undo whose guard fails returns 409 (§5.8).

### Migrations and schema versioning

- `PRAGMA user_version` = number of the last applied migration. Files `desk/migrations/NNNN_name.sql` are
  applied in order at startup, each in a transaction. Forward-only; no down migrations.
- Before applying any pending migration, copy the DB with `VACUUM INTO backups/pre-migrate-NNNN.sqlite`.
- If the DB's `user_version` is newer than the code knows, refuse to start and log why.
- Export files carry `schema_version`; import migrates older exports forward and refuses newer ones.

### Backup, export, import

| Mechanism | Decision |
|---|---|
| Automatic backup | Daily at first start of the day (and at 03:00 if running): `VACUUM INTO backups/desk-YYYY-MM-DD.sqlite`. Keep **14**. Images are immutable and GC'd only after 30 days, so DB backups stay valid. |
| Export | `GET /api/v1/export` → `desk-export-YYYYMMDD-HHMM.zip` containing `desk.json` (all non-deleted entities + settings, `schema_version`, `exported_at`) and `images/<id>.<ext>`. Offered in Settings as a secondary action `Export`. |
| Import | `POST /api/v1/import` (zip body) **replaces** all data, after an automatic `pre-import` backup. Settings action `Import…` (file picker). No merge in phase 1. Validates fully before touching data; on any error nothing changes (400 with the first problem). |
| Dev seed | `python -m desk --seed-demo` loads `tests/fixtures/seed-demo.json` (the mockup's seed, DN B4) into an empty data dir. First real run starts empty with the empty states of DN A6-27. |

---

## 5. API

Base path `/api/v1`. JSON in and out (`Content-Type: application/json; charset=utf-8`) except image upload,
export and import. All mutating requests (POST/PUT/PATCH/DELETE) must carry header `X-Desk: 1` (§10).

**Errors:** `{"error": {"code": "<machine_code>", "message": "<human text>", "field": "<optional>"}}`

| Status | Codes |
|---|---|
| 400 | `bad_json`, `validation` (with `field`) |
| 403 | `bad_host`, `bad_origin`, `missing_header` |
| 404 | `not_found` |
| 409 | `alias_taken`, `undo_stale`, `undo_consumed`, `conflict` |
| 413 | `too_large` |
| 415 | `unsupported_media` |
| 422 | `limit` (e.g. too many images) |
| 500 | `internal` (logged with a request id) |

**Undoable writes** return `"undo": {"token": "...", "label": "Note deleted"}` alongside the result. The
label is the text the UI prints before `· Undo` (DN B3 Undo line, receipt).

### 5.1 Bootstrap and change detection

| Method | Path | Response |
|---|---|---|
| GET | `/bootstrap?from=<utc iso>&to=<utc iso>` | Everything home needs in one call: `{rev, server_time, settings, shortcuts, tags, notes:{items, next_cursor}, todos:{open, done}, calendar, sections}`. `from`/`to` = the browser's local-today window in UTC (§6). `notes` = newest 200 active notes; `todos.open` = all open; `todos.done` = done within 30 days (Q9). |
| GET | `/rev` | `{rev}` |

Shapes used below:

```jsonc
Shortcut  {"id","kind":"link|group","name","url","alias","position",
           "isOpen","lastUsedChildId","children":[Shortcut]}          // children only on groups
Tag       {"id","name","position","noteCount","todoCount"}
Note      {"id","text","tags":["cost","prod"],"images":[{"id","width","height","url":"/img/<id>"}],
           "createdAt","updatedAt","status":"active|promoted","todoId"}
Todo      {"id","title","due":"2026-11-16"|null,"doneAt":null|ms,"tags":[...],
           "note":Note|null,"createdAt","updatedAt"}
```

### 5.2 Shortcuts

| Method | Path | Body → Response | Notes |
|---|---|---|---|
| GET | `/shortcuts` | → `[Shortcut]` (tree, ordered) | |
| POST | `/shortcuts` | `{kind, parentId?, name, url?, alias?}` → `Shortcut` | Appends at the end of its level. |
| PATCH | `/shortcuts/{id}` | any of `{name, url, alias, isOpen}` → `Shortcut` | "Save as typed" (DN B5): the client debounces 400 ms. 409 `alias_taken`. |
| POST | `/shortcuts/{id}/used` | `{}` → `{groupId, lastUsedChildId}` | Environment opened. Sent with `navigator.sendBeacon`-style fire-and-forget (`fetch(..., {keepalive:true})`) because the page navigates away. |
| PUT | `/shortcuts/order` | `{parentId: null\|id, ids:[...]}` → `[Shortcut]` | Full order of one level; drag and Up/Down both use it. Moving across levels is not supported (DN: drag within a level). |
| DELETE | `/shortcuts/{id}` | → `{undo}` | Soft delete (group with children). |

### 5.3 Notes and images

| Method | Path | Body → Response | Notes |
|---|---|---|---|
| GET | `/notes?cursor=&limit=100&tag=a&tag=b` | → `{items:[Note], next_cursor}` | Active notes, `created_at` desc. Repeated `tag` = union (OR). Older pages load on scroll; no visible control. |
| POST | `/notes` | `{text, tags:[], imageIds:[]}` → `Note` (+ `undo` when saved from a non-home route, DN B5) | Client has already extracted `#tags`; unknown tags are created. 400 if no text and no images. |
| PATCH | `/notes/{id}` | `{text?}` → `Note` | In-place edit, saved on blur (verbatim; see Q8). |
| PUT | `/notes/{id}/tags` | `{tags:[...]}` → `Note` | Replaces the set (tag editor). Creates unknown tags. |
| DELETE | `/notes/{id}` | → `{undo}` | Soft delete. |
| POST | `/images` | raw body, `Content-Type: image/webp\|png\|jpeg` → `{id, width, height, url}` | Called on paste; idempotent (content hash). |
| DELETE | — | — | No image delete endpoint: removing a draft thumbnail just drops the id; GC collects it. |

**Copy** is client-only: `navigator.clipboard.writeText(note.text)` (text only, never images; DN B5). No API.

### 5.4 Promote and return

| Method | Path | Body → Response |
|---|---|---|
| POST | `/notes/{id}/promote` | `{title, due?: date\|null, addTags?: [...]}` → `{todo: Todo, undo}`. 409 `conflict` if the note is not active. |
| POST | `/notes/save-as-todo` | `{text, tags, imageIds, title, due?}` → `{todo: Todo, undo}` (Ctrl+Enter in capture). |
| POST | `/todos/{id}/return-to-notes` | `{}` → `{note: Note, undo}`. 409 if the to-do has no source note. |

### 5.5 To-dos

| Method | Path | Body → Response | Notes |
|---|---|---|---|
| GET | `/todos?state=open\|done\|all&tag=a&tag=b&doneSince=ms` | → `[Todo]` | Unordered by the server; the client orders (DN B5). |
| POST | `/todos` | `{title, due?, tags?}` → `Todo` | "Add a to-do" field; client parses `#tag @due`. |
| PATCH | `/todos/{id}` | any of `{title, due}` → `Todo` | `due: null` clears. |
| PUT | `/todos/{id}/tags` | `{tags:[...]}` → `Todo` | |
| POST | `/todos/{id}/complete` | `{}` → `Todo` (sets `doneAt` = now) | Idempotent. |
| POST | `/todos/{id}/uncomplete` | `{}` → `Todo` | Idempotent. |
| DELETE | `/todos/{id}` | → `{undo}` | Also soft-deletes the source note. |

### 5.6 Tags

| Method | Path | Body → Response | Notes |
|---|---|---|---|
| GET | `/tags` | → `[Tag]` (vocabulary order, with counts) | Completion ranking ("most-used first", DN B5) uses `noteCount + todoCount`, computed client-side. |
| GET | `/tags/{name}/usage` | → `{notes, todos}` | Usage line `on 2 notes, 1 to-do` (DN B5). |
| GET | `/tags/{name}/rename-preview?to=x` | → `{merge: bool, target}` | Drives the `merges into #x · Enter` warning before committing. |
| POST | `/tags/{name}/rename` | `{to}` → `{tag: Tag, merged: bool, undo}` | Rename, or **merge** when `to` exists. Applies to all item types (incl. promoted notes). |
| DELETE | `/tags/{name}` | → `{undo}` | Removes the tag from every item, then from the vocabulary. |

### 5.7 Settings, calendar, sections, export

| Method | Path | Body → Response |
|---|---|---|
| GET / PATCH | `/settings` | `{theme?, todo_view?, ...}` → full settings |
| GET | `/calendar?from=<utc>&to=<utc>` | `{events:[{subject, start, end, response}], feed:{lastReceivedAt, generatedAt, source, windowStart, windowEnd, stale:bool}}` — `start`/`end` as UTC ISO with `Z`, ms precision. |
| POST | `/calendar/ingest` | Feed payload (§6) → `{ingestId, accepted, rejected:[{index, reason}]}` |
| GET | `/sections` | `[SectionManifest]` (§9) |
| GET | `/sections/{id}/strip` | `{label, headline, change, details:[...], asOf}` or 204 if the section has no strip |
| GET | `/export` · POST `/import` | §4 |

### 5.8 Undo strategy

- Every undoable write stores, in the same transaction, an **inverse operation list** in `undo_log` (e.g.
  promote → `[{op:'note.setStatus', id, status:'active'}, {op:'todo.softDelete', id}]`; tag merge → the
  list of `(item_type, item_id)` that carried the old tag plus the old tag row) and a **guard**: the
  `updated_at` of every row the inverse touches.
- `POST /undo/{token}` → applies the inverse in one transaction and returns the restored entities plus
  `{rev}`. 409 `undo_stale` if any guarded row changed since (the UI then prints `Can't undo · changed since`
  in place of `Undo`); 409 `undo_consumed` if already used.
- The UI exposes **one level** (the latest token in the tab), via `u`, the receipt or the Undo line (DN B5).
  The server keeps the last 50 tokens for 24 h; older rows are purged.
- Undoable: note delete, promote, save-as-to-do, return-to-notes, saved-to-notes from a non-home route,
  to-do delete, tag rename/merge/remove, shortcut remove. Check/uncheck, edits, reorder and tag-set changes
  are reversed by doing the opposite action and are not in the undo log.

---

## 6. Calendar ingestion

### Input record

`{"subject": string, "start": ISO 8601, "end": ISO 8601, "response": string}` — optional `"id"` (source
event id, used only for de-duplication).

### Parsing and normalisation (server, `calendar_ingest.py`)

| Rule | Behaviour |
|---|---|
| Fraction | Truncate the fractional seconds to 6 digits before parsing (`.0000000` has 7). |
| Offset | Accept `Z`, `+00:00`, any `±HH:MM`. Convert to UTC epoch ms. |
| No offset | The brief's sample lacks one; real data has it. Treat naive values as **UTC** (configurable `calendar.naive_tz`, see Q5) and count them in the ingest record. |
| Validation | `end > start` (else reject the record); `end − start ≤ 14 days`; `subject` trimmed, ≤ 500 chars, empty → `(no subject)`. |
| Response | `organizer`, `accepted`, `tentativelyAccepted`, `notResponded`, `declined`. Matching is case-insensitive. Unknown or missing (e.g. Graph's `none`) → `notResponded`, counted as a warning. |
| Duplicates | Same `id`, or same (`subject`, `start`, `end`) → keep one (the stronger response wins: organizer > accepted > tentative > notResponded > declined). |
| Snapshot semantics | An ingest **replaces** all stored events of the same `source` whose interval intersects the ingest window. Window = payload `window` if given; for a bare array, from local midnight of the earliest event day to local midnight after the latest event day (server local time); an empty bare array means "today has no events". |
| Retention | Events ending more than 30 days ago are deleted. |

### Meaning of `response` (display per DN B3 Agenda row)

| Value | Meaning | Rule | Word | Counts for NOW/NEXT, gaps, overlaps |
|---|---|---|---|---|
| `organizer` | User owns the meeting | solid | — | yes |
| `accepted` | Accepted | solid | — | yes |
| `tentativelyAccepted` | Maybe | dashed | `tentative` | yes |
| `notResponded` | No reply yet | dotted | `no reply` | yes |
| `declined` | Not attending | none, struck subject | `declined` | **no** (stays in chronological place) |

### Local time and "today" (client, `calendar.js`)

- The browser's time zone is the authority (it is the same machine as the server). All display is local,
  24-hour.
- **Today** = `[local midnight, next local midnight)` computed with `Date` (DST-correct; a DST day is 23 or
  25 h). The client sends this window as UTC instants to `/calendar` and `/bootstrap`.
- An event belongs to today if `start < todayEnd && end > todayStart`.
- **Crossing midnight:** an event that started yesterday or ends tomorrow is listed with its real local
  times (`23:30–00:30`), sorted by start; it is "running" while `start ≤ now < end`. Gap and overlap maths
  clamp intervals to today's window.
- Events of ≥ 24 h that cover the whole day (all-day / multi-day): see Q4; default — listed first in the
  agenda with time column `all day`, never NOW/NEXT, ignored for gaps and overlaps.
- Re-render NOW/NEXT, Earlier fold, gaps and the now tick on each **minute boundary** (one `setTimeout`
  re-armed each minute; this updates data, it is not an animation) and immediately on `visibilitychange`.
  When the local date changes, refetch the calendar for the new day (DN B8).

### Pluggable sources

```
Source (push) ──► POST /api/v1/calendar/ingest ─┐
Source (file) ──► <data>\calendar\inbox\*.json ─┼─► normalise ─► calendar_event (+ calendar_ingest)
Future plug-in ─► CalendarSource.fetch()  ──────┘
```

| Channel | Contract |
|---|---|
| Payload | Either a bare array of records, or `{"source": "outlook-export", "generatedAt": ISO, "window": {"start": ISO, "end": ISO}, "events": [...]}`. Default `source` = `"default"`. |
| POST | `POST /api/v1/calendar/ingest`, header `X-Desk: 1`, JSON body ≤ 2 MB. For scripts (PowerShell `Invoke-RestMethod`, Power Automate Desktop, a Graph export job). Example in `scripts/push-calendar.example.ps1`. |
| Drop folder | Any `*.json` written to `<data>\calendar\inbox\`. Polled every 60 s and at startup; a file is read only when its size is unchanged across two polls (finished writing). Then moved to `processed\` (keep last 20) or `failed\` with a `.error.txt` beside it. |
| Plug-in (later) | A Python class registered in config: `fetch(window) -> payload`, `interval_min`. Runs in a background thread; failures are logged and recorded in `calendar_ingest`. Phase 1 ships none. |

### Staleness

- `feed.stale = now − lastReceivedAt > calendar.stale_after_min` (default 120 min), or no ingest has ever
  covered today.
- When stale, the Day label row shows a fixed-length grey `as of HH:MM` (or `as of Thu 12` if older than
  today) on the right, `--ink3`, never the accent — consistent with the strip's `as of …` (DN A6-23) and the
  label-row rule (DN B3). Settings shows the feed status line (`source · last received · n events`).
- Never received anything: Day shows one quiet sentence `No calendar feed yet. See Settings.` (DN A6-27).
  A received feed with no events today keeps the designed `No events. The day is yours.`

---

## 7. Responsive modes as behaviour

All mode logic is client-side; the server is unaware of widths.

| Width (CSS px, `window.innerWidth`) | Mode | Source |
|---|---|---|
| ≥ 1360 | Desk, Day and To do side by side | DN A5-19, B1 |
| 1200–1359 | Desk, Day above To do | |
| 821–1199 | Desk, two columns, rail collapsed to link lines | |
| ≤ 820 | **Notepad mode** | |
| any, `Notepad` link | Forced notepad mode; bar shows `Full view` | DN B5 Notepad |

- Implement with `matchMedia('(max-width: 820px)')` and listen for `change`. Layout ranges are pure CSS
  media queries; only the notepad switch needs JS (different DOM order and auto-focus).
- **Forced** notepad is per tab, in memory; reload returns to width-based mode (DN B4).
- **Survives a mode switch** (both directions): draft text and images, caret position in capture, tag
  filter and `keep` set, receipt, open to-do, `Copied` state, Undo token, folds, route. Row selection
  survives if the selected row is visible in the new mode, else it clears. The notepad panel choice is
  dropped when leaving notepad mode.
- Entering notepad mode focuses the capture slip unless another field had focus (DN B5).
- Nothing is refetched on a mode switch.

---

## 8. Keyboard and clipboard

- **Keyboard map:** implement DN B6 exactly, with the principles in DN A4-18 (`/` always to Go; any
  printable key with nothing focused starts a note; Esc backs out one level; selection is keyboard-only).
  One central `keydown` handler in `keyboard.js` dispatches by context (field type, selected row kind,
  route, mode); zones register verbs.
- **No lost keystrokes at load:** `index.html` contains a tiny inline script that buffers printable keys
  and pastes typed before the modules finish loading, then replays them into capture (or Go after `/`).
- **Paste image:** a document-level `paste` listener on every route and mode. If
  `clipboardData.items` contains an `image/*`, prevent default, downscale/encode (§3.6), `POST /images`,
  append the id to the draft, render the 74 px thumbnail (DN B2). Text pastes are left to the browser.
  Several images in one paste → all added in order (up to the per-note limit). Drag-and-drop of image files
  onto capture follows the same path.
- **Copy text:** `navigator.clipboard.writeText(note.text)`; works because `http://127.0.0.1` is a secure
  context. Requires a user gesture (click or `c` key). On rejection, leave the label as `Copy` and log; no
  fallback needed. Image-only notes have no `Copy` (DN B5).
- **Links:** shortcuts navigate in place (`location.assign`) because the app is the start page; middle-click
  and Ctrl+click open a new tab (use real `<a href>` elements). Record `used` with `keepalive` before
  navigating (§5.2).

---

## 9. Extensibility contract for future sections

Follows DN A6 (rules 22–27) and the checklist DN A8. A section is registered on **both** sides; the two
manifests share the same `id`.

> **Phase 1:** the registry ships empty. Investments is out of scope for phase 1; it appears below only as
> the worked example of a future section.

### Server manifest (`desk/sections/<id>/__init__.py`)

| Field | Meaning |
|---|---|
| `id` | e.g. `investments` (later phase) — also the route segment and the API prefix `/api/v1/sections/investments/…`. |
| `title` | Nav word (`Investments`). One word. |
| `alias` | Go alias (`inv`). Reserved: shortcut aliases may not use it (409 `alias_taken`). |
| `nav_order` | Position in the masthead nav after `Today`, before `Settings`. |
| `migrations` | Optional folder of `NNNN_*.sql` for its own tables, prefixed `<id>_`; tracked in `section_migration(section_id, version)`. Core `user_version` is unaffected. |
| `routes` | Optional extra API handlers mounted under its prefix. |
| `strip()` | Optional: returns `{label, headline, change, details[], asOf}` for the one home strip (DN A6-23), or `None`. |
| `taggable_types` | Optional list of `item_type` strings it puts in `item_tag`. The core tag rename/merge/remove then covers them automatically. Each type supplies `count_active(tag_ids)` for TAGS counts and `exists(item_id)` for validation. |
| `data_source` | Optional plug-in: `fetch() -> snapshot`, `interval_min`, `as_of`. Same lifecycle and staleness convention as the calendar (§6): stored snapshot, `asOf` shown in grey, never blocks render. |
| `settings` | Optional list of setting keys with defaults; rendered as one line in Settings. |

### Client manifest (`web/js/sections/<id>.js`, imported by `registry.js`)

```js
export default {
  id: 'investments', title: 'Investments', alias: 'inv',
  renderRoute(el, ctx) {},        // list grammar only (DN A6-24); ctx = {api, tags, filter, mode, keyboard}
  renderStrip(el, data) {},       // optional; one line, details drop whole from the right
  notepad: { hideColumns: ['units', 'weight'] },  // optional mode adaptations (DN B5 Investments)
  keys: {},                       // optional verbs while its rows are selected; must not use / or printable keys with nothing focused
  taggable: false,                // true → its #words filter and it honours the global filter
};
```

### Behaviour the shell guarantees (sections cannot opt out)

| Concern | Rule |
|---|---|
| Route | `/#/<id>` (hash routing, so the server serves one `index.html`). Masthead nav word + Go alias + listed in the notepad Go panel (DN A6-22, A8-1). |
| Home strip | At most one, under Go + Today; hidden in notepad mode (DN A6-26). Fetched after first paint; a failing strip renders nothing. |
| Go launch target | `alias` and name prefix match in Go; Enter navigates to the route. |
| Capture | Always global: typing and Ctrl+V on the route land in the shared draft via the masthead field; a section never adds its own capture (DN A6-25). |
| Tags / filter | If `taggable`, the section uses the one vocabulary and the active filter; it may not create a second tag concept. |
| Notepad mode | Route opens under the capture slip with `← Notes` (DN A6-26). |
| Empty / stale | One quiet sentence; stale data shows `as of …` in grey. |

Phase 1 ships no section. The shell must still render correctly with an empty registry: nav is
`Today · Settings`, no home strip area, Go matches shortcuts, Settings and `#tag` prefixes only. With no
section to exercise it, the contract is unproven in phase 1; the first later-phase section (likely
Investments) must pass DN A8 using only this contract.

---

## 10. Non-functional requirements

### Performance budget (warm server, typical data: 1 000 notes, 300 to-dos, 30 shortcuts)

| Metric | Budget |
|---|---|
| Server cold start to listening | < 1 s |
| `GET /api/v1/bootstrap` server time | < 30 ms p95 (local) |
| Navigation → first paint with masthead, Go, Today and the top notes | < 200 ms |
| Go field accepts typing | from first paint (key buffer, §8) |
| Shell transfer (HTML + CSS + JS, uncompressed, excl. fonts and images) | < 150 KB |
| Fonts | 4 woff2 files max, ≤ 250 KB total, the two regular weights `<link rel=preload>`, `font-display: block` (local, so imperceptible; avoids a visible swap, DN A4-17) |
| Interaction → visible result (check, save note, promote, filter) | < 50 ms |
| Images | `loading="lazy"`, `width`/`height` attributes from the DB, decoded off the main thread (`decoding="async"`) |
| Rendering | Incremental per zone; tag counts kept in an index updated on writes, not recomputed by scanning (DN B8) |

Static assets are served with ETags; `index.html` with `Cache-Control: no-cache`.

### Accessibility

- **Focus order** follows the reading order: masthead (nav, Notepad, Theme) → Go field, shortcuts, TAGS →
  Today (NOW/NEXT, Day, To do) → Notes (capture, slips). In notepad mode: bar → capture → tags → panel →
  notes. Rows are focusable (`tabindex=0`) only through keyboard selection rules (DN A4-18).
- Visible focus ring everywhere: 2 px accent, offset 2 (DN B2). Never `outline: none` without a replacement.
- Semantic elements: real `<a>` for links, `<button>` for word controls, `<input type=checkbox>` for to-dos,
  `aria-pressed` on toggles and filter tags, `aria-expanded` on folds and groups, `aria-live="polite"` on
  the Undo line and `Copied`.
- **Contrast:** every text token in DN B2 meets WCAG AA (≥ 4.5:1) on both `--paper` and `--slip`, in
  both themes (decided by the user, 2026-11-15). The lowest pair is `--ink3` on a slip: 4.85:1 light,
  4.87:1 dark. Any new token or text/background pair must also meet AA; check it before shipping.
- **Reduced motion:** the design has no animation (DN A4-17); additionally set `scroll-behavior: auto`
  and keep any future transition behind `prefers-reduced-motion: no-preference`.
- Theme: honour `prefers-color-scheme` when `theme='auto'`; both themes must meet the same checks.

### Security (localhost app)

| Threat | Control |
|---|---|
| Network exposure | Bind `127.0.0.1` only. Refuse to start if configured to anything else. |
| DNS rebinding | Reject (403 `bad_host`) any request whose `Host` is not exactly `127.0.0.1:<port>` or `localhost:<port>`. |
| CSRF from other sites | For every mutating request: require header `X-Desk: 1` (forces a CORS pre-flight, which the server never approves — no `Access-Control-Allow-*` headers are ever sent) **and**, if an `Origin` header is present, it must equal the app's own origin (403 `bad_origin`). Scripts that push calendar data send `X-Desk: 1` and no Origin. |
| XSS | All user text rendered via `textContent`/DOM APIs, never `innerHTML` with data. CSP: `default-src 'self'; img-src 'self' blob: data:; style-src 'self'; script-src 'self' 'sha256-<key-buffer>'; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'`. |
| Malicious links | Shortcut URLs restricted to `http`/`https`. |
| Malicious images | Magic-byte check, no SVG, `nosniff`, served from `/img/` with fixed `Content-Type`. |
| Clickjacking | `frame-ancestors 'none'` + `X-Frame-Options: DENY`. |
| Data at rest | Stored under the user's profile (`%LOCALAPPDATA%`), inheriting its ACL. No encryption in phase 1. |

### Privacy

- No telemetry, analytics, error reporting or remote fonts. The app makes no outbound requests.
- Logs (`logs/desk.log`, rotated 5 × 1 MB) record method, path, status and timing — never note text, to-do
  titles, event subjects or image content.
- Export files contain everything; Settings says so next to `Export`.

---

## 11. Acceptance criteria

Each item is a testable check (Playwright unless marked *unit*). "Seed" = `--seed-demo` data; clock control
via the dev-only `?now=HH:MM` query (enabled only with `--dev`).

### A. Launch (task 1)

- [ ] A1 Opening `http://127.0.0.1:4711/` paints masthead, Go, Today and notes in < 200 ms (warm), with the
      saved theme and no theme flash.
- [ ] A2 One click on a top-level shortcut navigates the current tab to its URL; middle-click opens a new tab.
- [ ] A3 Clicking a group name toggles it; the state survives reload.
- [ ] A4 Opening an environment records it as last used; after reload the collapsed group prints that
      environment beside its name as a direct link, and the open group marks it.
- [ ] A5 `/` from anywhere (including a selected row) focuses Go. Typing `db p` + Enter opens Databricks
      Prod; `set` + Enter opens the Settings route; `#la` filters by `lakehouse`.
- [ ] A6 Keys typed before scripts finish loading are not lost.
- [ ] A7 Day shows only events intersecting the local today; times are local 24-hour from `Z`, `+00:00`
      and 7-digit-fraction inputs alike (*unit* for parsing).
- [ ] A8 NOW/NEXT follow DN B5 (running event with time left, `+1 overlapping`, `Free … until`, `Nothing
      else today`, `Nothing scheduled today`); declined events never count as now or next.
- [ ] A9 Overlap indent, gap rows ≥ 30 min, Earlier fold, running-row bold and accent rule render per DN B3
      with the seed day at `now=08:50`, `10:50`, `13:10`, `17:30`.
- [ ] A10 Without reload, NOW/NEXT/fold update at the next minute boundary, and the day rolls at local
      midnight (fake timers).
- [ ] A11 Event crossing midnight appears on both days with real local times (*unit*).
- [ ] A12 Feed older than 120 min shows `as of HH:MM` on the Day label row in `--ink3`; fresh feed shows
      nothing there.
- [ ] A13 POST ingest and a file dropped in `calendar\inbox` both update Day within one refresh/60 s; a
      malformed file moves to `failed\` with an error file and Day keeps the previous data.
- [ ] A14 Shortcut edit: add, rename, change URL/alias, reorder by drag and Up/Down, remove + Undo; an
      alias equal to another alias or a reserved section alias (`set`) is refused with an inline message; `javascript:` URL refused.

### B. Capture (task 2)

- [ ] B1 At 480×900 the app is in notepad mode with capture focused; at 821 px it is not; the `Notepad`
      link forces it at 1440 and `Full view` returns.
- [ ] B2 With nothing focused, typing a letter starts a note in capture (home, notepad) or the masthead
      field (Settings).
- [ ] B3 Ctrl+V with an image on any route adds a 74 px thumbnail; the image is stored ≤ 1100 px wide; a
      thumbnail can be removed before saving.
- [ ] B4 Enter saves; Shift+Enter adds a line; focus stays in capture; the note appears directly under
      the slip; the draft clears.
- [ ] B5 `#token` words become tags and leave the text; an existing tag is reused, a new word creates a
      tag; Tab takes the completion offer; Enter saves as typed.
- [ ] B6 Draft text and images survive reload, route change, mode switch, and appear in a second tab of
      the same browser.
- [ ] B7 After closing and reopening the browser (and restarting the server), saved notes, images and tags
      are unchanged.
- [ ] B8 Notepad images are capped at `min(320px, 40vh)`, cropped top-left, with `cropped · open` only
      when cut; `open` shows full size; Esc closes.
- [ ] B9 A pasted non-image, an SVG, or a > 5 MB file is rejected without losing the draft text.

### C. Triage (task 3)

- [ ] C1 `To-do →` (or `t` on a selected note) creates the to-do at once: title = first sentence, tags
      copied, `@due` from the first line; the note leaves the wall; the receipt appears in place.
- [ ] C2 Receipt edits (title, Due words, tags) persist; `Undo` restores the note to its time position
      and removes the to-do.
- [ ] C3 Ctrl+Enter in capture saves directly as a to-do with the note attached.
- [ ] C4 Drag `To-do →` onto a rail tag adds that tag; onto `DUE` sets due today (desk only).
- [ ] C5 By-due ordering: late (oldest first), today, then dated by date, undated newest first; Done fold
      last.
- [ ] C6 Checking strikes the row in place for the session; after reload it is in `DONE EARLIER`;
      unchecking restores it.
- [ ] C7 Open to-do shows title, Due words (`none · today · tomorrow · Mon dd · other…`), tag editor,
      source note with images, `Return to notes`, `Delete`; Return puts the note back with its own tags.
- [ ] C8 Delete a to-do + Undo restores it and its source note.
- [ ] C9 Keyboard: ↓ selects the first to-do (first note in notepad mode); `j/k`, ←/→, `x`, Space, Enter,
      `#`, Del, `u`, Esc behave per DN B6.
- [ ] C10 Undo after the affected item changed elsewhere reports `Can't undo · changed since` (*unit* for
      409 `undo_stale`).

### D. Tags, filter, by-tag view, copy

- [ ] D1 Clicking a TAGS entry, any `#word`, a by-tag heading, or Go `#prefix` filters notes, to-dos and the
      Done fold; Day, Go and strips are unaffected.
- [ ] D2 Two tags = union worded `or`; counts `n of m` match the data; `clear` and Esc (nothing focused)
      clear it.
- [ ] D3 With exactly one tag selected, capture and Add a to-do stamp it; with two, nothing is stamped.
- [ ] D4 Items created under a filter stay visible until the filter changes.
- [ ] D5 The filter is not restored after reload; `by due · by tag` is.
- [ ] D6 By-tag view: one heading per tag in vocabulary order with counts, a multi-tag to-do under each of
      its tags, `NO TAG` last; checking one copy updates all copies.
- [ ] D7 Rename updates every note, to-do and promoted note, and the active filter follows; rename onto an
      existing tag shows `merges into #x · Enter` first and merges; remove takes the tag off every item and
      deletes no item; all three undo exactly (*unit* for link sets).
- [ ] D8 Tag editor: `word ×` removes, `add tag` with completion adds; footer reads `edit tags` when tags
      exist, `+ tag` otherwise.
- [ ] D9 `Copy` puts exactly `note.text` on the clipboard (no image, no tags), label becomes `Copied` until
      the next click or key; `c` on a selected note does the same; image-only notes have no Copy.

### E. Platform

- [ ] E1 A request with `Host: evil.example:4711` gets 403; a POST with `Origin: https://evil.example` or
      without `X-Desk` gets 403 (*unit*).
- [ ] E2 The server is not reachable on the machine's LAN address.
- [ ] E3 With the network disabled, every feature works and the browser shows no failed requests.
- [ ] E4 Export → wipe → import reproduces identical data and images (*unit*: JSON deep-equal).
- [ ] E5 A migration run creates `pre-migrate-NNNN.sqlite` first; a DB from a newer version refuses to
      start.
- [ ] E6 Orphan images older than 30 days are collected; images of soft-deleted notes are not collected
      until purge (*unit*).
- [ ] E7 Both themes pass the checks in §10 (except the token values pending Q7); with keyboard only, every
      action in DN B6 is reachable.
- [ ] E8 With the section registry empty, the shell renders nav `Today · Settings`, no strip area on home,
      and Go offers no section other than Settings. (Investments is out of scope for phase 1.)

---

## 12. Build order and open questions

### Milestones

| # | Milestone | Done when |
|---|---|---|
| M0 | Skeleton: server, Host/Origin/`X-Desk` checks, static files, CSP, migrations, tokens + self-hosted fonts, theme injection, `bootstrap`, `rev`, startup script | E1, E2, E5 pass; empty page renders in both themes |
| M1 | **Launch:** shortcuts read + Go + groups + last-used; calendar ingest (POST + folder), local-time maths, Day, NOW/NEXT, minute refresh, staleness | A1–A13 |
| M2 | **Capture:** notes CRUD, draft, image paste/upload/serve, type-anywhere + key buffer, notepad mode and forced mode, copy | B1–B9, D9 |
| M3 | **Triage:** to-dos CRUD, promote + receipt, save-as-to-do, return, due words, done fold, undo log | C1–C10 |
| M4 | **Tags:** vocabulary, token parse/echo/completion, filter + keep set, by-tag view, tag editor, rename/merge/remove | D1–D8 |
| M5 | Rare editing and admin: shortcut edit mode, Settings route, export/import, daily backup, purge, image GC, cross-tab sync | A14, E4, E6 |
| M6 | Section registry and contract, shipped empty (Investments out of scope for phase 1) | E8 |
| M7 | Hardening: full keyboard map, a11y pass, performance budget, offline check | E3, E7, budget table |

### Open questions (each has a default the implementation uses until the user decides)

| # | Question | Default |
|---|---|---|
| Q1 | Notepad image cap height (DN B9). | `min(320px, 40vh)`; anything 280–320 px or 35–40 % of the viewport is within the rule. |
| Q2 | Real calendar source (Outlook/Graph export, Power Automate, other). | Ship the POST endpoint and the drop folder with an example PowerShell script; no built-in connector. |
| Q3 | When is calendar data "stale"? | 120 min since the last ingest, or no ingest covering today. |
| Q4 | All-day / multi-day events (the feed has no all-day flag). | Events of ≥ 24 h covering the whole local day: listed first with `all day`, excluded from NOW/NEXT, gaps and overlaps. |
| Q5 | Timestamps without an offset. | Treat as UTC (real data is expected to carry `Z`/offset). |
| Q6 | Stored resolution of pasted screenshots (`open` shows full size, but the design downscales to 1100 px). | 1100 px wide per DN B5; raising it (e.g. to 2560) only changes one client constant and the size limit. |
| Q7 | ~~Text tokens below WCAG AA.~~ **Resolved (user, 2026-11-15):** tokens raised so that all text meets AA on paper and slips (see §10 and DN B2). | n/a |
| Q8 | Should `#word` typed while editing an existing note's text become a tag? | No — in-place edits are saved verbatim, as in the mockup; tags change via `edit tags`. |
| Q9 | How far back does the `DONE EARLIER` fold reach? | 30 days; older done to-dos remain in the DB and in exports. |
| Q10 | New-tab page (not just start/home page). | Out of scope; Chrome/Edge need an extension to override the new-tab page. |
| Q11 | Runtime: is Python 3.12+ acceptable on the machine? | Yes; otherwise the Node 22 variant of the same layout and contract. |
