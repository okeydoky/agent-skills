# Personal Desk — final design notes

This is the handoff for the implementation session. It is self-contained: `final/design.html` is the
interactive mockup, `final/shots/` holds verification screenshots, and this note explains both.

- **Part A** lists the design principles. Every future feature follows them, so new sections look and
  behave native without a redesign.
- **Part B** specifies the current design.

The design direction is called **Ledger**: a browser start page set like a printed ledger page, read many
times a day and operated a few times an hour.

---

# Part A — Design principles

Each rule is stated once, with a one-line reason. "Must" means a reviewer can reject a change for
breaking it.

## A1. Material

1. **The page is print; only notes have a surface.** Everything is type on paper, separated by whitespace
   and 1 px hairlines. The single exception is a note, a flat tinted slip with no border, shadow or
   radius.
   *Why:* the one thing you can pick up and move should be the one thing that looks like an object.
2. **No cards, boxes, panels or containers.** A section is a mono caps label, a hairline and rows. Never
   nest one surface in another.
   *Why:* boxes make every block look equally important, and the page stops being calm.
3. **No shadows, gradients, blur or glow, anywhere.**
   *Why:* depth implies layers, and this page has one layer.
4. **Hairlines and spacing make the structure.** Use `--line` for separators and `--line2` for emphasis
   and field underlines. Spacing is a 4 px base: 48 px between columns, 26–30 px between blocks, 10 px
   between slips.
   *Why:* one structural device, used the same way everywhere, is what makes a new part look native.

## A2. Colour

5. **One accent, one meaning: "this needs you now".** Allowed uses:
   - NOW, the clock, and the running event's rule or the now tick;
   - due and late to-dos;
   - the capture slip edge;
   - keyboard selection and a focused field's underline;
   - the receipt edge;
   - the arrow in "To-do →";
   - a drag target;
   - the chosen Due word.

   **Never accent:** links, tags, filters, headings, branding, positive or negative numbers, decoration.
   *Why:* the accent is the page's only alarm. Spend it on anything else and nothing reads as urgent.
6. **Direction is a sign, not a colour.** Gains and losses are `+0.41` / `−1.12` in ink. No red/green.
   *Why:* red already means "now"; a second colour code would compete with it.
7. **Light and dark come from one token set.** A new colour is never allowed. A new token is allowed only
   if it is defined for both themes and fits an existing role. Theme follows the OS, with a manual
   auto → light → dark toggle.
   *Why:* if something works in one theme only, the design is not finished.
8. **Pasted images are content, not chrome.** In dark mode they are dimmed to 86 % brightness and get a
   hairline edge; nothing else about them is styled.
   *Why:* foreign pixels should not out-shout the page.

## A3. Type and numbers

9. **Two faces, fixed jobs.** Instrument Sans is for everything read: titles, notes, subjects, links.
   IBM Plex Mono is for everything scanned: times, dates, figures, labels, tags, aliases, hints and key
   names.
   *Why:* the face tells you whether to read or to scan.
10. **One scale.** Mono label/hint/tag 11 · agenda 13.5 · notes and rail children 14 · to-dos and links
    14.5–15 · Now/Next 17 · headline 30. New sizes are not allowed.
    *Why:* each new size is a new level of importance.
11. **Numbers, times and dates are mono, right-aligned in columns, 24-hour, local time, and short.**
    Examples: `10:50`, `Mon 16`, `1 d late`, `184,220.14`.
    *Why:* figures in columns can be compared at a glance.
12. **Labels never wrap.** A section label is one line of mono caps. When space runs short, optional
    content gives way whole, from the right. Nothing is clipped mid-word, and a control never vanishes
    because something else grew. Variable-length state, such as a filter echo, gets its own line under
    the label.
    *Why:* a label that moves or loses a control between visits breaks muscle memory.

## A4. Controls

13. **Words, not icons.** Actions are text: `To-do →`, `Copy`, `edit tags`, `clear`, `Undo`, `Edit`,
    `Done`, `open`. Allowed glyphs: `→`, `·`, `×` (remove), `+`, `–` (expand/collapse) and `::` (drag
    handle). No icon fonts, no emoji, no favicons.
    *Why:* a word cannot be misread, and the page stays typographic.
14. **How a control looks.**
    - Secondary action: grey text with a hairline underline.
    - Primary action: ink text with an accent underline (one per context).
    - Choice among words: the chosen word is ink, weight 600 and accent-underlined; the rest are grey.
    - Toggle: the selected word is ink and underlined.
    - Removable item: `word ×`; on hover the word is struck through and the `×` turns ink.
    - Field: no box, a single underline that turns accent on focus.

    *Why:* five patterns cover every control so far; a new control must reuse one.
15. **A `#word` always filters.** Anywhere a `#tag` is printed, clicking it filters by that tag. Editing
    tags uses `edit tags` / `+ tag` and the tag editor, never the `#word`.
    *Why:* one meaning per visual form.
16. **No modals, no confirms: act, then offer Undo.** Destructive and structural actions happen
    immediately and print `… · Undo`. Editors open inline, in place, where the thing is.
    *Why:* a confirm step is ceremony; Undo is cheaper and does not break the flow.
17. **Nothing moves by itself.** No timers, toasts, auto-dismiss, animation or carousels. Feedback is a
    word that changes ("Copy" → "Copied") and stays until your next action.
    *Why:* a page you glance at all day must look the same as you left it.
18. **Keyboard parity.**
    - Every frequent action has a key and a visible hint.
    - `/` always goes to Go. Any printable key with nothing focused starts a note. Esc always backs out
      one level.
    - Selection is entered only by keyboard (↓ or Tab). While a row is selected, keys are verbs only.
    - Key hints appear only while they apply.

    *Why:* the user's hands are on the keyboard. Hints that show only in context teach without clutter.

## A5. Layout, widths and modes

19. **Four width ranges, one order of giving way.**

    | Viewport | Layout |
    |---|---|
    | ≥ 1360 | Go rail · Today · Notes, with Day and To do side by side |
    | 1200–1359 | Day stacks above To do |
    | 821–1199 | Two columns; the rail becomes lines of links above Today |
    | ≤ 820 | Notepad mode |

    Things give way in this order: Day/To do side-by-side, then the rail, then everything except capture
    and notes. Column floors: rail 160, Day 280, To do 280, Notes 340. The page reserves the scrollbar
    gutter.
    *Why:* the half-screen widths (683–960 px) are where this user lives, so each range is designed, not
    just squeezed.
20. **Notepad mode is a mode, not a stack.** The order is fixed:
    - a one-line status bar;
    - the capture slip (always first, never moves);
    - the tags line;
    - one optional panel;
    - the notes, newest first.

    Everything else is reachable in at most two actions. Images in slips are capped at
    `min(320px, 40vh)`, cropped from the top-left, and say `cropped · open` when cut.
    *Why:* beside another window, the job is writing about that window.
21. **Capture works on every route.** Typing or Ctrl+V on any page goes to the one shared note draft:
    the masthead field on desk routes, the capture slip in notepad mode.
    *Why:* a thought should never need navigation first.

## A6. Adding a section (for example Investments)

> Phase 1 ships no sections; Investments is out of scope for phase 1 and is used here only as the example.

22. **A section is a route.** It has one word in the masthead nav, an alias in Go (`inv` + Enter) and a
    line in Settings if it has settings. Home stays Go · Today · Notes.
    *Why:* a home page that grows with each feature stops being glanceable.
23. **It may place one strip on home**, under the Go + Today zones. The strip is one line, always:
    - guaranteed: label, one headline figure, one change figure, and `as of … →` pinned right;
    - further detail shows only if it fits, and drops whole from the right;
    - the whole line links to the route.

    *Why:* the home page gets a summary, not a widget.
24. **Inside its route it uses the list grammar only.** That means the 30 px headline, a mono figures
    row, and hairline-ruled tables or lists of *mono key · text · grey mono word*, with no new surface
    and no new colour.
    *Why:* that is what makes it look native without design work.
25. **It never adds its own capture.** Notes come from the global capture, and to-dos come from promoting
    notes or "Add a to-do". If its items deserve tags, it uses the one tag vocabulary and the one filter.
    *Why:* one inbox and one organising concept.
26. **In notepad mode** the section opens under the capture slip with a `← Notes` link, is listed in the
    Go panel, and its strip is hidden.
    *Why:* notepad mode stays a notepad.
27. **Empty states are one quiet sentence** in secondary ink that says what to do next, with no
    illustration and no exclamation. When a filter caused the empty state, the sentence ends with `clear`.
    *Why:* an empty state is information, not an occasion.

## A7. Don'ts (AI-slop and other tells)

- No gradient hero, glassmorphism, frosted panels, purple/indigo glow or neon.
- No "Good morning, …!" greeting, motivational copy, or headings that describe the page ("Your
  dashboard").
- No emoji, icon grids, favicon tiles, avatars or decorative illustration.
- No cards, cards in cards, pills, chips, badges, coloured tags or tinted section backgrounds.
- No drop shadows, rounded containers or floating panels.
- No KPI tiles, sparklines as decoration, donut charts or progress rings on home.
- No toasts, spinners, skeleton shimmer, auto-advancing anything or timers.
- No modal dialogs, confirmation boxes or onboarding tours.
- No hover-only primary actions. Hover may reveal secondary ones (`edit tags`, `delete`) only on desk
  layouts, and they reserve no space.
- No second accent and no colour-coded state.

## A8. Checklist a new section must pass

1. Reachable from the masthead nav and from Go by an alias, and listed in the notepad Go panel.
2. Home footprint is at most one strip line; it never wraps at 1280 and its details drop whole.
3. Its route uses only existing tokens, the type scale, mono figures and hairline rows. Nothing has a
   surface except notes.
4. The accent appears only for something that needs the user now. Numbers show direction with signs.
5. Every control is one of the five control patterns, with text not icons. Every frequent action has a
   key and a hint.
6. Nothing is confirmed in a dialog; destructive actions are undoable.
7. Typing and Ctrl+V on the route land in the note draft.
8. Any taggable items use the shared vocabulary and filter, and `#words` on them filter.
9. It works at ≥ 1360, 1200–1359, 821–1199 and in notepad mode, in light and dark, with real-length data.
   It has an empty state.
10. It has demo-state hashes and screenshots for its key states.

---

# Part B — Specification of the current design

## B1. Layout

Zones:
- **Masthead:** wordmark `Desk`, text nav (Today · Investments · Settings), a one-line note field on
  non-home routes, then `Notepad` and `Theme auto|light|dark` at the right. A hairline sits below.
- **Go** (rail): Go field, shortcuts, `Edit`, then the TAGS list and its `Edit`.
- **Today:**
  - date headline and clock;
  - NOW / NEXT sentences;
  - a hairline;
  - **Day** (agenda) and **To do**.
- **Notes:** label, filter line, capture slip, Undo line, then slips newest first.
- **Strips:** one line per section, under Go + Today.

| Range | Arrangement |
|---|---|
| ≥ 1360 | `160px · 2.2fr · minmax(340px,1.12fr)`, column gap 48, page margin 44. Day and To do side by side (`minmax(280px,1.12fr) · minmax(280px,1fr)`, gap 44). |
| 1200–1359 | As above; Day above To do (row gap 20). |
| 821–1199 | `minmax(0,1.2fr) · minmax(340px,1fr)`, gap 40, margin 28. Go becomes: Go field + wrapping shortcut links (a collapsed group shows `Name – Env •` for its last-used environment), then a wrapping tags line (`TAGS word n …  Edit  clear`), above Today. Strip under Today. |
| ≤ 820 or forced | Notepad mode, content max-width 640 (608 px measure), side padding 16. |

Fixed rules at every width:
- labels are one line;
- a note's `Copy` and `To-do →` sit on the first footer line, pinned right;
- the date headline is one line;
- a strip is one line;
- `scrollbar-gutter: stable`.

## B2. Visual tokens

| Token | Light | Dark | Role |
|---|---|---|---|
| `--paper` | `#FAFAF6` | `#121211` | page |
| `--ink` | `#171715` | `#ECEBE4` | primary text, event rules, checked boxes, selected toggles |
| `--ink2` | `#4A4A44` | `#B4B3AA` | secondary text, times, response words, Copy, filter line |
| `--ink3` | `#69685F` | `#8C8B81` | labels, hints, aliases, `#tags`, gaps, elapsed/declined |
| `--line` | `#E3E2D9` | `#2A2A27` | hairlines |
| `--line2` | `#CCCBC0` | `#3D3D38` | strong hairline, image edge, field/control underline |
| `--slip` | `#F0EFE5` | `#1E1E1B` | note surface (only surface) |
| `--slip-in` | `#E6E5DA` | `#292925` | reserved |
| `--accent` | `#B83B18` | `#FF6A3D` | needs you now |

**Contrast rule:** every text colour must meet WCAG AA (≥ 4.5:1) on both `--paper` and `--slip`, in both
themes. Current lowest pair: `--ink3` on `--slip`, 4.85:1 light and 4.87:1 dark. A new token, or text placed on a
new background, must be checked before it ships. Keep hierarchy through size, weight and mono, not through
fainter grey.

Fonts:
- `"Instrument Sans", system-ui, -apple-system, "Segoe UI", Roboto, sans-serif`;
- `"IBM Plex Mono", ui-monospace, "Cascadia Mono", Consolas, monospace`;
- both from Google Fonts; the system stack is the offline fallback.

Metrics:
- body 15/1.45;
- labels 500 11/15 mono caps, letter-spacing .09em;
- focus ring 2 px accent, offset 2;
- checkbox 15 px, radius 3;
- slip padding 11/13 (desk) and 13/16 (notepad);
- desk image cap 140 px; notepad image cap `min(320px, 40vh)`;
- capture draft thumbnail 74 px high.

## B3. Components

| Component | Notes |
|---|---|
| Label row | mono caps word left; right side holds fixed-length content only (`by due · by tag` on To do; key hints while a row is selected). |
| Filter line | Under a label while a filter is on, mono 11 `--ink2`. To do: `#lakehouse · 3 of 8 · clear`; Notes: `#lakehouse · 4 of 6 · clear`; union `#cost or #team · 2 of 6 · clear`. Built from nowrap segments; wraps only at ` or ` / ` · `; `n of m · clear` is one segment. In notepad mode, one line under the tags strip: `#cost or #team · 2 of 7 notes · 3 of 8 to-dos · clear`. |
| Agenda row | 86 px mono time column · subject (wraps, max 3 lines) · grey response word. Left 2 px rule: solid accepted/organizer, dashed tentative, dotted no reply, none + struck for declined, accent when running, `--line2` when past. Overlap: indented 14 px. |
| Gap row | `free 1 h 15 min`, mono grey, no rule, indented to the subject column. |
| Now tick | 28×2 px accent bar at the top of the list when no event is running. |
| To-do row | checkbox · title, whose last word is bound in one nowrap span with up to two `#tags` (alphabetical), then `+N` and `note + image` · due date right (mono; accent `1 d late`, bold `today`, `new` for a just-added undated one). |
| Slip | text (editable in place) · images · footer. Footer grid `1fr auto`. Left (wraps): time, `#tags`, `+ tag`/`edit tags` and `delete` (desk: shown on hover/focus only, no reserved width; notepad: always). Right (nowrap): `Copy`, `To-do →`. |
| Receipt | The slip after promote: top accent hairline, `→ TO DO · #tags`, editable title, `note + image attached`, Due words, Tags editor, `Undo`, `Close`. |
| Tag editor | Current tags as `word ×` (hover: struck word, ink ×; click removes), then an underlined `add tag` field with completion hint below. |
| Pickers | Due words: `none · today · tomorrow · Mon 16 · other…` (native date picker behind "other"). |
| Strip | one line: label (182 px) · headline figure · change · details (drop whole from right) · `as of 10:45 →`. |
| Undo line | mono `Note deleted · Undo` under the capture slip, until the next change. |

## B4. State model

Persisted (mockup: `localStorage` key `deskA.final`; theme separately as `deskA.theme`):

| Entity | Shape | Rules |
|---|---|---|
| `shortcuts[]` | `{id, n, u, a}` or group `{id, n, a, kids:[{id, n, u, a}]}` | Order is display order. `a` = alias (top level / group) or key letter (environment, default = first letter). |
| `groupsOpen` | `{groupId: bool}` | Persists. |
| `lastUsed` | `{groupId: envId}` | Updated on every open of an environment. |
| `notes[]` | `{id, ts, text, images[], tags[]}` | `text` contains no `#tags` (extracted on save). Images: data URLs in the mockup. |
| `todos[]` | `{id, title, due: 'YYYY-MM-DD'\|null, tags[], done, note?}` | `tags` is a set (order meaningless). `note` = the promoted note, intact. |
| `tags[]` | ordered `string[]` | Vocabulary; creation order = Tags list and by-tag group order. Words match `[a-z0-9_-]+`. |
| `draft` | `{text, images[]}` | Survives reload, route and mode. |
| `todoView` | `'due'\|'tag'` | Remembered preference; default `due`. |
| theme | `'auto'\|'light'\|'dark'` | Default `auto`. |

UI state, never persisted:
- `filter: string[]`, and `keep: Set<id>` for items created under the current filter (cleared when the
  filter changes);
- route, notepad panel, forced-notepad flag;
- row selection, open to-do, receipt, `copied`, tagging note, tag-edit mode and open tag;
- Earlier and Done folds;
- Undo snapshot (one level: notes, to-dos, tags, shortcuts).

Calendar events are read-only input:
`{subject, start, end, response: organizer|accepted|tentativelyAccepted|notResponded|declined}`, with
times as UTC ISO strings (`…T21:30:00.0000000Z` or `…+00:00`).

## B5. Interaction spec

### Go and shortcuts
- **Links:** one click opens. The real app navigates in place; the mockup opens a new tab.
- **Groups:** a row `Databricks –` / `Azure • Portal 3 +`. Click the name or count to expand inline; the
  open state persists.
  - Open group: environments are indented behind a hairline, and the last-used one has an ink dot.
  - Collapsed group: the last-used environment prints beside the name as a direct link.
- **Go field:** `/` from anywhere focuses it, including from a selected row.
  - Matching covers aliases, group+key (`db p` → Databricks Prod), name prefixes and substrings,
    sections (`inv`, `set`) and `#prefix` (tag filter, automatic prefix match).
  - The first hit is marked `Enter`; Enter opens it; Esc clears.
  - Aliases print in mono grey only while Go has focus.
- **Editing (rare):** `Edit` under shortcuts, or Settings.
  - The rail turns into an edit list: a `::` handle drags within a level (with an accent drop line).
  - Click a name to open Name / URL / Alias fields (a group has Name and Alias; an environment has Name,
    URL and Key), plus `Up`, `Down`, `Remove`.
  - `+ link` inside a group, `+ Add link`, `+ Add group`, `Done`.
  - Changes save as typed. Remove is undoable.

### Day
- **NOW** shows the running event, `until 11:30 · 40 min left`, plus `· +1 overlapping` if there is
  one. With nothing running it shows `Free` and `until 12:00 · 10 min`. After the last event it says
  `Nothing else today`; with no events, `Nothing scheduled today`.
- **NEXT** shows `12:00 subject in 1 h 10 min · tentative`. Declined events never count as now or next.
  These two lines never truncate.
- **Local time:** parse UTC strings, normalise the 7-digit fraction to 3, and display local 24-hour
  time. "Today" is the local date.
- **Agenda:** elapsed events fold into `EARLIER · n +`, collapsed by default and expanding in place with
  dimmed rows. Then upcoming events in start order:
  - declined events stay in place and are ignored for overlaps and gaps;
  - an overlap is indented one step;
  - a gap of 30 min or more prints a gap row;
  - the running event has an accent rule and a bold subject;
  - with nothing running, the now tick sits at the top and the first gap is counted from now.
- **Empty day:** `No events. The day is yours.`

### Capture
- The capture slip is always first in Notes. Enter saves; Shift+Enter adds a line; Ctrl+Enter saves as a
  to-do (title = first sentence, `@due` applies). Focus stays in the field. The saved note appears
  directly under the slip.
- **Type anywhere:** with nothing focused and no row selected, a printable key focuses capture and lands
  in it. On Investments and Settings it lands in the masthead field, which prints
  `Saved to notes · Undo` after Enter.
- **Paste:** Ctrl+V with an image, on any route, adds it to the draft as a removable 74 px thumbnail
  (downscaled to 1100 px wide). A text paste behaves normally.
- **Tokens:**
  - `#word` becomes a tag and is removed from the text. An exact match uses the existing tag; otherwise
    the word is saved as typed, creating the tag.
  - `@due` is read only for a to-do: `today`, `tom`, a weekday prefix of three letters or more, `+3`, a
    day number or an ISO date.
- **Completion offer:** while the caret ends a `#word` that is a proper prefix of existing tags, the hint
  shows up to three, most-used first: `#la → lakehouse · Tab`. Tab takes the first. Tab is intercepted
  only while an offer shows; there is no cycling.
- **Hint line:**
  - At rest: `Enter saves · #tag · Ctrl+V image`, or `Enter saves with #x` under a one-tag filter.
  - With content: the parse echo on its own full-width line, then `Save as to-do` / `Save note` below.
    Echo segments: `#la → lakehouse · Tab`, `new tag #runbook` (prefixed `Enter:` when an offer shows),
    `saves with #lakehouse`, `as to-do: due Mon 16`. No key names; an empty echo takes no line.

### Notes
- One column, strictly newest first, at every width. Text is edited in place (saved on blur).
- **Images:**
  - Desk: full slip width, capped at 140 px, cropped top-left.
  - Notepad: capped at `min(320px, 40vh)`, plus a mono `cropped · open` line only when the image is
    actually cut.
  - A click on the image, or `open`, shows it full size; click or Esc closes.
- **Copy:** copies `note.text` only and changes to `Copied` until the next click or key. `c` on a
  selected note does the same. Image-only notes have no Copy.
- **Promote:** `To-do →` or `t` creates the to-do at once, and the slip becomes the receipt in place.
  - The to-do gets the first sentence as title, the note's tags, `@due` from the note's first line, and
    the whole note.
  - Ignoring the receipt is fine; it stays until the next wall action, `Close` or leaving the page.
  - Drag `To-do →` onto a tag in the rail to promote and add that tag, or onto the `DUE` heading to make
    it due today. This is desk only, and the target gets an accent underline.
- **Delete:** `delete`, or Del on a selected note, removes it at once and offers `Note deleted · Undo`.
- **Undo:** one level, available via `u`, the receipt or the Undo line.
- **Return to notes:** from an open to-do; puts the note back in its time position with its tags.

### To-dos
- **Add a to-do:** a field at the top of the list. Accepts `#tag @due` with the same echo and completion.
  Enter adds; an added undated to-do shows `new` until the next render cycle.
- **By due (default):**
  - `DUE` holds late items (oldest first), then today's;
  - `LATER` holds dated items by date, then undated, newest first;
  - then `DONE EARLIER · n +`.
- **By tag:** switch with `by due · by tag` on the label; the choice is remembered.
  - One heading per tag, in vocabulary order, with a grey count. A multi-tag to-do is listed under every
    one of its tags, and `NO TAG` comes last.
  - Due order inside each group. Late and today keep their accent and bold. A heading is a filter link.
  - Every copy of a row is one item: checking, editing or deleting one updates all. Inline detail opens
    under the first copy.
  - `DONE EARLIER` stays one flat fold.
- **Check:** the checkbox, `x` or Space strikes the row in place for the session. On the next load it
  folds into `DONE EARLIER`. Unchecking restores it.
- **Open:** click the title, or Enter. Shows an editable title, Due words, the tag editor, the source note
  with its images, `Return to notes`, `Delete` (undoable) and `Close`.

### Tags and filter
- One vocabulary for notes and to-dos. Tags never group the default list. In by-tag view they group with
  a to-do repeated under each of its tags.
- **Filter control:** the TAGS list (desk rail; a line at 821–1199; a strip under capture in notepad
  mode), plus any `#word`, any by-tag heading, and Go `#prefix`.
  - Click toggles a tag. `clear`, or Esc with nothing focused, removes all. The filter applies to notes,
    to-dos and the Done fold. Day, Go and strips are untouched.
- **One tag selected = a context.** Capture and "Add a to-do" stamp that tag.
- **Two or more = a union query.** It is worded with "or" and stamps nothing.
- **Visibility rule:** anything created or promoted under a filter stays shown until the filter changes.
- **By tag under a filter:** a shown to-do is listed under the selected tags it carries; a kept item
  without any selected tag goes under its own tags.
- **Notepad bar:** while filtered, `To do · 1 of 3 due` (filtered of global); otherwise `To do · 3 due`
  (or `To do · 8` when nothing is due).
- **Empty result:** `No notes tagged #x · clear` / `No to-dos tagged #x · clear`.
- **Editing an item's tags:**
  - Note: `+ tag` (no tags) or `edit tags` (has tags), or `#` on a selected slip.
  - Receipt and open to-do: the Tags row; `#` on a selected to-do opens it there.
  - Editor: `word ×` to remove, then the `add tag` field with completion (Tab), Enter to add and stay,
    Esc or `Done` to close.
- **Rename and remove (rare):** `Edit` under the TAGS list, or Settings › Tags.
  - Each tag becomes a dashed-underline name with a count. Click it to get a Name field, a usage line
    (`on 2 notes, 1 to-do`) and `Remove tag`.
  - Rename: Enter or blur. It updates every note, to-do and promoted note, and the active filter follows.
    Renaming to an existing tag **merges** them; the usage line warns `merges into #cost · Enter` first.
  - Remove: takes the tag off every item; no item is deleted.
  - Both are undoable. `Done` returns to filter mode.

### Notepad mode
- It starts automatically at ≤ 820 px. The `Notepad` link forces it at any width, and the bar then shows
  `Full view`.
- **Bar** (sticky, one line):
  - accent clock;
  - `until 11:30 · next 12:00 subject` (only the subject truncates; clicking it opens the Day panel);
  - `To do · 3 due` (To do panel);
  - `Go` (shortcuts, routes, theme, tag edit).
  - The toggles are underlined text; an open one is ink.
- Then, in order: the capture slip (auto-focused on entering the mode), the tags strip plus filter line,
  one panel, and the notes.
- Everything else works the same: promote, receipt, copy, tags, keyboard, Undo, by-tag. Routes open under
  the capture slip with a `← Notes` link.

### Investments (stub)
> **Out of scope for phase 1.** Removed from the mockup (`design.html`) and the spec (`app-spec.md`). Kept
> here only as the reference design for a later phase.

- **Route:**
  - headline;
  - `Sample data · prices as of 10:45`;
  - a figures row (Value, Today, Year to date, a 30-day ink line whose last point is accent);
  - a hairline table (Holding · Units · Price · Today · Value · Weight), with Units and Weight hidden in
    notepad mode.
- **Strip on home:** `INVESTMENTS  184,220.14  today +0.62%  VTI +0.41  VXUS +0.87  MSFT −1.12  BND +0.08
  as of 10:45 →`. Tickers drop whole from the right.
- Reachable with `inv` in Go.

### Settings (stub)
Live: theme, `Edit shortcuts, groups and aliases`, `Rename or remove tags`, reset. Described only:
calendar source, clock, the Enter-in-a-note preference, the notepad breakpoint. A keyboard reference
table is included.

## B6. Keyboard map

| Key | Where | Action |
|---|---|---|
| any printable key | nothing focused, no row selected | start a note (lands in capture / masthead field) |
| `/` | anywhere, incl. a selected row | focus Go |
| Enter · Shift+Enter · Ctrl+Enter | capture | save note · new line · save as to-do |
| Ctrl+V (image) | anywhere | add screenshot to the draft |
| Tab | capture, add-to-do, tag field, while an offer shows | take the tag offer |
| Enter · Esc | Go | open first hit · clear |
| ↓ | nothing focused / empty capture / empty add field | select first to-do (first note in notepad mode) |
| `j` `k` ↑ ↓ | selected row | move |
| ← → | selected row | switch between to-dos and notes |
| `x` · Space | selected to-do | done / undone |
| Enter · `#` · Del | selected to-do | open · open at tags · delete |
| `t` · `c` · `#` · Enter · Del | selected note | to-do · copy text · tags · edit text · delete |
| `u` | selected row | undo |
| Esc | field → row → nothing; with nothing focused | back out one level; clear tag filter |

## B7. Demo states (URL hash)

The hash combines with `&`. Any `state=` boots from fresh seed data and writes nothing. Without `state=`,
data persists; `reset=1` reseeds. The demo clock is pinned to Friday 13 November 2026, 10:50 local
(`now=HH:MM` moves it).

| Hash | Shows |
|---|---|
| `state=home` | default desk (an event running, a portrait screenshot note on top) |
| `state=home&now=08:50` · `now=13:10` · `now=17:30` | full morning (all events, overlap, gaps) · in a gap (tick) · after the last event |
| `state=earlier` | Earlier fold open |
| `state=filter` · `filter-long` · `filter-long-tag` | `#lakehouse` filter · same · same in by-tag view |
| `state=filter-two` · `filter-two-np` | `#cost or #team` (use `filter-two-np` at notepad widths) |
| `state=footer-check` · `footer-hover` | `#prod` filter: two- and three-tag older notes on top · with hover controls |
| `state=by-tag` · `by-tag-filter` · `by-tag-done` | by-tag view · under `#prod` · a two-tag to-do checked in both groups |
| `state=draft` · `tag-complete` · `tag-new` | capture with tokens and image · `#la` offer · new tag |
| `state=tagging` · `tags-edit` | tag editor on a note (× hover shown) · TAGS list in rename/remove mode |
| `state=copied` | `Copied` in a footer |
| `state=receipt` · `receipt-filled` · `promoted` · `todo-open` | promote flow · open to-do with its source note |
| `state=cursor-todo` · `cursor-note` | keyboard selection with hints |
| `state=token` · `drag` | add-to-do echo · rail tag as drop target |
| `state=note-deleted` · `done` | Undo line · to-dos checked in place |
| `state=group-open` · `go-focus` · `go` · `go-section` | groups · aliases · `db p` · `inv` |
| `state=edit-shortcuts` | rail edit mode |
| `state=empty-day` · `no-notes` · `no-todos` · `empty-all` | empty states |
| `state=route-capture` | Investments with a note in the masthead field |
| `route=investments` · `route=settings` | routes |
| `theme=light\|dark` · `mode=notepad` · `panel=day\|todos\|go` | theme · forced notepad · notepad panel |

Verification shots in `final/shots/`:
- `home-1440`, `notepad-480` (light and dark);
- `r3-01-filter-by-due|by-tag-{1440,1425,1280,960}`, `r3-01-filter-two-1440`;
- `r3-02-tall-shot-{700,480}`;
- `r3-03-tag-editor-1440`, `r3-03-receipt-1440`;
- `r3-04-notepad-filter-two-520`.

## B8. Mockup shortcuts the real app must do differently

- **Persistence:** the mockup uses `localStorage`, with images as JPEG data URLs. The app should store
  notes and to-dos in a local store (SQLite or IndexedDB) and images as files or blobs.
- **Calendar:** in-memory sample events. The app reads the events feed (UTC with offset) and re-renders
  NOW/NEXT, the fold, gaps and the tick every minute and when the date changes.
- **Clock:** pinned in the mockup; real time in the app.
- **Shortcut links:** open in a new tab in the mockup; the app navigates in place, since it is the start
  page. Middle-click still opens a new tab.
- **Clipboard:** the mockup uses `navigator.clipboard.writeText` with an `execCommand` fallback for
  `file://`. The app is served from localhost and needs only the first.
- **Undo:** a single whole-state snapshot in the mockup; the app should store an inverse operation.
- **Rendering:** the mockup re-renders everything per change; the app should render incrementally. Tag
  counts should be indexed once data grows.
- **Drag to file:** native HTML drag and drop; the drop states in the shots are simulated.
- **Fonts:** Google Fonts with a system fallback. The app should self-host both faces, since it is a
  local app that may run offline.
- **Settings:** calendar source, clock format and the Enter preference are described only; investments
  data is static.
- **Screenshots:** headless shots at 480 and 520 px use a wider iframe cropped to width, so the reserved
  scrollbar gutter is off-picture.

## B9. Open question

- **Notepad image cap height.** The default is `min(320px, 40vh)`; anything between 35–40 % of the
  viewport or 280–320 px is within the rule. Adjust after living with real split-screen captures.

---

## Changes from round 3

| Item | Change |
|---|---|
| R3-01 view switch hidden under a filter | Label row holds fixed content only (`by due · by tag` or key hints); filter echo moved to its own line under the label in both columns. |
| R3-02 tall screenshots in notepad mode | Notepad images capped at `min(320px, 40vh)`, top-left crop, `cropped · open` when cut; portrait seed screenshot added (note at 10:31). Replaces the earlier "uncapped in notepad" rule. |
| R3-03 removing a tag | Tag editors show `word ×` (hover: struck word, ink ×); footer word reads `edit tags` when tags exist, `+ tag` otherwise. Footer `#tags` still filter. |
| R3-04 notepad filter scope | Same filter-echo component under the tags strip (`… · 2 of 7 notes · 3 of 8 to-dos · clear`); bar reads `To do · 1 of 3 due` while filtered. |
| Tag field | No completion offer is shown while the add-tag field is empty. |
