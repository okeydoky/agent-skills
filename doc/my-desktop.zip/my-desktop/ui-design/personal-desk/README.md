# Personal Desk: UI design handoff

A local personal-productivity start page: shortcuts, the day's calendar, to-dos, a post-it note wall,
and a notepad mode for narrow split-screen windows. It is designed to grow new sections, Investments
first.

## Start here (implementation session)

| File | What it is |
|---|---|
| [final/design.html](final/design.html) | The interactive mockup. Open it in Chrome or Edge, and resize the window below 820 px for notepad mode. Demo states boot from the URL hash (see design-notes, Part B). |
| [final/design-notes.md](final/design-notes.md) | **Part A, Design principles:** the rules every future feature must follow, with a checklist for new sections. **Part B, Spec of the current design:** layout and width ranges, tokens for both themes, components, state model, interactions, keyboard map, and mockup shortcuts. |
| [final/app-spec.md](final/app-spec.md) | The application spec: stack, data model, persistence, local API, calendar ingestion, extensibility contract, security, acceptance criteria, and build order. |
| [final/shots/](final/shots/) | Key screenshots in light and dark, at the main widths and in notepad mode. |
| [brief.md](brief.md) | Requirements (including Addendum 1: tags, copy, app spec), the top 3 tasks, and the rubric. |
| [decision-log.md](decision-log.md) | Every decision and why. Settled points should not be reopened without new evidence. |

Key shots: `final/shots/home-1440-light.png`, `home-1440-dark.png`, `notepad-480-light.png`,
`notepad-480-dark.png`, `r3-01-filter-by-tag-1440-light.png`, `r3-02-tall-shot-700-light.png`.

## How the design was reached

| Phase / round | Findings (high / med / low) | Verdict summary | Outcome |
|---|---|---|---|
| Phase 1: diverge | n/a | Three directions: A "Ledger" (calm typographic columns), B "Console" (keyboard-first omnibar), C "Desk" (notes board with side panel). | 3 concept mockups |
| Phase 2: select | n/a | A 84.25, B 79.50, C 70.25. **Ledger won** on calm, hierarchy and aesthetics; its keyboard weakness was fixed by grafts from B. | Grafts from B (aliases, tokens, keyboard verbs) and C (instant promote with Undo, Earlier fold, capture on every route) |
| Round 1 | 0 / 5 / 3 | All accepted. Proportional timeline replaced by one agenda list everywhere (bold alternative). Notepad at 820 px and below, with designed mid range. Note wall is one newest-first column. | Round 2 |
| Round 2 (+ Addendum 1) | 0 / 3 / 5 | All accepted. Tags replace projects. To-do list is flat (Due / Later / Done) and tags filter. Note footer is fixed. | Round 3 |
| Round 3 | 0 / 2 / 2 | All accepted (designer's fixes). The by-tag switch stays visible under a filter, and notepad images are capped. | **Stop: max 3 rounds.** Fixes applied once in `final/` without further review |

## Decisions the user made

- Light and dark themes. Notes are separate post-its. To-dos have an optional due date. Calendar data is UTC and shown in local time.
- Tags on notes and to-dos with a filter, plus one-click copy of note text (Addendum 1).
- The running event's row is bold.
- The "by tag" to-do view is included: a to-do appears under each of its tags.

## Open questions (user call)

- **Notepad screenshot cap height.** The default is `min(320px, 40vh)`, with a `cropped · open` line when an image is cut.
- The calendar source (how events reach the app) is still undecided. The app spec defines a pluggable ingestion interface.
- App-level questions are listed with their defaults in `final/app-spec.md` §12. Examples are the stack (Python
  stdlib + SQLite, with Node as fallback), calendar staleness and all-day events.
- Contrast is resolved: all text tokens now meet WCAG AA on paper and on note slips, in both themes.

## Optional polish backlog

None outstanding. Every accepted low finding was applied in the following round or in `final/`.

## Not verified

- Real clipboard copy, real Ctrl+V image paste, and native drag of a note onto a tag were not exercised by
  hand. They were checked through demo states and scripts.
- The round-3 fixes in `final/` were checked by the designer's screenshots only, with no independent review.
- Narrow (480 px) shots were rendered through an iframe wrapper, because headless Edge cannot go narrower than about 500 px.

## Folder map

`phase1-diverge/` (3 directions) → `phase2-select/selection.md` → `round-1..3/` (each holds design, notes,
shots, review, blind findings, designer response and verdict) → `final/`.
