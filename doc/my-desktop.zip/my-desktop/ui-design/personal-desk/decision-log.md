# Decision log — Personal Desk

Append-only ledger. Settled points must not be re-raised without concrete new evidence.

## Phase 0 — Intake (2026-11-14), decided by the user

- Theme: light + dark, following the OS, one token set.
- Notes: separate post-it cards (not one continuous pad).
- Todos: text + optional due date + optional project grouping. No priority/tags/sub-tasks.
- Calendar: real data is UTC with timezone; always displayed in local time.

## Phase 2 — Selection (see phase2-select/selection.md)

- Winner: **Direction A "Ledger"** (84.25) over B "Console" (79.50) and C "Desk" (70.25).
- Known weakness accepted with the pick: A is keyboard-light; the grafts from B address it.
- Accepted grafts from B: aliases and group-scoped typing in Go (`db p` Enter); last-used environment
  marker; keyboard triage verbs on a focused row; `#project @due` tokens plus Ctrl+Enter to save as
  to-do; sections as launch targets; words ("note + image") instead of the slip glyph.
- Accepted grafts from C: instant promote with in-place receipt and Undo; fold past events into
  "Earlier · N"; capture available on every route; optional drag of a note onto a project heading.
- Drop/change in A: slip glyph; promote-form explainer sentence; declined events taking an overlap
  column; fixed 08–18 timeline; notepad panels pushing capture down; "delete" beside "To-do →".

## Round 1 — verdict (see round-1/verdict.md). 0 high, 5 medium accepted -> round 2 required

- R1-01 (medium) ACCEPTED: overlap truncation resolved by adopting the agenda list (R1-08). Patching the
  proportional timeline is REJECTED.
- R1-02 (medium) ACCEPTED merged: notepad mode at <= 820 px; 821-1199 is a designed two-column layout with
  the rail collapsed to Go plus a link line.
- R1-03 (medium) ACCEPTED merged: notes wall is ONE column, strictly newest first; screenshots full-width,
  capped at ~140 px. A side thumbnail is REJECTED.
- R1-04 (medium) ACCEPTED merged: labels never wrap; "To-do ->" stays inside the slip; Day stacks above
  To do at 1200-1359 and sits beside it from 1360.
- R1-05 (low) ACCEPTED merged: `/` always goes to Go; row selection is keyboard-entered only; verbs only
  while selected; Esc exits.
- R1-06 (low) ACCEPTED designer's fix: declined events in chronological place; time printed once.
- R1-07 (low) ACCEPTED merged: "To do · 3 due", underlined toggles, "Full view" link when notepad is forced.
- R1-08 (medium, bold alternative) ACCEPTED merged: agenda list is the only calendar rendering, with
  Earlier fold, free-gap rows and overlap shown by indent. The proportional timeline is SETTLED as dropped.
- USER CALL (open): whether the running event's row is bold. Default: bold (designer).
- USER CALL RESOLVED (2026-11-15, by the user): the running event's row stays **bold**. Settled.

## Addendum 1 — new requirements from the user (2026-11-15, mid round 2; see brief.md Addendum 1)

- Tags on notes and to-dos with a tag filter; may replace project grouping (designer decides, justified).
  This supersedes the Phase 0 "no tags" decision.
- One-click copy of a note's text (text only, no image).
- Handoff must include an app spec document alongside the UI design.
- Folded into round 2 before its review, so the round 2 reviewer judges against the amended brief.

## Round 2 — verdict (see round-2/verdict.md). 0 high, 3 medium accepted -> round 3 required (last round)

- Designer decision in round 2: tags REPLACE projects (one organising concept). Settled.
- R2-01 (medium) ACCEPTED merged: two-cell note footer with Copy / To-do -> pinned right; hover controls
  take no width; `scrollbar-gutter: stable`.
- R2-02 (medium) ACCEPTED, resolved by R2-08: the hidden "first tag" grouping rule is REMOVED.
- R2-03 (low) ACCEPTED merged: multi-tag filter is a union worded "or"; a tag is stamped on capture only
  when exactly one is selected; items created under a filter stay shown until it changes.
- R2-04 (low) ACCEPTED merged: parse echo on its own line above the actions, nowrap segments.
- R2-05 (low) ACCEPTED merged: tags bound to the title's last word; at most two, then "+N".
- R2-06 (low) ACCEPTED designer's fix, simplified: Tab accepts a completion, Enter saves as typed.
- R2-07 (low) ACCEPTED merged: Investments strip is always one line; whole tickers drop from the right.
- R2-08 (medium, bold alternative) ACCEPTED merged: to-do list is FLAT — DUE, then LATER (dated, then
  undated), then the Done fold. Tags are a set and are filter only. Grouping to-dos under tag headings
  is SETTLED as dropped.
- USER CALL (open): optional "by due · by tag" view of to-dos. Default: leave it out.
- USER CALL RESOLVED (2026-11-15, by the user): INCLUDE the optional "by tag" view of to-dos, in which a
  to-do with several tags appears under EACH of its tags. The flat Due/Later list stays the default view;
  "by tag" is a switch. Settled.
- Clarification (round 2 era): the round-1 verdict (section C) specified UNCAPPED screenshots in notepad
  mode; that clause was missing from this log. It is SUPERSEDED by R3-02 below.

## Round 3 — verdict (see round-3/verdict.md). 0 high, 2 medium accepted. STOP: max_rounds (3) reached.

- R3-01 (medium) ACCEPTED designer's fix: `TO DO` + `by due · by tag` on a one-line label row; filter echo
  on its own line underneath.
- R3-02 (medium) ACCEPTED designer's fix: notepad screenshots capped at `min(320px, 40vh)`, with a
  `cropped · open` line only when cropped. USER CALL (open): the cap height; default `min(320px, 40vh)`.
- R3-03 (low) ACCEPTED: tag editor shows `tag ×`; footer reads "edit tags" when the item has tags.
- R3-04 (low) ACCEPTED: same filter line in notepad mode; bar reads `To do · 1 of 3 due` while filtering.
- Orchestrator decision: because the accepted fixes are small and would otherwise mislead the
  implementer, they are applied once during Phase 4 consolidation into final/, without a further review.

## Post-handoff (2026-11-15), decided by the user

- Contrast: all text tokens must meet WCAG AA (>= 4.5:1) on --paper and --slip in both themes. New values:
  light --ink2 #4A4A44, --ink3 #69685F, --accent #B83B18; dark --ink2 #B4B3AA, --ink3 #8C8B81 (dark accent
  unchanged). Applied in final/design.html, design-notes B2 and app-spec §10/Q7.
