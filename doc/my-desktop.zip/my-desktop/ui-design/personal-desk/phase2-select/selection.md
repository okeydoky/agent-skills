# Phase 2 — Selection

Selector: neutral, no stake in any direction. Judged against the fixed rubric in `brief.md`.

**Winner: Direction A — "Ledger"** (84.3 / 100). B "Console" 79.5. C "Desk" 70.3.

## What was reviewed

- All 43 screenshots in the three `shots/` folders (A 15, B 13, C 15) and all three `design-notes.md`.
- Seven extra states rendered from the mockups with headless Edge at 1440×900, where the supplied shots left a
  flow unclear: A `todo-open`, A `edit-shortcuts`, B `list`, B `empty-day`, B `pad=1&tab=day`,
  B `pad=1&tab=links`, C `edit-shortcuts`.
  Saved in `C:\Users\19736\AppData\Local\Temp\claude\807056f5600cc8da\9e9d5755-1a61-424d-b855-850c9db3ccd6\scratchpad\selector`.
- Not reviewed: a stray file `direction-A\shots$1.png` that sits beside (not inside) A's `shots` folder. It looks
  like a mis-named leftover from the designer's capture script, not a deliverable.
- Scores rest on what the screenshots show. Where a claim in the notes could not be seen (for example A's
  "type anywhere starts a note", B's `db p` parsing, C's digit-key launch), it was credited as design intent
  only, not as demonstrated.

## Scores

Score 0–10 per criterion; weighted = score × weight ÷ 10.

| # | Criterion | Wt | A Ledger | B Console | C Desk |
|---|---|---|---|---|---|
| 1 | Task-flow efficiency | 25 | 8.0 → 20.0 | 9.0 → 22.5 | 7.0 → 17.5 |
| 2 | Notepad mode & capture | 20 | 8.5 → 17.0 | 8.0 → 16.0 | 8.0 → 16.0 |
| 3 | Visual hierarchy & calm | 15 | 9.0 → 13.5 | 6.5 → 9.75 | 6.5 → 9.75 |
| 4 | Aesthetic restraint & distinctiveness | 15 | 9.0 → 13.5 | 7.5 → 11.25 | 6.0 → 9.0 |
| 5 | Extensibility | 15 | 8.0 → 12.0 | 8.5 → 12.75 | 7.0 → 10.5 |
| 6 | Discoverability | 5 | 8.0 → 4.0 | 8.0 → 4.0 | 8.0 → 4.0 |
| 7 | Implementation feasibility | 5 | 8.5 → 4.25 | 6.5 → 3.25 | 7.0 → 3.5 |
| | **Weighted total** | 100 | **84.25** | **79.50** | **70.25** |

### Justifications

**1. Task-flow efficiency (25)**
- **A — 8.0.** The Now/Next sentence answers "what's my day" without decoding anything, every shortcut is on
  screen, a persisted-open group makes an environment one click, and `/prod` + Enter is the keyboard path.
  Promote is click + Enter. Loses points because triage has no keyboard path and promote always passes through
  a form.
- **B — 9.0.** Fastest of the three: environments are always visible one-click targets with nothing to expand,
  `db p` + Enter launches from an already-focused field, `t` + Enter promotes, `x` checks off. The cost is an
  overloaded field where a short note can collide with an alias, and a single-line omnibar is a cramped place
  to write a note in the full view.
- **C — 7.0.** One-click instant promote is the best promote of the three, and digit keys are a good idea. But
  a group environment needs a popover first, the day is pushed into a side rail, and overdue/today todos are
  scattered inside project groups, half of them below the fold at 1440×900.

**2. Notepad mode & capture (20)**
- **A — 8.5.** Reads as a different page, not a stack: a one-line status bar (time left, next event, due
  count, Go), a large capture slip, then a full-width stream. Promote opens inside the slip and the draft
  survives the mode switch. Weakness: opening the To do or Day panel pushes the capture slip far down the
  screen.
- **B — 8.0.** Purpose-built too: tall capture field, attached-screenshot tray with a clear "save note with 1
  screenshot" intent, next event in the header. The four-tab row makes it feel like a small app rather than a
  notepad, and the keycap hints add clutter in a narrow column.
- **C — 8.0.** Largest, most readable screenshots and a quiet bottom peek bar. Promote turns the note into an
  in-place receipt with no dialog, which is excellent. Capture needs Ctrl+Enter, and the rail slides over the
  notes rather than sitting with them.

**3. Visual hierarchy & calm (15)**
- **A — 9.0.** The eye goes date → Now/Next → Due group, in that order, and accent is used only for "needs you
  now". Hairlines and whitespace, nothing boxed. Timeline text at 12.5 px is on the small side.
- **B — 6.5.** The glance box does land, but it competes with an intent line, a shortcut strip, three pane
  digests, keycaps on every note and a status bar. Dense and mono-heavy for a page that is looked at all day.
- **C — 6.5.** The first thing seen on the start page is two large screenshots from old notes. The current
  event is clear once the eye reaches the rail, but what is due is not gathered anywhere.

**4. Aesthetic restraint & distinctiveness (15)**
- **A — 9.0.** A clear point of view ("the page is print; only notes are objects"), held consistently in both
  themes and on the investments route. No slop tells.
- **B — 7.5.** A real point of view (terminal instrument panel) and disciplined colour. Keycap chrome and pill
  chips in the promote form make it busier than "minimal" implies.
- **C — 6.0.** Competent but familiar: bordered cards on a tinted board, pill chips, a green accent. The serif
  for "your words" is a nice touch; the investments full page uses card panels, which edges toward the
  dashboard-template look the brief rules out.

**5. Extensibility (15)**
- **A — 8.0.** Six short rules: a section is a route plus one nav word plus at most one strip line on home.
  The investments route looks native. The strip sits below the fold on a normal day (only visible in the
  empty-day shot), and a text nav holds only a handful of sections.
- **B — 8.5.** The most systematic: a section registers a name, alias and number key and is made of panes
  (label + digest + rows). Investments is built from the same parts and is reachable from the omnibar.
- **C — 7.0.** A section is a rail tab, with an optional full page. Opening the Investments tab hides Today,
  rail tabs run out of room quickly, and the full page introduces a second visual pattern.

**6. Discoverability (5)**
- **A — 8.0.** "To-do →" is printed on every slip, the capture slip states "Enter saves · Ctrl+V pastes a
  screenshot", groups show `3 +`. Type-anywhere is hidden but harmless.
- **B — 8.0.** Every key is labelled next to a clickable equivalent and the intent line says what Enter will
  do. The omnibar concept itself has to be learned first.
- **C — 8.0.** "Add to todos" is always visible, chevrons mark groups, and a hint line under the board explains
  drag and keys.

**7. Implementation feasibility (5)**
- **A — 8.5.** Plain layout, lists and inline forms. The proportional timeline with offset overlaps is the
  only fiddly part.
- **B — 6.5.** Omnibar grammar, alias disambiguation, a modal TYPE/LIST keyboard model and always-on focus
  management are a lot of edge cases for one developer.
- **C — 7.0.** Custom pointer-event drag with folding drop zones, a masonry board of contenteditable notes and
  hover popovers are each manageable but collectively fragile.

## Decision

**A "Ledger" wins.** It leads on the two 15-point visual criteria by a wide margin and is first or level on
notepad mode, discoverability and feasibility, which more than offsets B's lead on raw task speed. The
deciding observation is that this page is looked at far more often than it is operated: A is the only
direction where a glance returns the current meeting, the next one and what is due without reading a grid or
a rail, and it does so with the most restrained and most recognisable visual system. Its weaknesses
(keyboard-light triage, a form on every promote, a space-hungry timeline) are additive fixes that do not
disturb its core rule.

**Strongest argument against the pick:** the user is a data engineer whose hands are on the keyboard, and
Launch is the most frequent action. B is measurably faster there (environments always one click, alias +
Enter from a field that is already focused) and it is the only direction with a complete keyboard path
through triage. If speed of operation mattered more than calm of reading, B would win; A as submitted asks
this user to reach for the mouse for everything except filtering links. The graft list below exists largely
to close that gap.

## Graft list — bring into A

Ordered by value. Each item states the reason and how it fits without breaking "the page is print; only notes
are objects".

### From B "Console"

1. **Aliases and group-scoped typing in Go** (`db` Enter → last-used environment, `db p` Enter → Prod).
   *Why:* closes most of B's speed lead on the most frequent action.
   *Fit:* Go already has a filter field; aliases appear as small mono grey prefixes only while Go is focused,
   so the resting rail stays plain text.
2. **Last-used environment marker on groups.**
   *Why:* makes "open Databricks" a single Enter or click for the usual case.
   *Fit:* a single ink dot beside the environment; no new colour.
3. **Keyboard triage verbs on a focused row** (`j/k` move, `t` note → to-do, `x` done, `u` undo).
   *Why:* A has no keyboard path for the Triage task.
   *Fit:* verbs act only when a slip or to-do row has focus (entered with ↓ or Esc), so they do not collide
   with A's type-anywhere capture. The cursor is an accent hairline, not a filled row; no status bar is added.
4. **`#project @due` tokens in "Add a to-do", and Ctrl+Enter in capture to save as a to-do.**
   *Why:* a to-do with date and project in one line, without opening pickers.
   *Fit:* parsed result is previewed in mono grey under the line, in the same style as existing hints.
5. **Sections are launch targets** (`inv` Enter opens Investments from Go).
   *Why:* gives every future section a keyboard home for free.
   *Fit:* one line added to A's extensibility rule 1; nothing visual changes.
6. **Words instead of the slip glyph on promoted to-dos** ("note + image").
   *Why:* A's small grey square is unreadable as "has a source note".
   *Fit:* mono grey text is already A's vocabulary for metadata.

### From C "Desk"

7. **Instant promote with an in-place receipt.** "To-do →" creates the to-do immediately; the slip becomes a
   receipt offering Due, Project and Undo, and ignoring it is a valid finish.
   *Why:* one action instead of click + Enter, and it works identically in notepad mode where the list is
   hidden (this answers A's own stated reason for rejecting instant promote).
   *Fit:* the receipt uses A's word-pickers on the slip surface, not C's pills or green fill.
8. **Fold elapsed events into one "Earlier · 3" line.**
   *Why:* A's 08–18 timeline spends a third of its height on the past and pushes the investments strip below
   the fold.
   *Fit:* one grey mono line at the top of Day, expandable; the proportional timeline starts near now.
9. **Capture works on every route** (Ctrl+V or typing on Investments lands in the notes draft).
   *Why:* both losing directions do this; A only implies it.
   *Fit:* behaviour only, plus a "saved to notes" line in the masthead on routes without the wall.
10. **Optional: drag a slip onto a project heading** to promote straight into that project.
    *Why:* a one-gesture promote-with-project for mouse users.
    *Fit:* only if it adds no chrome: the target project label gets an accent underline, no dashed boxes, no
    layout folding. Drop it if it cannot be done that quietly; item 7 already covers the need.

### Considered and not grafted

- **C's digit keys for shortcuts:** conflicts with A's type-anywhere capture (a digit would start a note).
  Aliases in Go cover the same need.
- **B's always-focused omnibar:** it is B's core idea, not a part; merging launch and capture into one field
  would replace A's design rather than improve it.
- **C's serif for note text and B's agenda list:** each would dilute A's single type system and proportional
  day.

## Drop or change in the winner

- **The slip glyph on to-do rows:** replace per graft 6.
- **The explanatory sentence in the promote form** ("The note leaves the wall and stays attached to the
  to-do."): unnecessary once promote is instant with Undo.
- **Half-width column for declined events:** the declined "Vendor demo" takes an overlap column and gets
  truncated. Declined events should be a single grey struck line that never claims a column.
- **Fixed 08–18 window at 60 px per hour:** change per graft 8 so the strip and the full to-do list fit at
  1440×900.
- **Notepad panels opening above the capture slip:** the To do panel pushes capture about 500 px down. Keep
  capture fixed directly under the bar and open panels below it.
- **"delete" printed beside "To-do →" in notepad mode:** a destructive word next to the primary gesture. Move
  it away from the action or make it undoable through the same Undo line.
- **Open question for refinement, not a drop:** Enter saves a note. Meeting notes are often several lines;
  check whether Enter-saves or Enter-newline (with Ctrl+Enter to save, as in C) fits this user better.
