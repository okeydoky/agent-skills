# Direction A — "Ledger"

Designer's rationale, written before any critique. Mockup: `design.html`. Screenshots: `shots/`.

## The bet

This user keeps the page open all day and looks at it far more often than they operate it. So the page is
set like a printed ledger page: three columns of type, hairlines, no boxes, nothing that moves unless
asked. Everything that matters now (current meeting, next meeting, what is due, every shortcut, every
note) is on screen without a click. Interaction is plain mouse plus three keyboard rules.

One rule gives the design its point of view: **the page is print; only notes are objects.** A note is the
only thing with a surface (a flat tinted slip, no border, no shadow). Shortcuts, events, to-dos and future
sections are type on paper. This satisfies "post-it-like cards" without sliding into a card dashboard, and
it makes the note wall the one place the eye reads as "loose things to deal with".

## Layout

Full view (> 1120 px), 44 px page margin, 48 px column gaps:

| Zone | Width | Content |
|---|---|---|
| Masthead | full | wordmark, text nav (Today · Investments · Settings), Notepad toggle, Theme toggle; one hairline below |
| Go (rail) | 160 px | filter field, shortcuts as plain text links, groups expand inline |
| Today | 2.3fr | headline (date + pinned clock), **Now / Next** sentence pair, then hairline, then two sub-columns: **Day** (time-proportional timeline) and **To do** |
| Notes | 1.42fr | capture slip (always ready), then a two-column wall of slips |
| Strips | full, page foot | one line per secondary section (Investments) under a hairline |

- The Now/Next pair is the largest text after the date (17 px, weight 500). It is the answer to "what is my
  day" in words, so the timeline below is confirmation, not something to decode.
- Day and To do sit side by side so both are above the fold at 1440×900. I rejected "to-dos beneath the
  timeline": due items would fall below the fold, failing the glance.
- Medium widths (641–1120 px): same three zones, Day and To do stack, the wall becomes one column.
- Notepad mode (≤ 640 px, or forced): described below.

## Visual system (tokens)

One token set; dark theme re-declares the same names. Theme follows the OS, with a manual
auto → light → dark toggle (stored), and `#theme=` override.

| Token | Light | Dark | Use |
|---|---|---|---|
| `--paper` | `#FAFAF6` | `#121211` | page |
| `--ink` | `#171715` | `#ECEBE4` | primary text, active rules, checked boxes |
| `--ink2` | `#5B5B54` | `#A6A59C` | secondary text, times |
| `--ink3` | `#8A897F` | `#737269` | labels, hints, past/declined |
| `--line` | `#E3E2D9` | `#2A2A27` | hairlines |
| `--line2` | `#CCCBC0` | `#3D3D38` | stronger hairline, past-event rule, image edge |
| `--slip` | `#F0EFE5` | `#1E1E1B` | note surface (the only surface) |
| `--slip-in` | `#E6E5DA` | `#292925` | slip glyph on a to-do |
| `--accent` | `#C5411C` | `#FF6A3D` | see below |

**Accent has one meaning: "this needs you now."** Now-line, current event rule, the NOW label, the clock,
overdue to-dos and the "Due" heading, the capture slip's edge (where the cursor goes), the confirming
action in a form, focus rings. Links are not accent. Gains and losses in Investments use +/− signs, never
colour, so a future section cannot dilute the accent.

Type: **Instrument Sans** (400/500/600) for everything read; **IBM Plex Mono** (400/500) for times, dates,
figures, section labels and key hints. Fallbacks: `system-ui, Segoe UI` and `ui-monospace, Cascadia Mono,
Consolas`. Scale: 11 mono caps label · 12.5 event · 14 notes/rail children · 14.5–15 to-dos/links ·
17 now/next · 30 headline. No size outside this scale.

Spacing: 4 px base. 48 px between columns, 30 px between blocks, 18 px between to-do groups, 10 px between
slips. Separation is whitespace first, a 1 px hairline second, never a box or a shadow. Radii: 0 on slips,
3 px on checkboxes only.

## Key interactions, and what I rejected

### Launch — shortcuts and groups
- Plain text links, 30 px line pitch, one click. A group (Databricks) is a row with a count (`3 +`); clicking
  it expands its environments inline, indented behind a hairline, and **the open state persists**. So the
  user's daily group is open forever and a specific environment is one click; rarely used groups stay one
  line. Demo: Databricks open, Azure closed.
- Rejected: hover fly-outs (fragile, hidden, mis-fire on the way to another link); a launcher grid with
  favicons (reads as a dashboard template, and icons of ten brands break the monochrome page); group click
  opening a "default" environment (surprising, and Prod is a bad thing to open by accident).
- Keyboard: `/` focuses **Go**; typing filters across groups ("prod" → *Databricks Prod*); Enter opens the
  first hit; Esc clears. Two to five keystrokes to any environment.
- Editing is rare, so it is one quiet "Edit" link under the rail (stubbed: drag handles, rename, add link,
  add group; also reachable from Settings).

### Launch — the day
- Now/Next sentences: "Now  *subject*  until 11:30 · 40 min left" / "Next  12:00  *subject*  in 1 h 10 min ·
  tentative". Declined events never count as now or next. With no current event the line reads "Free until
  12:00". Empty day: "Nothing scheduled today", the timeline collapses to one line.
- Timeline: 60 px per hour, 08–18 by default and stretching to fit earlier/later events. An event is a 2 px
  vertical rule whose length is its duration, with text beside it; no filled blocks.
  - Response is carried by the rule and repeated in words: accepted/organizer solid; tentative dashed +
    "tentative"; no reply dotted + "no reply"; declined no rule, struck through, grey + "declined".
  - Past events grey out; the current event's rule turns accent and its subject goes bold.
  - Now-line: 1 px accent line with a dot and the time in the hour gutter (the nearest hour label yields).
  - Long subjects wrap and clamp to the lines the duration allows; the full subject is in the tooltip and,
    when relevant, in the Now/Next sentence, which never truncates.
  - 15-minute events get one 14 px line showing only the start time.
  - Overlaps: the earlier event keeps the full width for the lines above the overlap; the later one sits in
    the right half from its start time. Events that start together fall back to equal columns. Rejected
    equal columns everywhere: it halved the *current* meeting's text in the demo day.
- Times are local, 24-hour. Demo data is authored as UTC strings in both real formats
  (`…T21:30:00.0000000Z` and `…+00:00`) and parsed through one function that trims the 7-digit fraction.
  Implementer: keep that normalisation; do not rely on `Date.parse` for 7 fractional digits.

### Capture
- The capture slip is the first object in the Notes column, always present, never a button or modal.
  Enter saves, Shift+Enter is a new line; a "Save note" text action appears once there is content (mouse
  path). The draft itself persists, so a half-typed note survives a reload or a mode switch.
- **Type anywhere**: with no field focused, any printable key starts a note (focus jumps to capture and the
  keystroke lands there). `/` is the single reserved key. Rejected a dedicated "new note" hotkey: one more
  thing to learn for the most frequent write action.
- **Ctrl+V anywhere** with an image on the clipboard puts it in the draft as a thumbnail (removable) and
  focuses capture for an optional caption; Enter saves. Rejected "paste creates a note instantly": the
  caption is the usual next step, and an explicit Enter keeps one rule for all notes. Because the draft is
  persisted and visible, a pasted screenshot is never lost even if Enter is forgotten.
- Notes are edited in place by clicking the text. Screenshots open full-size on click. Delete is a quiet
  word, shown on hover (always shown in notepad mode, where there is no hover habit).
- New notes go to the shorter wall column and keep that column for life, so the wall never reshuffles.

### Triage — promote
- Every slip carries a visible **"To-do →"** in its footer. No hover reveal, no drag, no menu.
- Clicking it opens the form *inside the slip* (no modal, eye stays put): title (first sentence of the
  note, pre-selected), Due as words (none · today · tomorrow · Mon n · other…), Project as words (existing
  projects · + new). Enter confirms from anywhere in the form; Esc cancels. Minimum path: click, Enter.
  With due date: click, click "tomorrow", Enter.
- Rejected drag-a-note-onto-the-list: undiscoverable, impossible in notepad mode where the list is hidden,
  and gives no place for due/project. Rejected instant promote with later editing in the list: in notepad
  mode the list is not on screen, so the options would be out of reach.
- **What happens to the note: it leaves the wall and travels with the to-do.** The wall is an inbox; if
  promoted notes stayed, it would silt up and the user would triage the same slip twice. Nothing is lost:
  the to-do shows a small slip glyph, and opening it shows the original note, text and screenshot, on its
  slip. "Return to notes" on the to-do reverses the promotion at any time; an "Undo" line sits under the
  capture slip for 9 seconds after promoting.

### Triage — to-dos
- A **Due** group leads the list (overdue + today, project shown inline in grey); then one group per
  project; then "No project". Due dates right-aligned in mono: "1 d late" in accent, "today" in bold ink,
  later dates grey.
- Checking strikes the row in place and it stays put for the session (so a mis-click is trivially
  reversible and the list does not jump); on the next load it folds into "Done earlier".
- Clicking a title opens the same Due/Project pickers inline, the attached note, Return to notes, Delete.
- "Add a to-do" line at the top, Enter to add.

### Notepad mode
- Breakpoint **640 px**: half of a 1280 px laptop screen and a third of a 1920 px monitor both land here.
  A half of 1920 (960 px) still fits the real desk in its medium layout, so it is not forced into notepad;
  the masthead "Notepad" toggle forces the mode at any width for those who want it.
- It is a different page, not a stack: masthead, rail, timeline, to-dos and strips are gone. What remains:
  1. a one-line sticky bar: clock, "until 11:30 · next 12:00 *subject*" (the subject of the current
     meeting is omitted, the user is in it), "To do *n due*", "Go";
  2. the capture slip, larger type, auto-focused on entering the mode;
  3. the notes as a single newest-first stream with full-width screenshots.
- The three bar items open one inline panel at a time above capture (agenda list, to-do list, shortcuts +
  routes + theme) and close on a second click. Nothing is unreachable; nothing is in the way by default.
- Promote works identically, in the slip. State is shared, including the draft, so resizing loses nothing.

## How a future section slots in (the rules)

1. A section is **a route** with one word in the masthead nav. Home stays Go · Today · Notes.
2. A section may place **one strip** on home: a single line at the page foot, label in the rail's column,
   at most about five figures, the whole line links to the route. No second strip, no widget on home.
3. Inside its route a section uses only: the 30 px headline, mono caps labels, hairline-ruled tables or
   lists, mono figures. **No surfaces** (slips belong to notes), no shadows, no new colours.
4. Accent means "needs you now" and nothing else. Direction of a number is a sign, not a colour.
5. In notepad mode a section is reachable from the Go panel and shows a "← Notes" link; strips are hidden.
6. If a section needs capture, it takes it from notes (promote a slip), it does not add its own input to home.

The Investments stub follows these exactly: nav word, one strip, a figures row, a hairline table, an ink
sparkline whose only accent is the latest point.

## Demo states (URL hash)

Combine with `&`. Any `state=` boots from fresh sample data and does not write to storage; without
`state=` the page uses and persists `localStorage` (notes, to-dos, projects, draft, open groups, theme).

| Hash | Shows |
|---|---|
| `state=home` | default desk on sample data |
| `state=group-open` | both groups expanded, Databricks › Prod under the pointer |
| `state=go` | Go filter with "prod" typed, first hit marked Enter |
| `state=edit-shortcuts` | rail in edit mode (static stub) |
| `state=draft` | capture slip with text and a pasted screenshot |
| `state=promote` | promote form open on the note with a screenshot, defaults |
| `state=promote-filled` | same, due tomorrow + project chosen |
| `state=promoted` | after promoting: undo line, new to-do open with its note attached |
| `state=todo-open` | an existing to-do open, showing its back-linked note and screenshot |
| `state=done` | two to-dos checked off in place |
| `state=empty-day` | no events |
| `route=investments` · `route=settings` | secondary routes |
| `theme=dark` · `theme=light` | force theme |
| `mode=notepad` | force notepad mode at any width |
| `panel=day` · `panel=todos` · `panel=go` | notepad mode with that panel open |
| `now=HH:MM` | move the pinned clock (default 10:50 on Fri 13 Nov 2026) |
| `reset=1` | discard stored data and reseed |

Notepad mode needs no hash: size the window to 640 px or narrower.

## Mockup notes for the implementer

- Shortcut links open in a new tab in the mockup; the real start page should navigate in place.
- The clock is pinned; the real app re-renders Now/Next and the now-line every minute.
- Pasted images are downscaled to 1100 px JPEG and kept in `localStorage`; the real app should store blobs
  on disk or in IndexedDB.
- Stubs: shortcut editing, Settings (only theme and reset are live), Investments data.
- Screenshots at 480 px were taken through a 480 px iframe because headless Edge will not lay out a
  window narrower than about 500 px.
