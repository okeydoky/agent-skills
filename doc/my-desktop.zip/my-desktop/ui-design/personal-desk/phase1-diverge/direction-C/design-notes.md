# Direction C — "Desk"

Notes-first workspace. The note board is the app; schedule, todos and shortcuts are periphery around it.
Written before any critique.

## The bet

What this user does all day is capture and triage. Launching a site takes a second and looking at the
calendar is a glance, so both get slim, always-visible edges. The centre of the screen goes to notes, shown
with real room and screenshots at a readable size.

## Layout

```
+--------------------------------------------------------------------+
| 1 GitHub  2 Databricks v  3 Azure v  4 Jira ...     Edit   theme   |  dock, 48px
+------------------------------------------------+-------------------+
|  [New note ]  [note+shot]  [note+shot]         | Today | Investm.  |
|  [note     ]  [note     ]  [note     ]         | Friday 13 Nov     |
|  [note     ]                                   | schedule          |
|                                                | Todos by project  |
|  board (scrolls)                               | rail, 372px       |
+------------------------------------------------+-------------------+
```

- **Board**: columns of notes, newest first reading across rows. Column count follows width (272px minimum
  column, 1 to 4 columns). The first card is always the open capture note.
- **Rail (372px, right)**: one panel at a time, chosen by tabs. "Today" holds the date, the schedule and the
  todos. The rail scrolls as one column.
- **Dock (48px, top)**: shortcuts as plain text labels with their key number. No favicons or tiles: labels
  scan faster than icons and need no remote assets.
- **Notepad mode (viewport ≤ 640px)**: the same board, one column. The dock slides up and the rail slides
  right, off-screen (CSS transforms on the same elements, 280ms). A 44px bar at the bottom shows the next
  event and the todo count; pressing it slides the rail back in over the board.

Breakpoint 640px: it covers half of a 1280px screen and a third of a 1920px one, the two common split
sizes. Above it the rail stays; between 641 and about 930px the board simply drops to one column.

## Visual system

One token set, two themes. Follows the OS, with a manual toggle (`data-theme` on `<html>`, stored).

| Token | Light | Dark | Use |
|---|---|---|---|
| `--board` | `#E8EBE6` | `#121514` | page and dock background |
| `--surface` | `#FBFCFA` | `#1D2120` | notes, inputs, popovers |
| `--rail` | `#F2F4F0` | `#171A19` | side rail, peek bar |
| `--sunk` | `#DFE3DC` | `#0D0F0E` | hover fill, image wells |
| `--ink` | `#181C1A` | `#E3E7E3` | text |
| `--ink-2` | `#535B56` | `#A3ACA6` | secondary text |
| `--ink-3` | `#848C86` | `#717A75` | meta, timestamps, key numbers |
| `--line` / `--line-2` | `#D2D7D0` / `#AEB6AE` | `#2A302D` / `#444C48` | hairlines / stronger borders |
| `--accent` / `--accent-weak` | `#0A6B58` / `#D9E9E2` | `#5FC4A6` / `#1B332D` | now, next, due today, drop target, links |
| `--late` | `#A8321F` | `#EB8C7B` | overdue, negative change. Never decoration |

- Three surface tints (board, rail, note) separate regions; there are no shadows anywhere. A dragged note
  is marked by an accent border, not a lift shadow.
- **Type**: Schibsted Grotesk for everything the app says; Newsreader (text serif, 16.5px/1.45) only for
  note text, wherever a note appears (board, capture, attached to a todo). Rule: serif means "your words".
  Fallbacks: `system-ui` and `Georgia`.
- Scale: 11.5 / 12.5 / 13.5 / 14.5 / 20 / 26. Weights 400, 500, 600. Sentence case, no all-caps labels.
- Spacing on a 4px grid: 16px gaps between notes, 10/16px note padding, 20px rail padding, 22px between
  rail blocks. Radius 6px on cards, 4px on controls, 13px on chips.
- Status is always text plus colour, never colour alone ("1 day late", "tentative", "declined").

## Key interactions and why

### Launch
- Single link: one click, or its digit key (1 to 0) when focus is not in a text field.
- Group: hover or click opens a small list of environments with hosts; click one. By keyboard: `2` then `3`
  is Databricks Prod. Hover-open makes the mouse path one aim and one click.
- On a wide window nothing is auto-focused, so digit keys work the moment the page opens. `N` jumps to the
  capture note.
- Rejected: environments always expanded inline in the dock (one click, but two groups already eat a third
  of the strip and it breaks at narrower widths); a left icon dock (icons need learning; text does not).

### My day
- An agenda list, not a proportional timeline. The rail is narrow; a list handles long subjects (two lines,
  full text on hover), 15-minute events and overlaps without tiny boxes.
- Finished events fold into one "Earlier, 3 events" row. The running event is the only filled row, with a
  progress line and "50 min left". The next event is bold with "in 20 min" in accent. If nothing is
  running, a "Free until 14:00" line takes that place.
- Response is the bar beside the time: solid = accepted or organiser, dashed = tentative, hollow = not
  answered, none plus struck-through subject = declined. Each also says so in words.
- Overlap is stated once, on the later event ("overlaps Lakehouse cost review").
- Events are authored as UTC ISO strings and rendered only through local `Date`.
- Rejected: a separate "next up" hero above the list (duplicates the first two rows).

### Capture
- The capture note is a real note that is always open at the front of the board. Type and it autosaves as a
  draft (survives reload). Ctrl+Enter or "Keep note" files it and opens a fresh one.
- Ctrl+V with an image attaches it to the note that has focus; with no focus it goes to the capture note,
  from anywhere in the app including the investments page. An image button is the non-keyboard path.
- Existing notes are edited in place; there is no edit mode.
- In notepad mode the capture note is focused on entry and is taller.
- Pasted images are downscaled to 1280px JPEG before storing.

### Promote a note to a todo
Two entry points, one result.
1. **Drag** the note (from its top strip, margins or screenshot) onto the rail. When a drag starts the
   schedule folds away so every project is a visible, large drop zone; the hovered project fills with
   accent tint and says "Drop to add here". Dropping anywhere else on Todos files it under "No project".
   Esc cancels.
2. **"Add to todos" button**, always visible on every note (not hover-only). Ctrl+Shift+Enter does the same
   from the keyboard, including straight from the capture note.

Either way the todo exists immediately, with no dialog. The new row opens with Due chips (No date, Today,
Tomorrow, next Monday, Pick a date) and Project chips, plus Undo. Date and project stay optional, and
ignoring the row is a valid finish. In notepad mode the rail is hidden, so the same editor appears as a
receipt in the place the note occupied.

**What happens to the note**: it leaves the board and lives on inside the todo. The first line becomes the
title; the full text and screenshot stay attached (thumbnail on the row, full note when the row is opened).
"Turn back into a note" reverses it at any time. Reason: the board is an inbox, and triage should empty it.
Keeping both copies makes clutter and two things to maintain; deleting the note loses context.

Rejected: a promote dialog (ceremony for a frequent action); drag only (undiscoverable, and impossible in
notepad mode); pointer-events drag was chosen over HTML5 drag-and-drop because the latter fights
`contenteditable` and cannot style the drag image.

### Todos
- Checkbox, title, due date in a right-hand column, thumbnail if it came from a note with a screenshot.
- Grouped by project with "No project" first, since that is where quick adds and button promotes land.
  "By date" flattens the list by due date.
- The header counts what matters: "1 late, 1 due today". Late is red and bold, today is accent and bold.
- Click a row to open the editor and the attached note. Done items fold into "Done, 2".
- `T` focuses the add field.

## Extensibility rules

1. **The board is notes.** No other section takes space on it.
2. **A new section is a rail tab.** Its panel is built from the same parts as Today: a block (14px
   semibold heading, optional meta on the same line) containing rows (30 to 40px, text left, figure right).
   Investments in the mockup uses exactly this.
3. **If a section needs width, it also gets a full page** on its own route (`/investments`), reached from
   the tab's "Open the full page" link. A full page replaces the board only. The dock and the Today rail
   stay, so shortcuts, schedule and todos are never more than a glance away, and Ctrl+V or `N` returns to
   notes.
4. **Notepad mode shows notes only.** Sections are reachable through the peek bar and the same tabs.
5. Colour: accent means "now, next, or act here". Red means late or negative. A section adds no new hues.
6. Serif is reserved for note text.

## Demo states

Append to `design.html#`. Combine with `&`. Any `state=` runs on fresh seeded data and does not touch
`localStorage`; without it, notes, todos, draft and theme persist.

| Hash | Shows |
|---|---|
| (none) | home |
| `theme=dark`, `theme=light` | force a theme |
| `mode=notepad` | force notepad mode at any width (normally: window ≤ 640px wide) |
| `state=group-open` | Databricks group open |
| `state=capture` | capture note with text and a pasted screenshot |
| `state=promote-drag` | mid-drag, note over the Lakehouse migration drop zone |
| `state=promoted` | the resulting todo with its editor (wide); the in-place receipt (narrow) |
| `state=todo-open` | an older todo opened, showing its source note and screenshot |
| `state=peek` | notepad mode with the Today rail slid back in |
| `state=investments` | investments tab in the rail |
| `state=investments-page` | investments full page |
| `state=empty-day` | no events |
| `state=edit-shortcuts` | static stub of shortcut editing |

"Now" is pinned to Friday 13 November 2026, 13:40 local.

## Known gaps (mockup, not design)

- Shortcut editing and the investments views are static. "New project" uses a browser prompt.
- Shortcut links show a toast instead of navigating.
- Todo titles are not editable in place yet; the design intends them to be, in the opened row.
- Dragging is not offered in notepad mode; the button and Ctrl+Shift+Enter cover it.
