# Direction B — "Console"

Designer's own rationale, written before any critique.

## The bet

The user is an engineer who opens this page dozens of times a day and whose hands are already on the
keyboard. So the page has **one input that is always focused**, and that input launches links, captures
notes, adds todos and accepts pasted screenshots. Everything below it is a dense, read-at-a-glance
instrument panel. Every keyboard action also has a visible, clickable equivalent, labelled with its key, so
the mouse user is never stranded and the keys teach themselves.

## Layout

Desktop (> 640 px), top to bottom:

1. **Omnibar** (left, takes all spare width) + minimal nav `1 Today  2 Investments  3 Settings`, clock,
   theme, `?`. No logo, no greeting.
2. **Intent line** — one line directly under the omnibar that states what each key will do *with the current
   input* (`↵ open Databricks · Dev`, `Tab pick environment`, `Alt ↵ save as note instead`). Its items are
   real buttons. This line is the design's safety device: the omnibar is overloaded on purpose, and the
   intent line removes the guessing.
3. **Shortcuts strip** — every shortcut in one hairline row: `alias  Name`, and for groups the environments
   inline (`db Databricks  Dev · Staging Prod`). A specific environment is always one click away; nothing
   to expand. A small dot marks the last-used environment.
4. **Three panes**, hairline-separated, each scrolling independently:
   **Day** (29%) · **Todos** · **Notes**. Each pane = caps label + one-line digest + rows.
5. **Status bar** — mode badge (`TYPE` / `LIST`), the single-key verbs valid for the focused row, and the
   result of the last action with `u undo`.

Notepad mode (≤ 640 px, or pinned with the `pad` command): the omnibar becomes a taller capture field at the
top; under it a tab row `Notes · Todos · Day · Links`; Notes is the default and fills the rest. The header
shrinks to `NOTEPAD` plus a one-line "next 14:00 1:1 Priya · 20 min" so a meeting is never missed.

**Breakpoint: 640 px.** That is half of a 1280-px-wide logical desktop and a third of a 1920 one — the
widths a snapped split actually produces. Below it three panes cannot hold readable rows; above it they can.
Because a half-snap on a 1920 screen is 960 px (still full view), the mode can also be **pinned** from the
omnibar (`pad` ↵), which centres the notepad at 640 px.

## Visual system

One token set, two themes; theme follows `prefers-color-scheme`, a manual toggle sets `data-theme`.

| Token | Light | Dark | Use |
|---|---|---|---|
| `--bg` | `#F5F4F0` | `#131412` | page |
| `--surface` | `#FBFAF7` | `#1A1B19` | omnibar, note cards, glance box |
| `--raise` | `#ECEBE5` | `#242522` | hover, list cursor row |
| `--ink` | `#1A1B19` | `#E7E6E0` | primary text |
| `--ink2` | `#55574F` | `#A9AAA2` | secondary text, key caps |
| `--ink3` | `#8B8D85` | `#73756E` | meta, past events, hints |
| `--line` / `--line2` | `#DDDBD3` / `#C6C4BB` | `#2A2B28` / `#40413D` | hairlines / stronger rules, inputs |
| `--accent` | `#1466B3` | `#78B6EE` | **now**, next, cursor, due today, the active intent |
| `--accent-bg` | `#E2ECF5` | `#172838` | current event row, promote form |
| `--warn` | `#B3361F` | `#EE8068` | overdue, negative numbers — nothing else |

- **Type:** IBM Plex Sans for anything a human wrote (subjects, titles, notes); IBM Plex Mono for anything
  the system computed (times, durations, dates, counts, aliases, key caps, labels). Fallbacks: `system-ui`
  / `ui-monospace, Consolas`. Sizes: 13 body, 11–12 mono meta, 14 glance, 17 omnibar. Weights 400/500/600.
- **Spacing:** 28 px page gutter (14 in notepad mode), 22 px pane padding, 28 px minimum row height,
  hairlines between rows. Radius 3–4 px. **No shadows, no gradients, no icons** — the only glyphs are key
  caps, an 8 px square event marker and the checkbox.
- **Colour rule:** colour means state. Accent = "this is now / this is where you are"; warn = "late".
  Everything else is ink on paper.

## Key interactions and why

### Launch
- Type an alias; the strip filters **in place** (non-matches dim, the top match is underlined) and the
  intent line names the result. `gh ↵` opens GitHub. `db ↵` opens Databricks in the last-used environment.
  `db p ↵` opens Prod. `db Tab` scopes the omnibar to the group (chip `Databricks ›`), then `1/2/3` or
  `d/s/p` opens immediately with no Enter.
- Mouse: every link and every environment is a visible one-click target in the strip.
- *Rejected:* a dropdown/command-palette overlay (hides the day while you launch; the strip already is the
  result list). Expand-on-click group folders (an extra click on the most frequent action). Auto-firing on a
  unique alias without Enter (fires while typing a note). A `>` command prefix (sections and commands are
  just more launch targets: `inv ↵`, `theme ↵`, `pad ↵`).
- *Known trade-off:* a one- or two-word note that happens to match an alias would launch on Enter. The
  intent line shows this before Enter, and `Alt ↵` forces a note. Three or more words never match.

### Capture
- Plain text + `↵` saves a note; `Shift ↵` is a new line. `Ctrl+V` with an image attaches it to the draft
  (thumbnail tray under the omnibar, `⌫` on an empty field removes it); `↵` saves text + image together.
  `+ image` is the mouse path.
- `Ctrl ↵` saves the text as a todo instead. Optional `#project` and `@due` tokens (`@fri`, `@tomorrow`,
  `@20`, `@11-27`) are parsed live and previewed in the intent line.
- The same field is the capture field in notepad mode, so a half-typed draft and its attachments survive
  crossing the breakpoint in either direction.
- *Rejected:* auto-saving on image paste (a screenshot nearly always wants a caption); separate "new note" /
  "new todo" inputs (two places to aim at); a modal editor.

### Triage
- `↓` (or `Esc`) from an empty omnibar enters **LIST** mode: `j/k` move, `Tab` switches notes ↔ todos,
  `/` returns. One verb per key, same key means the same idea everywhere: **`x` = done with it** (checks a
  todo, files a note), `t` = note → todo, `↵` = open (edit note / show a todo's source note), `⌫` delete,
  `u` undo.
- **Promote** (`t`, or the always-visible `→ todo` button on each note): the note opens an inline form —
  title prefilled from the note's first line, due, project. `↵` creates. So the minimum is `t ↵`. Due takes
  the same grammar as the omnibar plus chips (today / tomorrow / Mon / none); project is type-ahead plus
  chips. Not a modal: the note and its screenshot stay visible while you decide.
- **What happens to the note:** it is **filed, not deleted**. It leaves the inbox for a collapsed `filed`
  fold, and the todo carries a `note + image` back-link that expands the original text and screenshot
  inline. Reason: the inbox should empty as you triage, but the screenshot is evidence you will want when
  doing the todo. `restore` and `u` reverse it.
- Todos are grouped by project; the pane digest (`1 overdue · 2 due today · 8 open`) carries the "what is
  due" glance, and due labels are right-aligned in mono so they scan as a column.
- *Rejected:* drag a note onto the todo list (slow, undiscoverable, no keyboard path); promote-and-delete
  (loses the screenshot context); a separate "Due" section duplicating rows.

### Day
- An agenda **list**, not a proportional timeline: columns are start · duration · response marker · subject
  · tags. Long subjects wrap (never truncated). Since a list loses proportional time, three things restore
  it: a duration column, explicit `free 30m` gap rows, and a progress hairline under the current event.
- A **glance box** at the top answers the only two questions that matter (`NOW … 35 min left`,
  `NEXT 14:00 … in 20 min`) at a larger size; it is the first place the eye lands on the page.
- Overlaps are bracketed in the marker column. Response: solid square = accepted/organizer, hatched +
  italic = tentative, hollow = no reply, struck through + dimmed = declined (and never counted as "next").
- Times are parsed from UTC wire strings and shown in local time; the zone is stated under the list.

## How a future section slots in (the rules)

1. **A section is a route.** It registers `{name, alias, number key}` and thereby appears in the nav, in the
   omnibar (`inv ↵`) and in the cheat sheet. Nothing else on the page moves.
2. **A route is 1–3 panes. A pane is: caps label + one-line digest + rows** on the shared row grid
   (28 px rows, hairlines, mono for computed values, sans for human text).
3. **The omnibar, intent line, strip and status bar are global** and identical on every route; capture
   works everywhere and lands in the same inbox.
4. **Rows get single-key verbs**, listed in the status bar; `j/k`, `x` (done with it), `↵` (open), `u`, `/`
   keep their meaning.
5. **Colour only for state** (accent = now/focus, warn = bad). No new hues per section.
6. **In notepad mode a route's panes simply stack**; routes are listed in the Links tab.

The Investments stub (Holdings / Watchlist / Allocation) is built from exactly these parts with no new CSS
concepts beyond a column template.

## Demo states (URL hash, combinable with `&`)

`#state=<name>&theme=light|dark&pad=1&tab=notes|todos|day|links` — any `state` uses fresh seed data and
never touches storage. Without `state`, notes/todos persist in `localStorage` (`#reset` reseeds).

| State | Shows |
|---|---|
| `home` | default view |
| `filter` | omnibar `db` → strip filtered to Databricks, intent line |
| `filter-env` | `db p` → Prod picked |
| `group-open` | scoped to the Databricks group (after Tab), `1/2/3` |
| `note-draft` / `todo-draft` | text in the omnibar; todo draft shows `#project @due` parsing |
| `paste` | draft with a pasted screenshot attached |
| `list` / `list-todos` | list mode with cursor (todos: source note expanded) |
| `promote` | inline promote form open on a note with a screenshot |
| `promoted` | after promoting: new todo with back-link expanded, note in the filed fold |
| `keys` | cheat sheet |
| `investments` / `settings` | future-section stub / static settings |
| `empty-day` | no events |
| `links-edit` | shortcut editing stub (static) |

Notepad mode: size the window ≤ 640 px (e.g. 480×900), or add `pad=1`.

## Mockup caveats for the implementer

- Launching only reports the URL in the status bar; a real build navigates.
- Calendar demo data is authored as wall-clock times and serialised to the real wire shape (UTC, 7
  fractional digits + `Z`, or `+00:00`) so the day looks right in any timezone; the render path is the real
  UTC → local one. "Now" is pinned to Fri 13 Nov 2026 13:40 local.
- Shortcut editing and Settings are static stubs. Investments rows are not yet in the list cursor.
- Headless Edge cannot go narrower than ~500 px, so the 480 px shots were taken through a 480 px iframe.
