# Brief — Personal Desk (local personal-productivity start page)

A web app that runs on the user's own machine and serves as their browser home base. Single user, no auth,
no sharing. Desktop browser (Chrome/Edge) only. This brief is fixed for the whole design flow.

## Requirements

1. **Shortcuts.** Links to the user's most-visited sites. Some shortcuts are **groups**: e.g. a "Databricks"
   group containing 3 links, one per environment (Dev / Staging / Prod). Opening a link must be as fast as
   possible (it is the most frequent action). Adding/editing/reordering shortcuts must exist but is rare.
2. **Calendar — "my day".** Shows what today looks like. Data is a flat list of events:
   `{"subject": string, "start": ISO datetime, "end": ISO datetime, "response": "organizer" | "accepted" | "tentativelyAccepted" | "notResponded" | "declined"}`.
   Real data carries **UTC plus a timezone offset** (e.g. `2026-11-13T21:30:00.0000000Z` or with `+00:00`);
   **display is always in the user's local time**. Read-only (no event editing). Must handle: long subjects
   (e.g. "Following: Need: James, Tracy, Sankar, Alain - Force Migration to Databricks"), overlapping
   events, 15-minute events, an empty day, and must make "now / what's next" obvious. `response` must be
   visually distinguishable (at minimum: tentative and declined differ from accepted/organizer).
3. **Todos.** Each todo: checkbox, title, **optional due date**, optional **project** (todos can be grouped
   under a project), and an optional back-link to the note it was promoted from (including its screenshot).
   No priorities, tags, or sub-tasks in phase 1.
4. **Notepad.** Notes are **separate post-it-like cards**. A note holds text and/or **pasted screenshots**
   (Ctrl+V an image). Notes **persist across sessions**. Capturing a note must be near-zero friction.
   Any note can be **promoted to a todo** in one obvious gesture (the note's text becomes the title, its
   screenshot stays attached; decide and justify what happens to the original note).
5. **Narrow viewport = notepad mode.** When the viewport is narrow (the window is split-screened beside
   another tab/app, roughly ≤ 560–640px wide — designer picks and justifies the breakpoint), the app turns
   into a dedicated note-taking surface: capture and recent notes come first, everything else gets out of
   the way. It is used to take notes about what is on the other half of the screen. It is a *mode*, not
   merely a stacked responsive layout. Promote-to-todo must still work there.
6. **Style.** Minimal and modern. **No AI slop**: no gradient hero, no glassmorphism, no purple/indigo
   glow, no emoji as icons, no decorative illustrations, no "Good morning, user!" filler, no cards-in-cards,
   no drop shadows as decoration, no generic dashboard-template look. Restraint, typography and spacing
   carry the design.
7. **Light + dark themes**, following the OS setting, from one token set (plus a manual toggle).
8. **Extensible.** More sections will come later (first known example: an **investments** section). The
   design must say where a new section goes and how it looks, without a redesign. Not everything must fit
   on one screen — secondary content may live on **another route**. The mockup must include at least a
   stub of how one future section (investments) would slot in, to prove the system.
9. **Deliverables.** (a) Interactive HTML mockup demonstrating the interaction flows; (b) a **design note**
   that an implementation session can build from *and* that states the design principles future features
   must follow.

### Non-goals
- Real calendar integration, real persistence backend, auth, multi-user, mobile-phone design.
- Editing calendar events. Todo priorities / tags / sub-tasks / recurring todos.
- Real investment features (only a stub proving extensibility).

## Primary user and top 3 tasks

A data engineer who keeps this open as their browser start page all workday, often with the window
split-screened next to a meeting, a doc, or a notebook.

1. **Launch** — open the page, glance at "what is my day / what's next", and jump to a frequent site
   (including a specific environment inside a group) in one or two actions.
2. **Capture** — from the narrow split-screen notepad mode, jot a note and paste a screenshot about what is
   on the other screen, with zero ceremony; it is still there tomorrow.
3. **Triage** — back in the full view, turn a note into a todo (optionally with a due date and project),
   then work the todo list (check off, see what is due).

## Rubric (weights sum to 100)

| # | Criterion | Wt | "Excellent" looks like |
|---|---|---|---|
| 1 | Task-flow efficiency (top 3 tasks) | 25 | Each top task takes the minimum plausible actions; nothing modal or ceremonial in the way; keyboard paths exist for the frequent ones. |
| 2 | Notepad mode & capture quality | 20 | Narrow mode feels purpose-built for note-taking beside another window; paste-a-screenshot and promote-to-todo are obvious and fast; transition between modes loses nothing. |
| 3 | Visual hierarchy & calm | 15 | At a glance the eye lands on what matters now (next event, due todos); density is comfortable for an all-day page; nothing shouts. |
| 4 | Aesthetic restraint & distinctiveness | 15 | Clearly minimal and modern, has a point of view, zero AI-slop tells, works equally well in light and dark. |
| 5 | Extensibility of the system | 15 | A new section (investments) has an obvious home and looks native; the rules that make this true are few and statable. |
| 6 | Discoverability | 5 | Key gestures (promote, paste, group expand) are findable without a manual. |
| 7 | Implementation feasibility | 5 | Buildable by one developer with plain web tech; no interaction that depends on fragile tricks. |

## Fixed rules

- **Severity bar:** only **high/medium** findings accepted by the judge trigger another refinement round.
  - *High* — a top-3 task is blocked, confusing, or clearly slower than it should be; or a requirement is
    unmet; or a rubric criterion with weight ≥ 15 is materially failed.
  - *Medium* — a noticeable drag on a top-3 task or rubric criterion that a user would feel daily; an
    inconsistency that would mislead the implementer.
  - *Low* — polish; taste; rarely-hit states.
  Accepted low findings are batched into the next round if one happens, otherwise listed as optional polish.
- **Stop conditions:** stop when there are no high/medium findings, OR the judge accepts no high/medium
  findings, OR `max_rounds` = **3** refinement rounds are done.
- **Never overwrite** an earlier phase's or round's files. Every phase/round writes new files.
- The bar above is identical in every round.

## Mockup constraints

- One self-contained `design.html`: inline CSS + vanilla JS. Google Fonts allowed (must degrade gracefully
  offline to a sensible system stack). No other remote assets; screenshots inside notes are generated
  placeholders (inline SVG / canvas / data URI), never remote URLs.
- Works in current Chrome/Edge. Realistic in-memory demo dataset: ~10 shortcuts incl. a Databricks group
  with 3 environments and at least one other group; a believable workday of 6–8 events including the long
  subject above, an overlap, a tentative, a declined, and a 15-minute event; ~8 todos across 2–3 projects
  plus some without a project, some with due dates (one overdue, one today); ~6 notes, two with
  screenshots. Calendar demo data is authored in UTC and rendered in local time; "now" is pinned to a fixed
  demo time mid-workday so screenshots are stable.
- Notes/todos persist in `localStorage` in the mockup so "persists across sessions" is demonstrable. Real
  image paste (Ctrl+V) should work.
- **Demo-state hook:** the mockup must boot straight into key states from the URL hash, e.g.
  `design.html#state=group-open`, `#state=promote`, `#theme=dark`, combinable with `&`. List all states in
  `design-notes.md`. Notepad mode must be reachable by simply sizing the window narrow (e.g. 480×900).

## Addendum 1 — requirements added by the user on 2026-11-15 (during round 2)

These come from the user and supersede the original text where they conflict (in particular the
"no tags" wording in requirement 3 and the Non-goals list). Rubric, severity bar and stop conditions
are unchanged.

10. **Tags on notes and to-dos.** Both notes and to-dos can carry tags. There is a **filter** that shows
    only items with the selected tag(s), and it applies to notes and to-dos. The user suggested tags may
    **replace** the current project grouping of to-dos; the designer decides between "tags replace
    projects" and "tags alongside projects" and justifies it — one organising concept is preferred unless
    there is a strong reason for two. Tags must survive promote (a note's tags carry to its to-do),
    must be quick to apply at capture time (e.g. the existing `#token` syntax) and after the fact, and
    must work in notepad mode.
11. **Copy a note's text in one click.** Each note has a copy control that puts the note's **text only**
    (no image) on the clipboard, with a quiet confirmation.
12. **Deliverables also include an app specification** document for the implementation session, alongside
    the UI design (written at handoff).
