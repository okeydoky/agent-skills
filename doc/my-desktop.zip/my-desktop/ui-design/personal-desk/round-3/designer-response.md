# Round 3 — designer response to blind findings

Written from `findings-blind.md` only (I have not opened `review.md`). I looked at the reviewer's renders
`i2-700.png` (injected split-screen capture) and `i1-520.png` (two-tag filter in notepad mode), and at my
own `filter-light.png`, `filter-two-light.png`, `by-tag-filter-light.png` and `tagging-light.png`. No file
other than this one was changed.

| Finding | Position | Short answer |
|---|---|---|
| R3-01 view switch vanishes under a filter | agree | A layout bug I introduced; the label row has room for one of the two, not both. |
| R3-02 uncapped screenshots in notepad mode | agree on the problem, partial on the history | Uncapped was specified for notepad mode in the round-1 verdict, not silently changed; but a tall capture breaks the mode, so it must be capped. |
| R3-03 removing a tag has no affordance | agree on the editor, partial on the footer | The editor needs a visible remove mark; the footer `#tag` should keep filtering. |
| R3-04 notepad hides the filter's scope | agree | The echo was simply not carried into notepad mode, and the due count disagrees with the list. |

---

## R3-01 — The "by due · by tag" switch disappears whenever a tag filter is active

**Why it was designed this way.** In round 3 I added the switch at the right of the To do label, where the
keyboard hints already appeared, so it would cost no vertical space. The label row is a one-line flex row
with a fixed height and `overflow: hidden`; that rule exists so labels never wrap (a round-1 decision).
The filter echo (`· #lakehouse · 3 of 8 · clear`) also lives in that row. I checked the switch with the
short `#prod` filter and with no filter, not with a long tag name.

**Is the problem real: agree.** `filter-light.png` shows `TO DO · #lakehouse · 3 of 8 · clear` and no
switch; `by-tag-filter-light.png` with `#prod` shows both. Whether a control exists depends on the length
of a tag name, and nothing says why it went. The no-wrap rule did what it was told and hid the overflow;
the defect is that two growing things were put in one fixed row.

**Proposed fix.** Give each its own line, in both columns, so the rule is the same for Notes and To do:
- **Label row (always one line):** `TO DO` on the left, `by due · by tag` on the right. While a to-do is
  selected the keyboard hints still take the switch's place, as now. Notes: `NOTES` on the left, its key
  hints on the right when selected.
- **Filter line (only while a filter is on):** directly under the label, mono grey, its own full-width
  line: `#lakehouse · 3 of 8 · clear` (To do) and `#lakehouse · 4 of 6 · clear` (Notes). Built from nowrap
  segments; if a multi-tag union is too long, the tag list wraps at ` or ` boundaries and `n of m · clear`
  stays together.
- The label row then holds only fixed-length content, so the no-wrap rule can never hide a control again.
  Cost: one 15 px line in each column while filtering, which is when the state is worth stating.
- Add verification shots: `filter` with the longest seed tag at 1440, 1425, 1280 and 960, both views.

---

## R3-02 — In notepad mode, screenshots are uncapped

**Why it was designed this way.** In round 2 the judge's verdict for R1-03 specified a 140 px cap for the
desk layouts and "Notepad mode keeps uncapped full-width screenshots", on the reasoning that in notepad mode
the image is the point and the column is narrow. So this was a decision, not a silent divergence. I tested it
only with the demo's wide screenshots (480×270 and similar), which come out at 230–330 px.

**Is the problem real: agree on the problem, partial on the history.** `i2-700.png` is decisive: a 960×1080
capture of the half-screen beside the window, which is exactly what notepad mode exists for, fills
everything below the capture slip, and every earlier note, plus that note's own Copy and To-do →, is off
screen. The earlier decision assumed landscape screenshots; split-screen captures are portrait by nature. The
reviewer's point that the mode where screenshots matter most is the one that breaks is right.

**Proposed fix.** Keep one slip component and change one property, as the R1-03 verdict wanted:
- In notepad mode, cap images at `min(320px, 40vh)`: about 320 px at 900 high, 280 px in a 700 px tall
  window. Wide screenshots at 480 px (≈ 250 px tall) are unaffected; portrait ones are cropped from the top,
  which is where a document's heading and the area the note is about usually are.
- Desk layouts keep their 140 px cap.
- **When an image is cropped, say so in words:** a mono grey line directly under it, `cropped · open`,
  where "open" shows it full size (the existing zoom view; click on the image does the same). No line when
  the image fits, so the common case is unchanged.
- The draft thumbnail in the capture slip stays at its current 74 px.
- Result in the reviewer's case: the note takes about 380 px including text and footer, and the previous
  note's text is visible below it at 900 high.
- Add a portrait screenshot to the seed data and a `state=tall-shot` demo at 700 and 480, so this is
  checked from now on.

---

## R3-03 — Removing a tag from a single note or to-do has no visible affordance

**Why it was designed this way.** The tag editor shows the item's current tags as pressed words, matching
the Due words above it (pressed = chosen; click to change). I relied on the tooltip for "Remove". The footer
`#tag` filters because every `#tag` on the page filters, in the rail, footers, rows and by-tag headings.

**Is the problem real: agree on the editor, partial on the footer.**
- Editor: agree. In `tagging-light.png` the current tag is an underlined word that looks like a selected
  option, not like something removable, and only the tooltip says otherwise. Due words are a choose-one
  control; tags are a set, and they should not borrow the same look.
- Footer: partial. Clicking `#lakehouse` to filter is the one consistent meaning of a `#word` on this page,
  and the reviewer lists that consistency as a strength. Changing it in one place would make the vocabulary
  ambiguous. The real issue is that "+ tag" reads as add-only, so a user who wants to *correct* a tag looks
  for the next nearest thing, the tag itself.

**Proposed fix.**
- In every tag editor (note "+ tag", receipt, open to-do), each current tag is printed as `lakehouse ×`:
  the word in ink, a mono grey `×` after it. Hover strikes the word through and turns the `×` ink; click
  removes it (undoable as today). The `×` is the same character the capture slip already uses to remove a
  pasted thumbnail, so it adds no new vocabulary. Picker styling (accent underline) is no longer used for
  tags.
- In the note footer, the edit word reads **"+ tag"** when the note has no tags and **"edit tags"** when it
  has some, so the correction path is named.
- Footer and row `#tags` keep filtering; their tooltip already says "Show only #lakehouse".

---

## R3-04 — Notepad mode hides the filter's scope

**Why it was designed this way.** In notepad mode the column labels are hidden (the bar replaces them), so
the label-row echo did not exist there; I relied on the underlined selected tags in the tags strip and the
"clear" word. The bar's due count was kept global on purpose in round 2, as a safety net ("what is due
today" should not be hidden by a filter), and I did not revisit that when filters became common.

**Is the problem real: agree.** `i1-520.png` shows two selected tags and "clear", but nothing says "or" or
how much is hidden; the bar says `To do · 3 due` while opening To do shows one due item. Two numbers that
disagree on one screen are worse than either choice.

**Proposed fix.**
- Under the tags strip, while a filter is on, the same filter line as R3-01 in the same mono grey:
  `#cost or #team · 2 of 7 notes · 3 of 8 to-dos · clear` (wrapping only between segments). This replaces
  the trailing "clear" in the strip, so there is one place to read and clear the filter in each layout.
- The bar's count follows the filter and says so: `To do · 1 of 3 due` while filtered (the first number is
  what the panel shows, the second the global due count), `To do · 3 due` otherwise. The global count is
  still on screen, which keeps the safety net, and the two numbers no longer contradict each other. At
  480 px the bar has room: only the next-event subject truncates.
- Same wording in the desk's label line (R3-01) so the implementer builds one filter-echo component.
