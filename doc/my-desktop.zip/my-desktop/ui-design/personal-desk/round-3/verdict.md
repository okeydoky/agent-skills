# Round 3 verdict (final round): Personal Desk ("Ledger")

Judge: neutral, round 3. Inputs: `brief.md` (incl. Addendum 1), `decision-log.md`, `round-1/verdict.md`,
`round-3/review.md`, `round-3/designer-response.md`, round-3 shots (`filter-light`, `filter-two-light`,
`by-tag-filter-light`, `notepad-filter-dark`, `tagging-light`) and the reviewer's renders (`i1-520`,
`i2-700`). I checked the two medium observations myself: `filter-light.png` at 1440 shows
`TO DO · #lakehouse · 3 of 8 · clear` with no view switch, and `i2-700.png` shows one portrait capture
filling the whole viewport below the capture slip.

## Summary table

| ID | Final severity | Verdict | One-line reason |
|---|---|---|---|
| R3-01 | medium | ACCEPT designer's fix (same as reviewer's first option) | Whether a settled control appears depends on how long a tag name is. Separate lines fix the cause. |
| R3-02 | medium | ACCEPT designer's fix | Uncapped notepad images were a recorded decision, not a silent change, but portrait split-screen captures break the mode. The decision is reopened on that evidence. |
| R3-03 | low | ACCEPT designer's fix | A visible `×` in the editor plus a footer word that names editing. Footer `#tags` keep their single meaning, which is filtering. |
| R3-04 | low | ACCEPT designer's fix | The same filter line in notepad mode, and a bar count that states both numbers. |

## Per-finding detail

### R3-01: view switch vanishes under a filter · medium · ACCEPT designer's fix
This is confirmed at 1440, the user's main width. A settled user-call control becomes unreachable in a
common state, on a top-3 task (triage), and nothing explains why. Both parties propose the same structure:
a fixed-content label row plus a separate filter line. The designer's version is more complete because it
applies to both columns and lets the line wrap only at segment boundaries. I prefer separate lines over the
reviewer's ellipsis alternative because truncating the echo would hide which tags are in the union, against
R2-03.

### R3-02: uncapped notepad screenshots · medium · ACCEPT designer's fix
**History.** `round-1/verdict.md` §C says: "Notepad mode keeps uncapped full-width screenshots." The
designer is right. The decision log's R1-03 line leaves out that clause, which is how the reviewer read it
as a contradiction. So this was not a silent divergence. **Merit:** that decision assumed landscape
screenshots. `i2-700.png` shows that a portrait capture of the neighbouring half-screen, the mode's core
use, hides every earlier note and the note's own Copy and To-do →. That is concrete new evidence on
criterion 2 (weight 20), and it is enough to reopen the decision. Medium is confirmed. The designer's cap,
`min(320px, 40vh)`, is precise and leaves the common landscape case unchanged. Use it in place of the
reviewer's approximate 35%.

### R3-03: tag removal affordance · low · ACCEPT designer's fix
Every `#word` on the page filters, and the reviewer lists that as a strength, so it stays. The editor fix
(`lakehouse ×`) and the footer label "edit tags" when tags exist answer the discoverability problem without
adding vocabulary. The `×` already exists in the capture slip.

### R3-04: notepad filter scope · low · ACCEPT designer's fix
Two numbers on one screen that disagree are a defect. `1 of 3 due` keeps the round-2 safety net (the global
due count) and agrees with the panel. There is one filter-echo component for both layouts.

## Consolidated build spec (apply once in the final consolidation)

Where this text differs from either party's, this text wins.

1. **Filter echo component (R3-01, R3-04).**
   - The label row in each desk column is one line and holds fixed-length content only. On the left is
     `TO DO` / `NOTES`. On the right is `by due · by tag` (To do only), or key hints while an item is
     selected (as now). It keeps its existing `nowrap` and overflow rules.
   - While a filter is on, a filter line sits directly under the label: full width, mono grey, built from
     nowrap segments. To do: `#lakehouse · 3 of 8 · clear`. Notes: `#lakehouse · 4 of 6 · clear`.
     Multi-tag: `#cost or #team · 2 of 6 · clear`. It wraps only at ` or ` or ` · ` boundaries, and
     `n of m · clear` stays together. The line is absent when no filter is on.
   - Notepad mode uses the same component under the tags strip:
     `#cost or #team · 2 of 7 notes · 3 of 8 to-dos · clear`. This replaces the strip's trailing `clear`.
   - Notepad bar count while filtered: `To do · 1 of 3 due` (filtered due count of the global due count,
     accent on the numbers as now). With no filter it stays `To do · 3 due`. Nothing else in the bar changes.
     At 480 px only the event subject truncates.
2. **Notepad screenshot cap (R3-02).**
   - In notepad mode (natural or forced), slip images get `max-height: min(320px, 40vh)`, full slip width,
     cropped from the top-left, with a hairline edge as in the desk layouts. The desk layouts keep ~140 px.
     The capture-slip draft thumbnail stays at 74 px.
   - Only when an image is cropped, show one mono grey line directly under it: `cropped · open`. "open" and
     a click on the image both open the existing full-size zoom.
   - Add a portrait (about 960×1080) screenshot to the seed and a `state=tall-shot` demo. Render it at
     700×900 and 480×900.
   - Design notes: replace the round-1 sentence "Notepad mode keeps uncapped full-width screenshots" with
     the rule above.
3. **Tag editing (R3-03).**
   - In every tag editor (note `+ tag`, promote receipt, open to-do), each current tag is shown as
     `lakehouse ×`: the word in ink and a mono grey `×`. On hover the word is struck through and the `×`
     turns ink. Click removes the tag, undoable as today. Tags no longer use the accent-underline picker
     style. Due words keep it.
   - The note and to-do footer edit word reads `+ tag` when the item has no tags and `edit tags` when it has
     some. Footer and row `#tags` still filter, with the tooltip "Show only #tag".
4. **Verification shots to add.** `filter` with the longest seed tag at 1440, 1425, 1280 and 960, in both
   views (by due, by tag). `filter-two` at 1440. Notepad two-tag filter at 520 (echo plus `1 of 3 due`).
   `tall-shot` at 700 and 480. `tagging-light` showing `×` and hover strike. A light/dark pair for each where
   the existing set has one.
5. **Decision log (for the orchestrator).** Record that R3-02 supersedes the round-1 notepad "uncapped"
   clause: notepad images are capped at `min(320px, 40vh)`, desk images at ~140 px.

## User-call items

1. **Notepad image cap height (R3-02).** The value between 35% and 40% of the viewport, or 280 to 320 px,
   is taste within a settled rule. Default: `min(320px, 40vh)`.

No other items are user calls.

## Count

Accepted: **0 high, 2 medium** (R3-01, R3-02), plus 2 low (R3-03, R3-04). This is the final round. All
four fixes are applied once in the final consolidation per the build spec above, with no further review.
