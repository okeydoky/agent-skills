# Round 3 — Review

Reviewer: independent, first look at this design. Judged against brief.md (including Addendum 1) and
decision-log.md. Evidence: the provided screenshots (all states, light and dark, 1440 / 1366 / 1280 / 960 /
821 / 700 / 480), plus states I rendered myself with headless Edge from a scratch copy that had a small
script added to it. That script typed and saved a `#lakehouse` note, toggled two tag filters, and
injected a portrait split-screen screenshot.

## Strengths — keep

1. **The calm agenda header.** "NOW Lakehouse pipeline design review · until 11:30 · 40 min left" and
   "NEXT 12:00 …" above a plain agenda answer "what is my day" in one glance. The red time accent is the only
   loud colour on the page, and dark mode keeps the same hierarchy (`home-light.png`, `home-dark.png`).
2. **Capture that echoes its parse.** The draft line "saves with #lakehouse · as to-do: due Mon 16" with
   "Save as to-do / Save note" (`draft-light.png`), the `#la → lakehouse · Tab · Enter: new tag #la` hint
   (`notepad-tag-complete-light.png`) and "new tag #runbook" (`tag-new-dark.png`) make tagging at capture
   time quick and easy to trust. In a scripted run, typing a note with `#lakehouse` and pressing Enter saved
   it and bumped the count to 8 with no other step.
3. **Promote in place.** "To-do →" turns the note into a receipt in the same spot, with Due words
   (none / today / tomorrow / Mon 16 / other…), the tags carried over, and Undo / Close
   (`receipt-filled-light.png`, `notepad-receipt-light.png`). The open to-do shows the source note with its
   screenshot (`todo-open-dark.png`). This is the best part of the triage flow.
4. **One tag vocabulary everywhere.** Tags look the same and filter the same way in the rail index, the
   notepad strip, item footers and by-tag headings. The filter echo "#cost or #team · 2 of 6 · clear" is
   honest about union semantics (`filter-two-light.png`). Copy is a quiet word that swaps to "Copied"
   (`copied-light.png`, `notepad-copied-dark.png`), which is what the brief asks for.
5. **Restraint.** There is no AI-slop tell anywhere. Mono labels, words instead of icons, flat tinted slips,
   and an investments route and strip that look native (`investments-light.png`).

## Findings

### R3-01 — The "by due · by tag" switch disappears whenever a tag filter is active at 1440
- **Severity:** medium
- **Rubric criterion:** 1 Task-flow efficiency (Triage); also an inconsistency that would mislead the implementer
- **Observation:** At the default 1440 × 900 width, the To do header reads
  "TO DO · #lakehouse · 3 of 8 · clear" and the "by due · by tag" switch is gone (`filter-light.png`). The same
  happens with two tags, "#cost or #team · 3 of 8 · clear" (`filter-two-light.png`, and my own render after
  clicking #cost then #team). With the short filter "#prod" the switch is still there (`by-tag-filter-light.png`),
  and at 960 it is visible with #lakehouse (`w960-filter-light.png`), because that column is wider. The
  label row is a wrapping flex line with a fixed 15 px height and overflow hidden, so the switch wraps onto a
  hidden second line.
- **Problem:** Filtering and the by-tag view are the two features the user asked for, and they collide at the
  user's main width. Whether the switch shows depends on how long the tag names are. A user who filters to
  #lakehouse cannot switch to by tag, or back to by due, without clearing the filter first. Nothing tells
  them why the control vanished. An implementer copying the mockup would ship the same disappearing control.
- **Suggestion:** Keep the view switch on a fixed line that never wraps away. For example, move the filter
  echo ("#lakehouse · 3 of 8 · clear") to its own line under the "TO DO" label, the way the parse echo got
  its own line in R2-04, and keep "by due · by tag" pinned to the right of "TO DO". Alternatively, truncate the
  echo with an ellipsis before the switch is allowed to drop. State the rule in the notes: header controls never
  wrap out of view.
- **Rationale:** A control should not vanish because of the data. The decision log treats the by-tag view as a
  settled user call, so it has to stay reachable in every filter state.

### R3-02 — In notepad mode, screenshots are uncapped, so one pasted screenshot fills the screen
- **Severity:** medium
- **Rubric criterion:** 2 Notepad mode & capture quality (weight 20); also an inconsistency with settled R1-03
- **Observation:** In full view, slip images are capped at about 140 px. In notepad mode the cap is removed.
  The demo's wide screenshots already take about 230 px at 480 wide (`notepad-light.png`) and about 325 px at
  700 wide (`w700-notepad-dark.png`), so only two or three notes fit on screen. I injected a realistic capture
  of the other half of a split screen (a 960 × 1080 doc screenshot) at 700 wide. That single note filled
  everything below the capture box and pushed every earlier note off-screen.
- **Problem:** Capture in notepad mode means screenshots of the window beside it, which is tall and narrow by
  definition. Each such paste takes over the viewport, so the user loses sight of their recent notes, which is
  the context they are writing into. They also have to scroll past it to reach the next note's To-do or Copy.
  The decision log settled "screenshots full-width, capped at ~140 px" for the notes wall, and the mockup
  silently does something else in the mode where screenshots matter most.
- **Suggestion:** Apply a cap in notepad mode too, sized to the mode. For example, cap the height at about 35%
  of the viewport (roughly 220–300 px), crop from the top-left as full view does, and use the existing
  click-to-zoom for detail. Show a quiet "1 of 1 · click to enlarge" hint only when the image was cropped.
  Write the cap into the notes as a rule for both modes.
- **Rationale:** It keeps the notes list scannable beside another window, which is the brief's own reason for
  notepad mode. It also brings the mockup back in line with a settled decision.

### R3-03 — Removing a tag from a single note or to-do has no visible affordance
- **Severity:** low
- **Rubric criterion:** 6 Discoverability
- **Observation:** In the tag editor (`tagging-light.png`, `notepad-tagging-light.png`,
  `receipt-filled-light.png`), the item's existing tags appear as underlined words ("lakehouse"). Clicking one
  removes it, but the only cue is a hover tooltip ("Remove #lakehouse"). There is no ×, strikethrough or
  hover change that says "click to remove". In the slip footer, "#lakehouse" sits right next to "+ tag", yet
  clicking it filters the whole page instead of editing the note's tags.
- **Problem:** Adding a tag after the fact is easy, but correcting a wrong tag means guessing that an
  underlined word is a toggle. A user who clicks the footer's "#lakehouse" to change it sees the whole page
  filter instead. That is surprising, but recoverable.
- **Suggestion:** In the tag editor, render the item's own tags as "lakehouse ×", or show a strikethrough
  preview on hover. Keep footer #words as filters, but rename "+ tag" to "tags" (edit) so it clearly owns
  both adding and removing.
- **Rationale:** It is a small, cheap change that makes after-the-fact tag edits, which Addendum 1 requires,
  discoverable without changing any flow.

### R3-04 — Notepad mode hides the filter's scope: no "N of M / or" echo, and the top-bar due count ignores the filter
- **Severity:** low
- **Rubric criterion:** 3 Visual hierarchy & calm / 2 Notepad mode
- **Observation:** With #cost and #team selected at 520 wide (my render), the notepad shows two underlined
  tags and "clear", but not the "#cost or #team · 2 of 7" echo that full view shows. The top bar still reads
  "To do · 3 due", although only one due to-do matches the filter (`notepad-filter-dark.png` shows the
  single-tag case).
- **Problem:** In notepad mode the user cannot tell that the list is filtered to a union, or how much is
  hidden. The due count disagrees with what opening To do will show.
- **Suggestion:** Add the same echo line under the notepad tag strip ("2 of 7 · #cost or #team") and make the
  top-bar count follow the filter, or label it "3 due · all" while a filter is on.
- **Rationale:** The filter state should read the same in both modes, consistent with R2-03's wording rule.

No finding is marked "Bold alternative". This round does not need one: the remaining issues are local fixes.
