# Personal Desk — "Ledger", round 3

Standalone design note for `round-3/design.html`, written so an implementation session can build from it.
Screenshots are in `round-3/shots/`: `<state>-light.png` / `<state>-dark.png` at 1440×900 unless the name
carries a width; `notepad-*` and `footer-480` at 480×900 through an iframe (headless Edge will not lay out
a window narrower than about 500 px).

## The idea

The page is looked at far more often than it is operated, so it is set like a printed ledger page:
columns of type separated by whitespace and hairlines, nothing boxed, nothing that moves unless asked.

Three rules carry the design:

1. **The page is print; only notes are objects.** A note is the only thing with a surface (a flat tinted
   slip, no border, no shadow). Shortcuts, events, to-dos, tags and every future section are type on paper.
2. **Accent means "this needs you now", and nothing else.** One colour, one meaning.
3. **One list grammar.** Day, To do, Earlier, Tags and section tables are rows of *mono key · text · grey
   mono word*, with a left rule where state matters.

And one sentence for to-dos: **To-dos are ordered by due date and filtered by tag; tags never group the
default list.** A second view, *by tag*, is the user's explicit choice and lists a to-do under every one of
its tags, so no tag is ever privileged.

## Layout and width ranges

Zones: **Go** (shortcuts, then the tag index) · **Today** (headline, Now/Next, Day, To do) · **Notes**
(capture slip, then slips, newest first). A masthead above (wordmark, text nav, Notepad toggle, Theme
toggle). Section strips sit under the Go + Today zones.

| Viewport width | Layout | What has given way |
|---|---|---|
| ≥ 1360 | Go (160) · Today · Notes. Inside Today, Day and To do side by side, starting on the same line. | Nothing. |
| 1200–1359 | Go · Today · Notes. Inside Today, Day stacked above To do. | Day / To do side by side. |
| 821–1199 | Two columns: Today · Notes. Go becomes the Go field and one wrapping line of shortcut links above Today, then one line of tags. | The rail as a column. |
| ≤ 820 | Notepad mode, content capped at a 608 px measure. | Everything except capture and notes (panels on demand). |

**Order of giving way:** Day/To do side-by-side first, then the rail, then everything but capture and
notes.

Floors: rail 160, Day 280, To do 280, Notes 340. Notes is one column at every width. Page margin 44 px
(28 px in the two-column range), column gap 48 px (40 px). The page reserves the scrollbar gutter
(`scrollbar-gutter: stable`) so a real window with a scrollbar lays out exactly like one without.

Fixed at every width:
- section labels never wrap (key hints are dropped first);
- a note's **Copy** and **To-do →** sit at the right of the first footer line and never move;
- the date headline stays on one line;
- a section strip is one line.

Forced notepad ("Notepad" in the masthead, `mode=notepad`) works at any width and shows "Full view".

Why 820: halves of 1366, 1536 and 1600 px displays (683, 768, 800) are the common split-screen windows;
820 keeps the boundary off 800.

## Visual tokens

One token set; the dark theme re-declares the same names. Theme follows the OS; a toggle cycles
auto → light → dark and is stored; `#theme=` overrides.

| Token | Light | Dark | Use |
|---|---|---|---|
| `--paper` | `#FAFAF6` | `#121211` | page |
| `--ink` | `#171715` | `#ECEBE4` | primary text, event rules, checked boxes, last-used dot, selected tag |
| `--ink2` | `#5B5B54` | `#A6A59C` | secondary text, times, response words, Copy |
| `--ink3` | `#8A897F` | `#737269` | labels, hints, aliases, `#tags`, gap rows, elapsed and declined events |
| `--line` | `#E3E2D9` | `#2A2A27` | hairlines |
| `--line2` | `#CCCBC0` | `#3D3D38` | stronger hairline, image edge, field and control underlines |
| `--slip` | `#F0EFE5` | `#1E1E1B` | note surface, the only surface |
| `--slip-in` | `#E6E5DA` | `#292925` | reserved, unused |
| `--accent` | `#C5411C` | `#FF6A3D` | "needs you now" |

Accent appears only on: NOW label and clock, the running event's rule or the now tick, the Due heading,
late dates and the "n due" count, the capture slip edge, the keyboard selection hairline, a focused
field's underline, the top edge of a promote receipt, the arrow in "To-do →", a drag target's underline,
the chosen word in a picker. Links, tags and filters are never accent. Investments shows direction with
+ and −.

Type: **Instrument Sans** 400/500/600 for everything read; **IBM Plex Mono** 400/500 for times, dates,
figures, labels, aliases, tags and hints. Fallbacks `system-ui, Segoe UI` and `ui-monospace, Cascadia
Mono, Consolas`. Scale: 11 mono label/hint/tag · 13.5 agenda · 14 notes and rail children · 14.5–15
to-dos and links · 17 Now/Next · 30 headline. Screenshots in dark theme are dimmed to 86 % brightness.

Spacing: 4 px base; 48 between columns, 26–30 between blocks, 10 between slips. Radius: 0 on slips, 3 px
on checkboxes. No shadows. Metadata is always words; no icons, no pills, no colour per tag.

## Interactions

### Launch: Go
- Shortcuts are plain text links, one click each. A group is a row with a count (`3 +`); clicking expands
  it inline and the open state persists. An ink dot marks the last-used environment; a collapsed group
  prints it beside the name ("Azure • Portal") as a direct link.
- **Go field:** `/` focuses it from anywhere, a selected row included. A name, part of one, or an alias,
  then Enter. `db` → Databricks, last-used first. `db p` → Databricks Prod. `inv` → Investments section.
  `#co` → the `#cost` filter (prefix matching is automatic here, because Go searches and never writes).
- Aliases are hidden at rest and print in mono grey while Go has focus.
- Rejected: hover fly-outs, a favicon grid, group click opening a default environment, always-visible
  aliases, an always-focused omnibar that merges launch and capture.

### Launch: shortcut editing (rare path)
"Edit" under the shortcuts (also in Settings) makes the rail editable in place: `::` handle to drag within
a level, click a name for Name / URL / Alias fields (group: Name, Alias; environment: Name, URL, Key) plus
Up, Down, Remove; "+ link" inside groups, "+ Add link", "+ Add group", "Done". Remove is undoable.
Rejected: a modal manager or settings table; the rail is edited where it stands.

### Launch: the day
- **Now / Next** sentences, the largest text after the date: "Now *subject* until 11:30 · 40 min left
  · +1 overlapping", "Next 12:00 *subject* in 1 h 10 min · tentative". Declined never counts. No running
  event reads "Free until 12:00". These never truncate.
- **Day is one agenda list**, the same component at every width and in the notepad Day panel.
  - One row per event: mono time range in a fixed 86 px column, subject, then the response word in grey
    mono (tentative / no reply / declined only). Subjects wrap; the tooltip has the full text.
  - Left rule carries the response: solid accepted or organizer, dashed tentative, dotted no reply, none
    plus struck grey text for declined. The running event's rule is accent and its subject is bold
    (settled by the user).
  - Chronological. Declined events stay in place and are ignored for overlaps and gaps.
  - Overlap: an event that starts before the previous non-declined one ends is indented 14 px.
  - Gaps of 30 minutes or more: one quiet mono row, `free 1 h 15 min`, upcoming only.
  - Elapsed events fold into "EARLIER · n +", collapsed by default, in both modes.
  - Now in a gap: a short accent tick at the top of the list. No time label; the time is printed once,
    beside the date.
- Empty day: "No events. The day is yours." After the last event: "Nothing else today."
- Times are local, 24-hour. Demo events are authored as UTC strings in both real formats
  (`…T21:30:00.0000000Z`, `…+00:00`) and go through one parser that trims the 7-digit fraction.
- Rejected after round 1: the proportional timeline (truncated overlaps and long subjects, needed twice
  the height).

### Capture
- The capture slip is the first object in Notes, always present. **Enter saves, Shift+Enter adds a line,
  Ctrl+Enter saves as a to-do.** Focus stays in the field.
- **A saved note appears directly under the capture slip** (one column, newest first, at every width).
- **Type anywhere, on every route:** with no field focused and no row selected, a printable key starts a
  note. **Ctrl+V with an image, on every route**, adds it to the draft as a removable thumbnail. On
  Investments or Settings the text lands in a one-line masthead field ("Saved to notes · Undo"); in
  notepad mode the capture slip stays under the bar on every route.
- One draft, persisted across reload, route and mode.
- **Hint line.** At rest: `Enter saves · #tag · Ctrl+V image` (or `Enter saves with #lakehouse` under a
  one-tag filter). Once the draft has content the footer is two rows: the **parse echo** on its own
  full-width line, then "Save as to-do" and "Save note" right-aligned below. The echo is built from
  `nowrap` segments joined by ` · `, so it can only break at a separator:
  `#la → lakehouse · Tab` · `new tag #runbook` · `saves with #lakehouse` · `as to-do: due Mon 16`.
  Key names stay out of the echo; they are in the rest hint and the buttons' tooltips. An empty echo
  takes no line.
- Slip: text, then screenshots at full slip width, capped at 140 px high in the desk (top-left crop,
  hairline edge, click to open full size); uncapped in notepad mode.
- Notes are edited in place by clicking the text.

### Note footer
- **Two cells, `1fr auto`, aligned on the first line.**
  - Right cell: **Copy** and **To-do →**, `nowrap`, pinned right. They never move, whatever the tags.
  - Left cell: time, then the note's tags as mono grey `#words` (alphabetical), then "+ tag" and "delete".
    Only this cell wraps, and it wraps between whole items.
- On desk layouts "+ tag" and "delete" take no width at rest (`display: none`); they appear on slip hover
  or keyboard focus, at the end of the left cell. In notepad mode they are always shown.
- **Copy** puts the note's text only, never the image, on the clipboard. It is a regular-weight grey word,
  lighter than "To-do →". After a click it reads "Copied" in primary ink until the next click or key
  press anywhere: no toast, no timer. Image-only notes have no Copy. `c` copies the selected note.
- Verified with the two-tag (`#cost #prod`) and three-tag (`#lakehouse #prod #team`) older seed notes at
  1440, 1425 (1440 minus a scrollbar), 1424 with the hover controls showing, 1280, 1265, 821, 700 and 480
  (`footer-*.png`).

### Triage: promote
- Every slip prints **"To-do →"**. One click, or `t` on a selected slip, creates the to-do at once.
- The slip becomes a **receipt** in the same position: `→ TO DO · #cost #prod` (all its tags, or
  `→ TO DO` alone), the editable title, "note + image attached", Due as words, Tags, Undo, Close. Ignoring
  it is a valid finish. No timer.
- The note leaves the notes column and travels with the to-do, **with its tags**. The to-do row says
  "note + image"; opening the row shows the original slip and screenshot; "Return to notes" puts it back.
- Title = first sentence of the note.
- **Drag "To-do →" onto a tag word in the rail** to promote it and add that tag, or onto the `DUE`
  heading to make it due today. Feedback is an accent underline on the target only. Not offered in
  notepad mode. Rejected: tag headings in the to-do list as drop targets (they no longer exist).

### Triage: to-dos
- **One list, one order, no tag headings.** Sections, each shown only when non-empty:
  - `DUE` — overdue first (oldest first), then due today. "1 d late" in accent, "today" in bold ink.
  - `LATER` — dated to-dos by due date, then undated ones, newest first.
  - `DONE EARLIER · n +` fold.
- **Row:** checkbox · title · tags · due date (right-aligned mono). Tags appear once, alphabetical, in mono
  grey. The last word of the title, the tags and the "note + image" marker sit in one `nowrap` span, so a
  tag is never alone on a line. At most two tags, then `+N` (the full list in its tooltip and in the open
  to-do).
- "Add a to-do" accepts `#tag @due`; the echo under the line shows the result before Enter.
- Checking strikes the row in place for the session; on next load it folds into "DONE EARLIER".
- Clicking a title opens the row inline: editable title, Due words, Tags, the source note, Return to
  notes, Delete (undoable).
- Rejected this round: grouping under each to-do's first tag (a hidden primary tag, i.e. a project set by
  typing order; the rail and the headings disagreed).

### Triage: the "by tag" view (user decision, round 3)
- **Switch:** `by due · by tag` at the right of the To do label, in the label's mono grey; the current view
  is ink and underlined. While a to-do is selected the keyboard hints take that place (`by-tag-*.png`).
- **By due** is the default and is the list described above.
- **By tag:** one heading per tag, in the Tags list's order, each with its count in grey (`LAKEHOUSE 3`);
  untagged to-dos last under `NO TAG`. **A to-do with several tags is listed under each of them.** Within
  a group, due order (dated by due, then undated newest first). Late and today dates keep their accent and
  bold, so "what is due" stays readable inside every group. A heading is also a one-click filter.
- **The same item everywhere.** Every copy of a row is the same to-do: checking, editing, deleting or
  tagging one updates all of them at once. Its inline detail opens under the first copy only. Rows look
  identical in every group (all tags shown), which is the cue that it is one item.
- `DONE EARLIER` stays a single flat fold at the end, so a finished multi-tag to-do is not repeated.
- **With a tag filter:** the filter decides *which* to-dos show (any selected tag, plus the visibility
  rule); the view decides *how*. A shown to-do is listed only under the **selected** tags it carries, so
  with one tag selected the list is that tag's single group, and `#cost or #team` shows a COST and a TEAM
  group with shared items in both. To-dos kept visible by the visibility rule that carry none of the
  selected tags appear under their own tags (or NO TAG). `by-tag-filter-*.png`.
- **Persistence:** the chosen view is a preference and is remembered across sessions (stored with the
  data), unlike the filter, which is a momentary question and resets. Rationale: someone who thinks in
  projects will want that view every morning; a forgotten filter would silently hide work.
- **Layouts:** identical in every range. In 821–1199 and 1200–1359 To do sits under Day, so the grouped
  view is longer there; it is still the user's choice. In notepad mode the switch sits on the To do
  panel's label and the panel renders the same groups (`notepad-by-tag-*.png`).
- **Keyboard:** repeated rows are separate stops for `j`/`k`; `x` on any copy completes the to-do.
- Rejected: grouping under one tag per to-do (round 2's hidden primary tag); collapsing duplicate rows to a
  "also in #prod" note (hides the item from the group the user scans); persisting the filter instead of
  the view.

### Tags and the filter

**Decision (round 2, kept): tags replace projects.** One vocabulary for notes and to-dos. Round 3 removes
the last trace of projects: there is no primary tag and no grouping.

**Entering tags.**
- At capture and in "Add a to-do": `#word`. An exact match uses the existing tag. Otherwise **Enter saves
  the word exactly as typed**, creating the tag; the echo says `new tag #runbook` first.
- **Completion is an offer.** While the caret is at the end of a `#word` that is a proper prefix of
  existing tags, the echo shows `#la → lakehouse · Tab` (up to three candidates, most used first). Tab
  replaces the word with the first candidate. No cycling. Tab is intercepted only while an offer shows,
  so focus moves normally otherwise. With an offer showing the new-tag segment reads
  `Enter: new tag #la`, so both outcomes are stated.
- **After the fact:** "+ tag" on a note (or `#` on a selected slip), and the Tags row in the receipt and
  in the open to-do. All three are the same control: the current tags as words (click one to remove it),
  then an "add tag" field with the same completion rule (`#` not needed). Enter adds and keeps the field
  focused for the next tag; Esc closes.
- Tags are lower-case words matching `[a-z0-9_-]+`; anything else is dropped from the word.

**Filter (the Tags list is the only filter control).**
- Desk ≥ 1200: "TAGS" block in the rail under the shortcuts, one word per row with a count (notes + open
  to-dos). 821–1199: one line under the shortcut links. Notepad: one line under the capture slip. Clicking
  a `#word` on any row or slip toggles that tag too.
- Click toggles a tag; "clear" removes all. The filter applies identically to notes, to-dos and the Done
  fold. Day, Go and strips are untouched; a promote receipt always stays visible.
- **One tag selected = a context.** Labels: `NOTES · #lakehouse · 3 of 6 · clear`,
  `TO DO · #lakehouse · 3 of 8 · clear`. Capture and "Add a to-do" stamp that tag; the hint reads
  `Enter saves with #lakehouse`.
- **Two or more selected = a query (union).** Labels use "or": `TO DO · #cost or #team · 3 of 8 · clear`.
  Nothing is stamped; the capture hint is the normal rest hint.
- **Visibility rule:** anything created or promoted while a filter is on stays shown until the filter next
  changes, whatever its tags. A note never disappears on save.
- Empty result: `No to-dos tagged #x · clear` / `No notes tagged #x · clear`, in the muted style.
- Clearing: "clear" in either label or beside TAGS, click the selected tag again, or Esc with nothing
  focused. The filter is session state and is not persisted.
- Rejected: intersection ("all of"), because most items carry one tag; a filter bar above the columns,
  because the Tags list already is one and the labels state the result.

### Tag rename and remove (rare path)
Handled like shortcut editing: in place, where the tags are listed (`tags-edit-*.png`).
- "Edit" under the Tags list (also Settings › Tags) turns it into an edit list: each tag a dashed-underline
  name with its count.
- Click a name: a Name field opens under it with a usage line (`on 2 notes, 1 to-do`) and "Remove tag".
- **Rename:** type and press Enter (or leave the field). Every note, to-do and promoted note carrying the
  tag is updated; an active filter follows the new name. If the new name is an existing tag, the two
  **merge**; the usage line says `merges into #cost · Enter` before it happens.
- **Remove:** the tag is taken off every item that carries it. Items themselves are never deleted; a to-do
  or note left with no tags is simply untagged.
- Both are undoable from the Undo line ("Tag #prod renamed #production · Undo", "Tag #team removed ·
  Undo").
- "Done" returns the list to filter mode. In notepad mode the same list opens from the Go panel's line.
- Rejected: a separate tag-management page (one more route for a rare task), confirming removal in a
  dialog (Undo is cheaper and the page has no modals).

### Keyboard
- **Selection is entered by keyboard only:** `↓` with nothing focused (first to-do; first note in notepad
  mode), `↓` in an empty capture or add field, or Tab. A mouse press on a row never selects it.
- **While a row is selected, keys are verbs only**; other letters do nothing. `j`/`k` or arrows move,
  `←`/`→` switch between to-dos and notes, `u` undoes, `/` goes to Go, Esc leaves selection.
  - To-do: `x` or Space done, Enter opens, `#` opens it at its tags, Del deletes.
  - Note: `t` makes it a to-do, `c` copies its text, `#` opens its tags, Enter edits, Del deletes.
- With nothing focused, Esc clears an active tag filter.
- The selection is a 2 px accent hairline at the row's left. Key hints, ending in "esc to type", print at
  the right of the column label only while that column holds the selection.
- Undo is one level: promote, return, deletes, shortcut removal, tag rename/merge/remove.
### Notepad mode (≤ 820 px, or forced)
- Order, always: one-line sticky bar → capture slip → tags line → one optional panel → notes stream.
- Bar: clock; "until 11:30 · next 12:00 *subject*" (only the subject truncates); "To do · 3 due" (accent
  on "3 due"), or "To do · 8" when nothing is due; "Go"; "Full view" only when forced. The toggles are
  underlined like every other text control.
- Capture is auto-focused on entering the mode and never moves; panels (the same Day agenda, To do, Go +
  routes + theme) open below it.
- Tags, filter, promote, receipt, copy, completion and keyboard selection work the same.

### Empty states
One quiet sentence each: no events, no to-dos, no notes, no shortcuts, no match under a filter.

## Rules for adding a section

1. A section is **a route** with one word in the masthead nav **and an alias in Go** (`inv` + Enter).
2. It may place **one strip** on home, under the Go and Today zones. The strip is **one line, always**,
   every item `nowrap`. Guaranteed: label, one headline figure, one change figure, and the `as of … →`
   link pinned right. Further detail items show only if they fit and **drop whole from the right**; they
   are never clipped mid-item. The whole line links to the route.
3. Inside its route it uses the list grammar only: 30 px headline, mono caps labels, hairline-ruled rows,
   mono figures. **No surfaces**, no shadows, no new colours.
4. Accent means "needs you now". Direction of a number is a sign, not a colour.
5. Capture is global: typing or pasting on the route goes to the notes draft. A section never adds its own
   input to home; to feed to-dos it promotes notes. If it has items worth tagging, it uses the same tag
   vocabulary and the same filter, never its own.
6. In notepad mode it opens under the capture slip, is listed in the Go panel, and its strip is hidden.

## State model (for the app specification)

Persisted:

| Key | Shape | Notes |
|---|---|---|
| `notes[]` | `{id, ts, text, images[], tags:Set<string>}` | `text` holds no `#tags` (extracted on save). |
| `todos[]` | `{id, title, due:YYYY-MM-DD\|null, tags:Set<string>, done, note?:Note}` | No project, no primary tag; tag order carries no meaning. `note` is the promoted note, tags as they were. |
| `tags[]` | ordered `string[]` | The vocabulary; creation order drives the Tags list. Tags with no notes and no open to-dos are hidden from the list but kept in the vocabulary (offered by completion, shown in edit mode). |
| `shortcuts[]` | `{id, n, u, a}` or `{id, n, a, kids:[{id, n, u, a}]}` | `a` = alias (group) or key (environment). |
| `groupsOpen`, `lastUsed` | `{groupId: bool}`, `{groupId: kidId}` | |
| `draft` | `{text, images[]}` | Survives reload, route and mode. |
| `todoView` | `due` \| `tag` | Remembered preference; default `due`. |
| theme | `auto` \| `light` \| `dark` | |

View state, never persisted: `filter: string[]`, `keep: Set<id>` (items created under the current filter;
cleared whenever the filter changes), selection, open to-do, receipt, `copied`, tag-edit mode, Earlier and
Done folds.

Derived rules:
- To-do order (by due): `DUE` = `due <= today`, sorted by due then creation; `LATER` = dated by due, then
  undated newest first.
- By tag: for each shown to-do, groups = (its tags ∩ selected tags) if a filter is on and that is non-empty,
  else its tags, else `NO TAG`; groups in vocabulary order; due order inside; one item, many rows.
- Filter: an item is shown if `keep` has it, or no tag is selected, or it carries any selected tag.
- Stamp: with exactly one selected tag, new notes and to-dos get it.
- Promote copies `note.tags` into `todo.tags`; return restores the note as it was.
- Rename `a → b`: replace in every note, to-do and `todo.note`; if `b` exists, merge (set union) and drop
  `a` from the vocabulary. Remove `a`: delete from every set and from the vocabulary.
- Copy reads `note.text` only.

## Demo states (URL hash)

Combine with `&`. Any `state=` boots from fresh sample data and never writes storage. Without `state=`
the page persists to `localStorage` (key `deskA.r3`); `reset=1` reseeds.

| Hash | Shows |
|---|---|
| `state=home` | default desk, 10:50, an event running |
| `state=home&now=08:50` | full morning: tick, all eight events, long subject, overlap indent, gaps |
| `state=home&now=13:10` | in a gap |
| `state=earlier` | Earlier fold expanded |
| `state=filter` | one-tag filter (`#lakehouse`): context labels, stamped capture hint |
| `state=filter-two` | two-tag query (`#cost or #team`), rest hint |
| `state=footer-check` · `footer-hover` | filter `#prod`: the two- and three-tag older notes first; hover variant focuses the first slip |
| `state=tag-complete` | draft `…#la`, echo offers `#la → lakehouse · Tab` |
| `state=tag-new` | draft with `#runbook`: `new tag #runbook` |
| `state=tagging` | "+ tag" open on a note, add field focused |
| `state=tags-edit` | Tags list in edit mode, `prod` open (rename / remove) |
| `state=copied` | "Copied" in a note footer |
| `state=draft` | capture with text, `#lakehouse @mon` and a pasted screenshot: two-row echo |
| `state=receipt` · `receipt-filled` | a note just promoted, receipt |
| `state=promoted` · `todo-open` | a to-do open with its source note and screenshot |
| `state=cursor-todo` · `cursor-note` | keyboard selection, key hints in the label |
| `state=token` | "Add a to-do" with `#cost @fri` and its echo |
| `state=drag` | a rail tag as drop target |
| `state=by-tag` | the by-tag view; a two-tag to-do under COST and PROD |
| `state=by-tag-filter` | by tag under the `#prod` filter: a single PROD group |
| `state=by-tag-done` | by tag after checking the two-tag to-do: struck in both groups |
| `state=note-deleted` · `done` | Undo line · two to-dos checked in place |
| `state=group-open` · `go-focus` · `go` · `go-section` | groups open · aliases visible · `db p` · `inv` |
| `state=edit-shortcuts` | rail in edit mode |
| `state=empty-day` · `no-notes` · `no-todos` · `empty-all` | empty states |
| `state=route-capture` | Investments with a note typed in the masthead |
| `route=investments` · `route=settings` | secondary routes |
| `theme=dark` · `theme=light` · `mode=notepad` | force theme · force notepad mode |
| `panel=day` · `panel=todos` · `panel=go` | notepad mode with that panel open |
| `now=HH:MM` | move the pinned clock (default 10:50, Fri 13 Nov 2026) |

By-tag renders: `by-tag-*` at 1440 (light, dark), `by-tag-w1280x720`, `by-tag-w960`, `notepad-by-tag-*`.

Width renders in `shots/`: `w1366x768`, `w1280x720` (default, 08:50), `w1265x1100`, `w960` (default,
filter, tags-edit, draft), `w821`, `w700-notepad`, `forced-notepad-1440`, `footer-{1440,1425,1424-hover,
1280,1265,821,700-notepad,480}`.

## Changes from previous round (round 2 → round 3)

| Finding | Verdict | What changed |
|---|---|---|
| R2-01 "To-do →" wraps on two-tag notes | accept merged | Footer is two cells (`1fr auto`); Copy and To-do → pinned right on line one; only the left cell wraps; "+ tag" and "delete" take no width at rest; `scrollbar-gutter: stable`. Checked at 1440/1425/1424-hover/1280/1265/821/700/480. |
| R2-02 hidden "first tag" grouping | accept, via R2-08 | No primary tag, no tag headings; `todo.tags` is a set. Receipt header shows all tags. Drag-to-file targets are the rail's tag words. |
| R2-03 two-tag filter | accept merged | "or" in labels; one tag = context (stamps), two or more = query (stamps nothing, rest hint); items created under a filter stay shown until it changes; empty-result line with clear. |
| R2-04 capture hint wraps | accept merged | Echo on its own line above the actions, built from nowrap segments, no key names; empty echo takes no line. |
| R2-05 orphaned tag | accept merged | Last title word + tags + back-link in one nowrap span; two tags then `+N`; alphabetical. |
| R2-06 `#prefix` auto-resolves | accept, simplified | Enter saves the word as typed (`new tag #x` announced); completion offered as `#la → lakehouse · Tab`, up to three, Tab takes the first, no cycling; same in the tag field. Go keeps automatic prefix match. |
| R2-07 strip wraps at 1280 | accept merged | One line; label, figure, change and "as of →" guaranteed; tickers drop whole from the right. Written into section rule 2. |
| R2-08 flat due-ordered list | accept merged | `DUE` · `LATER` · `DONE EARLIER` is the default list; tags filter. |
| User decision: "by tag" view | user call, resolved: include | `by due · by tag` switch on the To do label; by tag lists a to-do under each of its tags, `NO TAG` last, due order inside; one item, many rows; under a filter only the selected tags head groups; the view is remembered, the filter is not; same in mid and notepad layouts. |
| Own gap: tag rename/remove | designer | Edit mode on the Tags list, as with shortcuts: rename (with merge), remove from all items, both undoable; also from Settings. |
| Seed data | — | The 11:20 note carries three tags to exercise the footer. |

Kept from the round-2 review's strengths: the NOW / NEXT pair; instant promote with an in-place receipt
(same component at 480); notepad mode as a real mode with panels under the capture slip; one typographic
system and a single accent in both themes, with the native-looking Investments route; tags as the single
organising concept with the filter stated in the rail, both column labels and the capture hint.

## Open questions

None from the user. One for the implementation session: whether the remembered `todoView` should also be
per-device (it is stored with the data in the mockup).

## Known stubs and mockup shortcuts the real app must do differently

- Shortcut links open in a new tab here; the real start page should navigate in place.
- The clock is pinned; the real app re-renders Now/Next, the fold, gaps and the tick each minute.
- Pasted images are downscaled to 1100 px JPEG and stored in `localStorage`; the real app should store
  blobs on disk or in IndexedDB.
- Copy uses `navigator.clipboard.writeText` with an `execCommand('copy')` fallback for `file://`; the real
  app, served from localhost, should need only the first.
- Calendar data is in-memory; the real app reads the events file (Settings describes the source only).
- Settings: theme, shortcut editing, tag editing and reset are live; calendar source, clock format and the
  Enter preference are described only. Investments data is static.
- Undo is a single snapshot of notes, to-dos, tags and shortcuts, not a history.
- Dragging "To-do →" uses native HTML drag and drop; the drag state in the shots is simulated.
- The 480 px shots use a 495 px iframe cropped to 480, so the page's reserved scrollbar gutter falls
  outside the picture; a real narrow window shows its scrollbar there.
- Tag counts are computed on every render; fine for hundreds of items, index them if that grows.
- Not exercised by hand: native drag and drop, the date picker popup, real clipboard paste and copy.
  Completion, filter stamping, the visibility rule, rename/merge/remove with undo, and footer geometry
  (Copy and To-do → on the first line, inside the slip, on all 11 slips) were checked by script in a
  browser with a 16 px scrollbar.
