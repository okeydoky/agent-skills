# Round 2 verdict — Personal Desk ("Ledger")

Judge: neutral. Basis: `brief.md` (incl. Addendum 1), `decision-log.md`, `round-2/review.md`,
`round-2/designer-response.md`, the round-2 shots (`home-light`, `filter-two-light`, others) and the
reviewer's renders (`w1280tall`, `w1280draft`). Every observation below was checked against a screenshot;
all eight are visible as described. Settled decisions were not re-opened.

## Summary table

| ID | Final severity | Verdict | Reason |
|---|---|---|---|
| R2-01 | medium | ACCEPT merged | Primary Triage gesture changes position per note (seen in `w1280tall`); breaks the settled R1-04 rule. Two-zone footer + stable scrollbar gutter. |
| R2-02 | medium | ACCEPT reviewer's option (a), i.e. resolved by R2-08 | "First tag" is an unstated, unchangeable project; rail says `prod 2` but there is no PROD group. Remove the rule rather than document it. |
| R2-03 | low | ACCEPT merged | Union must be worded "or"; a multi-tag selection is a query and must not write tags. Designer's "created items stay visible" rule covers the vanish case. |
| R2-04 | low | ACCEPT merged | Hint breaks into three lines with an orphan "16" (`w1280draft`). Own full-width line, short nowrap segments. |
| R2-05 | low | ACCEPT merged | Lone `#prod` line in `home-light`. Bind tags to the title's last word; cap at two tags + "+N". |
| R2-06 | low | ACCEPT designer's fix (simplified) | Completion is an offer accepted with Tab; Enter saves what was typed. No cycling. |
| R2-07 | low | ACCEPT merged | Strip wraps at 1280. One line always; whole items drop from the right (no mid-item clipping). |
| R2-08 | medium | ACCEPT merged | Flat due-ordered list is the default and the only view built in round 3; "by tag" view is a user call, default = leave out. |

## Per-finding detail

### R2-01 — "To-do →" wraps on two-tag notes — medium — ACCEPT merged
Confirmed in `w1280tall.png` ("Prod DBU spike…": Copy top right, To-do → bottom left). Severity stands:
the promote control is the Triage gesture, it moves on exactly the notes triaged next morning, and it
re-breaks a settled decision. Both parties propose the same structure; build the designer's two-cell
footer and add the reviewer's `scrollbar-gutter: stable`. The designer's "also shoot at 1425 / 1265" is
process, adopted.

### R2-02 — hidden "first tag" grouping — medium — ACCEPT, resolved by R2-08
Confirmed in `home-light.png` (COST heading holds a `#prod` to-do; no PROD heading; rail lists prod 2).
Medium is right: it misleads the implementer (no rule for removal, order, re-filing) and silently
reintroduces a second organising concept, against Addendum 1's "one concept preferred". Of the reviewer's
three options, (c) keeps two concepts and (b) as a default doubles rows in the column whose job is "what
is due". Option (a) wins on criteria 1, 3 and 5.

### R2-03 — two-tag filter — low — ACCEPT merged
Confirmed in `filter-two-light.png` (`#cost #team · 3 of 8`, hint "Enter saves with #cost #team"). Low is
right (multi-tag filtering is occasional). Take the "or" wording and single-tag-only stamping (both agree),
plus the designer's rule that anything created in the current view stays shown until the filter changes.
For the multi-tag hint use the plain rest-state hint (reviewer) rather than "no tag added": it is the
existing string and needs no new state.

### R2-04 — capture hint wraps — low — ACCEPT merged
Confirmed in `w1280draft.png`. Hint moves to its own full-width line above the two actions; key reminders
drop while the draft has content (both agree). Use the designer's wording because it is truthful about
what `@due` does (it only applies when saved as a to-do); the reviewer's `→ #lakehouse · due Mon 16`
would imply a note gets a due date.

### R2-05 — orphaned tag line — low — ACCEPT merged
Confirmed in `home-light.png`. Designer's last-word binding is the reviewer's first option; add the
reviewer's "+N" cap so three tags cannot push a row to three lines. Matters more after R2-08 because
every row now carries all its tags.

### R2-06 — `#prefix` auto-resolves — low — ACCEPT designer's fix, simplified
Both want completion as an explicit offer. Designer's Tab rule is accepted; **Tab cycling through several
candidates is rejected** (extra state in a textarea for a rare case, criterion 7): the hint lists up to
three candidates and Tab takes the first (most-used).

### R2-07 — investments strip wraps at 1280 — low — ACCEPT merged
Confirmed in `w1280tall.png`. Designer's rule is accepted with one correction from the reviewer: detail
items are dropped whole from the right, never clipped mid-item.

### R2-08 — flat, due-ordered list — medium — ACCEPT merged
Both parties agree; checked against the rubric rather than taken on agreement. At 1280 and 960 To do sits
under Day, and five headings for eight items push due work down (`w1280tall`); under a filter the tag
heading only repeats the filter label (`filter-light`). The user's wording asks for tags plus a filter
that shows only the selected tag, and offers that tags "maybe replace" grouping: a filter-only model
meets that literally, with one mechanism for notes and to-dos. The designer's "by due · by tag" toggle is
not built by default: a single-tag filter already *is* that tag's group, and the toggle adds chrome, a
second render path and duplicated rows. It is flagged as a user call below.

## Consolidated build specification for round 3

### A. To-do list (R2-02, R2-05, R2-08)
1. **One list, one order, no tag headings.** Sections, each shown only when non-empty:
   - `DUE` — overdue first (oldest first), then due today. Accent treatment as now.
   - `LATER` — dated items ascending by due date, then undated items, newest first.
   - `DONE EARLIER · N +` fold, unchanged.
2. **Row:** checkbox · title · tags · due (right-aligned, as now). Tags are shown once per row, in
   alphabetical order, in the existing small mono `#tag` style. The last word of the title and the tag run
   sit in one `nowrap` span, so a tag is never alone on a line. Show at most two tags, then `+N`; the open
   to-do shows all of them. The `note + image` back-link marker follows the tags in the same span.
3. **Data model:** `todo.tags` and `note.tags` are sets of lowercase strings; order carries no meaning.
   There is no primary tag, no project field, no heading logic.
4. **Receipt header:** `→ TO DO` followed by all the to-do's tags (`→ TO DO · #cost #newtag`), or
   `→ TO DO` alone if untagged.
5. **Drag to file (optional gesture, settled in Phase 2):** drop targets are the tag words in the rail
   (desk) — dropping promotes the note and adds that tag. Keep the existing `DUE` drop target if round 2
   has one. No drop targets inside the to-do list other than that.
6. **Design notes must state the rule in one sentence:** "To-dos are ordered by due date and filtered by
   tag; tags never group."

### B. Tag filter (R2-03)
1. The Tags list (rail on desk, tags strip in notepad mode) is the only filter control. Click toggles a
   tag; `clear` removes all. The filter applies identically to notes, to-dos and the Done fold.
2. **One tag selected = a context.** Labels: `NOTES · #lakehouse · 3 of 6 · clear`,
   `TO DO · #lakehouse · 3 of 8 · clear`. Capture and "Add a to-do" stamp that tag; hint reads
   `Enter saves with #lakehouse`.
3. **Two or more selected = a query (union).** Labels use the word "or":
   `TO DO · #cost or #team · 3 of 8 · clear`. Nothing is stamped; the capture hint is the normal
   rest-state hint.
4. **Visibility rule:** an item created or promoted while a filter is on stays shown until the filter
   next changes, whatever its tags.
5. Empty filtered list: `No to-dos tagged #x · clear` / `No notes tagged #x · clear` in the muted label
   style.

### C. Tag entry (R2-06, R2-04)
1. **At capture and in "Add a to-do":** `#word` tokens. An exact match with an existing tag uses it.
   Otherwise Enter saves the word exactly as typed, creating the tag; the hint says `new tag #lake` first.
2. **Completion is an offer.** While the caret is in a `#word` that is a proper prefix of existing tags,
   the hint shows `#lake → lakehouse · Tab` (up to three candidates, most-used first). Tab replaces the
   word with the first candidate. No cycling. Tab is intercepted only while an offer is showing.
3. Go's `#` filter keeps automatic prefix matching (it is a search, not a write).
4. **After the fact:** `+ tag` on a note, and the Tags row on the receipt and the open to-do, use the
   same input and the same completion rule. Clicking an existing chip in an editor removes it.
5. **Capture hint layout:** at rest, unchanged. Once the draft has content the footer is two rows: the
   parse echo on its own full-width line, then `Save as to-do` and `Save note` right-aligned below. Echo
   text is built from `nowrap` segments joined by ` · `: `saves with #lakehouse` and, when an `@due`
   token is present, `as to-do: due Mon 16`. No "Enter / Ctrl+Enter" in the echo (they live in the
   rest-state hint and the buttons' tooltips).
6. Tags carry through promote unchanged (Addendum 1); works identically in notepad mode.

### D. Note footer (R2-01)
1. Two cells, `1fr auto`, aligned on the first line. Right cell: `Copy`, `To-do →`, `nowrap`, pinned
   right, never moves. Left cell: time, then tags; only this cell wraps.
2. `+ tag` and `delete` take no width at rest on desk layouts (`display: none`; shown on slip hover or
   keyboard focus, at the end of the left cell). In notepad mode they are always shown in the left cell.
3. `scrollbar-gutter: stable` on the page scroller.
4. Verification shots must include a two-tag and a three-tag older note at 1440, 1425, 1280, 1265, 821
   and 480.

### E. Section strip (R2-07)
One line, always; every item `nowrap`. Guaranteed: label, headline figure, one change figure, and the
`as of … →` link pinned right. Detail items (tickers) show only if they fit and drop whole from the
right. Write this into the section rules in the design notes so future sections inherit it.

## User-call items (work is not blocked)

1. **Optional "by due · by tag" view on the To do label** (designer's proposal: tag headings in rail
   order plus UNTAGGED, a multi-tag to-do repeated under each tag, choice remembered).
   **Default: leave it out.** Round 3 builds the flat list only. If the user wants a standing grouped
   overview, it can be added later without touching the data model (tags are already a set).

## Result

Accepted: **0 high, 3 medium** (R2-01, R2-02, R2-08 — R2-02 and R2-08 are one change) and 5 low
(R2-03 – R2-07, batched). Accepted high/medium findings: **3** — round 3 is required.
