# Round 2 review — Personal Desk ("Ledger")

Reviewer: independent, first look at this design. Judged from the round-2 screenshots (light and dark),
extra headless renders at 1280, and a live session at 1440 with a real scrollbar (typed a note with two
`#tags`, promoted it, edited due/tags on the receipt, filtered by one and two tags, cleared, checked a
to-do off, hovered notes). Settled decisions in the decision log were not re-opened.

Flows walked: Launch, Capture and Triage at 1440 / 1280 / 960 / 821 / 700 / 480; tag at capture, tag after
the fact, filter, clear, tags through promote, copy.

## Strengths — keep

1. **The NOW / NEXT pair under the date.** Two lines answer "what is my day" before the eye reaches
   anything else, in every width, and the notepad bar compresses the same answer into one line
   (`10:50 until 11:30 · next 12:00 …`). Nothing else on the page competes with it.
2. **Instant promote with an in-place receipt.** One click on "To-do →" and the to-do exists; the slip
   turns into a receipt with Due / Tags / Undo exactly where the note was, and the new row appears in the
   list marked "new". No modal, no form, and it is the same component at 480 px.
3. **Notepad mode is a real mode.** Capture slip first, one-line status bar, tags strip, panels (To do /
   Day / Go) that open under the slip instead of pushing it down. It reads as a purpose-built pad at 480
   and 700, not a stacked dashboard.
4. **One typographic system doing all the work.** Sans for content, small mono caps for labels and
   metadata, a single red-orange accent reserved for now / overdue / the primary gesture. Light and dark
   are equally convincing, and the investments route looks native with no new component.
5. **Tags as the single organising concept, with the filter stated in three places** (rail selection,
   `NOTES · #lakehouse · 3 of 6 · clear`, `TO DO · #lakehouse · 3 of 8 · clear`) and the capture hint
   changing to "Enter saves with #lakehouse". The filter state is impossible to miss and one click to clear.

## Findings

### R2-01 — "To-do →" drops to its own line on notes with two tags

- **Severity:** medium
- **Rubric criterion:** 1 Task-flow efficiency (Triage); 3 Visual hierarchy & calm
- **Observation:** A note's footer is one row: time, tags, (hover-only "+ tag" and "delete"), "Copy",
  "To-do →". As soon as the note is older than today (weekday timestamp, e.g. `Thu 16:42`) and carries two
  tags, the row overflows and "To-do →" wraps to a second line at the far left, under the timestamp, while
  "Copy" stays top right. Seen on the seed note "Prod DBU spike…" (`#cost #prod`) in the designer's own
  `w821-light.png`, in a 1280-wide render of `#state=home` and of `#state=receipt-filled`, and at 1440 in a
  real browser window (the 15 px page scrollbar narrows the note column from 370 to 365 px, which is enough
  to break it; the headless shots hide scrollbars, so `home-light.png` does not show it). A note I typed
  with `#newtag #co` wrapped the same way. The "+ tag" and "delete" controls are invisible until hover on
  desktop but still reserve their width in the row, which is what uses up the space.
- **Problem:** The primary Triage gesture changes position from note to note: bottom-right on most notes,
  bottom-left on a second line for any multi-tag note from a previous day. That is exactly the set of notes
  a user triages the next morning. The decision log settled "labels never wrap; 'To-do →' stays inside the
  slip" in round 1; adding tags to the row re-broke it, and it will get worse with three tags or a longer
  tag name. The footer also looks ragged where it happens.
- **Suggestion:** Split the footer into two fixed zones: left = time + tags (allowed to wrap onto a second
  line or truncate with "+1"), right = "Copy" and "To-do →" as a non-wrapping, right-pinned group. Take
  "+ tag" and "delete" out of the reserved flow (overlay them on hover, or make the tag chips themselves
  the entry to the tag editor and keep only "delete" on hover). Add `scrollbar-gutter: stable` so column
  widths are the same with and without a page scrollbar.
- **Rationale:** The promote control must be in the same place on every note at every width; metadata is
  the part that can afford to flex.

### R2-02 — To-do groups are decided by a hidden "first tag"

- **Severity:** medium
- **Rubric criterion:** 1 Task-flow efficiency (Triage); 5 Extensibility (few, statable rules); misleads
  the implementer
- **Observation:** The to-do list is grouped under tag headings (LAKEHOUSE, COST, UNTAGGED), but a to-do
  with several tags appears under only one of them, with the others printed as small inline `#tags`. "Tag
  untagged job clusters in Prod" (`cost`, `prod`) sits under COST with `#prod` beside it; there is no PROD
  heading at all, although the rail lists `prod 2`. In the live session I promoted a note typed with
  `#newtag #cost`, then added `lakehouse` on the receipt: the to-do stayed under a new NEWTAG heading
  showing `#cost #lakehouse`. The heading is whichever tag happened to be applied first; nothing in the
  receipt, the open to-do, or the row shows which tag is "the" group or lets the user change it. The
  receipt header (`→ TO DO · newtag`) names only that one tag.
- **Problem:** Tags were adopted as the single organising concept, but the list silently reintroduces a
  second one (a primary tag, i.e. a project) whose value depends on typing order. A user scanning for prod
  work under headings will not find a PROD group and will miss items unless they use the filter; a user who
  adds the "right" tag after the fact cannot move the to-do to that group. An implementer has no stated
  rule for which tag heads a to-do, what happens when that tag is removed, or how heading order is derived.
- **Suggestion:** Make the rule explicit and visible, one of: (a) drop tag headings and keep only DUE /
  everything-else ordered by due date, with all tags inline and the rail filter doing the grouping (see
  R2-08); or (b) keep headings but list a multi-tag to-do under every one of its tags (with DUE still
  de-duplicated on top); or (c) keep a primary tag but show it as such in the Tags row of the receipt and
  open to-do (first chip is the heading, clicking another chip with a modifier or a "file under" control
  changes it). State the chosen rule in one sentence in the design notes.
- **Rationale:** A grouping the user cannot predict or change is worse than no grouping; with tags as the
  one concept, the list should not depend on an invisible order.

### R2-03 — Two-tag filter does not say "any", and capture then stamps both tags

- **Severity:** low
- **Rubric criterion:** 6 Discoverability; misleads the implementer
- **Observation:** `filter-two-light.png` and my live session: selecting `cost` and `team` shows items
  that have either tag (`#cost #team · 3 of 8`, including a to-do that has only `team`). The header prints
  the tags side by side with no "or / any". With that filter on, the capture hint reads "Enter saves with
  #cost #team", so a new note receives both tags.
- **Problem:** `#cost #team` printed together reads as "both". And the two behaviours disagree: the list
  treats the selection as a union while capture treats it as a set to apply, so a note captured under an
  "either" filter ends up tagged with tags it may have nothing to do with.
- **Suggestion:** Print the header as `#cost or #team`. When more than one tag is selected, do not
  auto-apply any tag at capture (hint returns to "Enter saves · #tag"); keep auto-apply for the single-tag
  case, where it is clearly useful.
- **Rationale:** One selected tag is a context; several are a query, and a query should not write data.

### R2-04 — Capture hint wraps into three ragged lines once a draft has tokens

- **Severity:** low
- **Rubric criterion:** 3 Visual hierarchy & calm
- **Observation:** `draft-light.png` (1440) and a 1280 render of `#state=draft`: with `#lake @mon` in the
  draft, the mono hint "Enter saves with #lakehouse · Ctrl+Enter to-do, due Mon 16" breaks over three
  lines ("…#lakehouse / · Ctrl+Enter to-do, due Mon / 16") beside "Save as to-do" and "Save note".
- **Problem:** The hint is the feedback that the tokens were understood; broken mid-phrase with an
  orphaned "16" it is harder to read than the tokens themselves, and it makes the calmest component on the
  page look unfinished at the moment of capture.
- **Suggestion:** Show the parse result as its own line above the buttons in the same form the to-do field
  already uses (`→ #lakehouse · due Mon 16`, see `token-light.png`), and drop the key reminders while a
  draft has content (the two buttons already say what Enter and Ctrl+Enter do).
- **Rationale:** Same echo pattern in both inputs, half the text, no wrap.

### R2-05 — Secondary tag orphaned on its own line in to-do rows

- **Severity:** low
- **Rubric criterion:** 3 Visual hierarchy & calm
- **Observation:** `home-light.png` / `home-dark.png`: "Tag untagged job clusters in Prod" fits on one
  line and its `#prod` tag wraps alone onto a second line; "Review Sankar's PR…" does the same with
  `#lakehouse`. In the DUE group every row repeats a tag, so three rows each become two lines.
- **Problem:** Rows that would be single lines become two, the list gets longer, and a lone grey `#tag`
  line reads like a separate item at a glance.
- **Suggestion:** Keep tags on the title's last line (non-breaking join to the last word), or move them to
  the right-hand meta column before the due date; truncate to one tag plus "+1" when space is short.
- **Rationale:** Density of the to-do column is what keeps "what is due" above the fold.

### R2-06 — `#prefix` silently resolves to an existing tag

- **Severity:** low
- **Rubric criterion:** 7 Implementation feasibility / clarity of rule
- **Observation:** Typing `#co` in the capture slip saved the note with `#cost`; `#lake` becomes
  `#lakehouse` (`draft-light.png`). The hint does show the resolved tag before saving.
- **Problem:** A new tag whose name is a prefix of an existing one (`prod` when `production` exists, `co`,
  `team` vs `teams`) cannot be created from capture, and a fast typist who does not read the hint gets a
  tag they did not type.
- **Suggestion:** Resolve a prefix only when it is unambiguous and offer the exact text as the alternative
  in the hint (`#cost · Tab for new #co`), or require Tab to accept a completion and otherwise create the
  tag as typed.
- **Rationale:** Completion should be an offer, not a rewrite.

### R2-07 — Investments strip wraps its labels at 1280

- **Severity:** low
- **Rubric criterion:** 5 Extensibility (the strip is the proof of the system)
- **Observation:** 1280-wide render of `#state=home`, bottom strip: "today / +0.62%", "VTI +0.41 … / BND
  +0.08" and "as of / 10:45 →" each break onto two lines; at 1440 the strip is one line.
- **Problem:** The one example of "how a future section slots in" looks broken at the second most common
  width, and contradicts the settled "labels never wrap" rule.
- **Suggestion:** Give the strip a priority order: total and today's change never wrap; tickers drop from
  the right as space runs out; "as of 10:45 →" stays pinned right on one line.
- **Rationale:** A strip is a one-line summary by definition; state the truncation rule so every future
  section inherits it.

### R2-08 — Bold alternative: flat, due-ordered to-do list; tags only filter

- **Severity:** medium (alternative resolution of R2-02; may be rejected)
- **Rubric criterion:** 1 Task-flow efficiency; 3 Visual hierarchy & calm; 5 Extensibility
- **Observation:** The to-do column currently has four kinds of heading for eight items (DUE, one per
  first-tag, UNTAGGED, DONE EARLIER), each to-do lives under exactly one, tags are repeated inline in DUE,
  and the rail already offers the same tags as a one-click filter with counts. With the filter on
  (`filter-light.png`) the list shows DUE plus a single LAKEHOUSE heading that repeats the filter label.
- **Problem:** The headings duplicate what the filter does, cost vertical space (at 1280 and 960 the to-do
  list starts below the Day list and every heading pushes due items further down), and create the
  hidden-primary-tag rule described in R2-02. "See what is due" is the task; "see by tag" is one click away.
- **Suggestion:** Remove tag headings from the to-do list. Show one list ordered by due date: overdue and
  today on top under DUE, then dated items, then undated, each with its tags inline in the meta column;
  DONE EARLIER fold unchanged. The Tags list (rail / notepad strip) is the only grouping mechanism, for
  notes and to-dos alike. Dragging a note to file it targets a tag in the rail instead of a heading.
- **Rationale:** One concept (tags), one mechanism (filter), one ordering rule (due date) for both notes
  and to-dos; fewer rules for the implementer, a shorter list, and no item whose position depends on the
  order its tags were typed.
