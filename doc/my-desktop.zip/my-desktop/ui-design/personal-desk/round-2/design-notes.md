# Personal Desk — "Ledger", round 2

Standalone design note for `round-2/design.html`. Screenshots are in `round-2/shots/`
(`<state>-light.png` / `<state>-dark.png` at 1440×900 unless the name carries a width; `notepad-*` at
480×900 through an iframe).

## The idea

The page is looked at far more often than it is operated, so it is set like a printed ledger page: columns
of type separated by whitespace and hairlines, nothing boxed, nothing that moves unless asked.

Two rules carry the design:

1. **The page is print; only notes are objects.** A note is the only thing with a surface (a flat tinted
   slip, no border, no shadow). Shortcuts, events, to-dos and every future section are type on paper.
2. **Accent means "this needs you now", and nothing else.** One colour, one meaning.

A third rule emerged in round 2: **one list grammar.** Day, To do, Earlier and section tables are all rows
of *mono key · text · grey mono word*, with a left rule where state matters.

## Layout and width ranges

Zones: **Go** (shortcuts, then the tag index) · **Today** (headline, Now/Next, Day, To do) · **Notes** (capture slip, then
slips). A masthead above (wordmark, text nav, Notepad toggle, Theme toggle). Section strips sit at the
foot of the Go + Today zones.

| Viewport width | Layout | What has given way |
|---|---|---|
| ≥ 1360 | Go (160) · Today · Notes. Inside Today, Day and To do side by side, starting on the same line. | Nothing. |
| 1200–1359 | Go · Today · Notes. Inside Today, Day stacked above To do. | Day / To do side by side. |
| 821–1199 | Two columns: Today · Notes. Go becomes the Go field plus one wrapping line of text links above Today; a collapsed group shows its last-used environment, an open group lists its environments inline. | The rail as a column. |
| ≤ 820 | Notepad mode, content capped at a 608 px measure. | Everything except capture and notes (panels on demand). |

**Order of giving way:** Day/To do side-by-side first, then the rail, then everything but capture and
notes.

Floors: rail 160, Day 280, To do 280, Notes 340. Notes is one column at every width. Page margin 44 px
(28 px in the two-column range), column gap 48 px (40 px).

Fixed at every width: section labels never wrap (key hints are dropped first); "To-do →" is always inside
its slip (the footer may wrap); the date headline stays on one line.

Forced notepad ("Notepad" in the masthead, `mode=notepad`) is available at any width and shows
"Full view" in its bar.

Why 820: halves of 1366, 1536 and 1600 px displays (683, 768, 800) are the common split-screen windows
and should get the layout built for sitting beside another window; 820 keeps the boundary off 800.

## Visual tokens

One token set; the dark theme re-declares the same names. Theme follows the OS; a toggle cycles
auto → light → dark and is stored; `#theme=` overrides.

| Token | Light | Dark | Use |
|---|---|---|---|
| `--paper` | `#FAFAF6` | `#121211` | page |
| `--ink` | `#171715` | `#ECEBE4` | primary text, event rules, checked boxes, last-used dot |
| `--ink2` | `#5B5B54` | `#A6A59C` | secondary text, times, response words |
| `--ink3` | `#8A897F` | `#737269` | labels, hints, aliases, gap rows, elapsed and declined events |
| `--line` | `#E3E2D9` | `#2A2A27` | hairlines |
| `--line2` | `#CCCBC0` | `#3D3D38` | stronger hairline, image edge, field and control underlines |
| `--slip` | `#F0EFE5` | `#1E1E1B` | note surface, the only surface |
| `--slip-in` | `#E6E5DA` | `#292925` | reserved, unused |
| `--accent` | `#C5411C` | `#FF6A3D` | "needs you now" |

Where accent appears: NOW label and clock, the running event's rule or the now tick, the Due heading,
late dates and the "n due" count, the capture slip edge, the keyboard selection hairline, a focused
field's underline, the top edge of a promote receipt, the arrow in "To-do →", a drop target's underline,
the chosen word in a picker. Links are never accent. Investments shows direction with + and −.

Type: **Instrument Sans** 400/500/600 for everything read; **IBM Plex Mono** 400/500 for times, dates,
figures, labels, aliases, hints. Fallbacks `system-ui, Segoe UI` and `ui-monospace, Cascadia Mono,
Consolas`. Scale: 11 mono label/hint · 13.5 agenda · 14 notes and rail children · 14.5–15 to-dos and
links · 17 Now/Next · 30 headline. Screenshots in dark theme are dimmed to 86 % brightness.

Spacing: 4 px base; 48 between columns, 26–30 between blocks, 15 between to-do groups, 10 between slips.
Radius: 0 on slips, 3 px on checkboxes. No shadows. Metadata is always words in mono grey; no icons.

## Key interactions

### Launch: Go
- Shortcuts are plain text links, one click each. A group is a row with a count (`3 +`); clicking it
  expands inline and the open state persists.
- **Last-used environment:** an ink dot marks it inside an open group; a collapsed group prints it beside
  the name ("Azure • Portal") as a direct link.
- **Go field:** `/` focuses it from anywhere, a selected row included. Type a name, part of one, or an
  alias; Enter opens the first hit, marked "Enter". `ol` → Outlook. `db` → Databricks, last-used first.
  `db p` → Databricks Prod. `prod` → Databricks Prod. `inv` → Investments section.
- Aliases are hidden at rest and print in mono grey only while Go has focus.
- Rejected: hover fly-outs, a favicon grid, group click opening a default environment, always-visible
  aliases, an always-focused omnibar that would merge launch and capture.

### Launch: shortcut editing
"Edit" under the rail (also in Settings) makes the rail editable in place: `::` handle to drag within a
level, click a name for Name / URL / Alias fields (group: Name, Alias; environment: Name, URL, Key) plus
Up, Down, Remove; "+ link" inside groups, "+ Add link", "+ Add group", "Done". Remove is undoable. In the
two-column range the edit list drops under the Go line in two columns (`w960-edit-shortcuts-light.png`).
Rejected: a modal manager or settings table; the rail is edited where it stands.

### Launch: the day
- **Now / Next** sentences, the largest text after the date: "Now *subject* until 11:30 · 40 min left
  · +1 overlapping", "Next 12:00 *subject* in 1 h 10 min · tentative". Declined never counts. No running
  event reads "Free until 12:00". These never truncate.
- **Day is one agenda list, the same component at every width and in the notepad Day panel.**
  - One row per event: mono time range in a fixed 86 px column, subject, then the response word in grey
    mono (tentative / no reply / declined only).
  - Left rule carries the response: solid accepted or organizer, dashed tentative, dotted no reply, none
    plus struck grey text for declined. The running event's rule is accent and its subject is bold.
  - Chronological by start. Declined events stay in their place and are ignored for overlaps and gaps.
  - **Overlap:** an event that starts before the previous non-declined event ends is indented one step
    (14 px) with its own rule. No extra word; the Now sentence keeps "+1 overlapping".
  - **Gaps:** between non-declined events 30 minutes or more apart, one quiet row, mono grey, no rule:
    `free 1 h 15 min`. Upcoming gaps only. The 08:50 view has three gap rows; I judged that readable and
    kept the 30-minute threshold (`morning-0850-*.png`).
  - **Earlier:** elapsed events fold into "EARLIER · n +", collapsed by default, expanding in place with
    dimmed rows, in both modes.
  - **Now:** a running event has the accent rule. In a gap, a short accent tick sits at the top of the
    list, followed by the gap row counted from now (`gap-1310-*.png`). Neither carries a time; the time is
    printed once, beside the date.
  - Long subjects wrap; the tooltip has the full text.
- Empty day: "Nothing scheduled today" and "No events. The day is yours." After the last event:
  "Nothing else today." (`evening-1730-*.png`).
- Times are local, 24-hour. Demo events are authored as UTC strings in both real formats
  (`…T21:30:00.0000000Z`, `…+00:00`) and pass through one parser that trims the 7-digit fraction.
- Rejected, after round 1 evidence: the proportional timeline. It truncated overlaps and long subjects in
  a ~300 px column, changed scale with the time of day and needed twice the height.

### Capture
- The capture slip is the first object in Notes, always present. **Enter saves, Shift+Enter adds a line,
  Ctrl+Enter saves as a to-do.** "Save note" / "Save as to-do" appear as words once there is content.
  Focus stays in the field after saving.
- **A saved note appears directly under the capture slip.** Notes are one column, strictly newest first,
  at every width; keyboard order equals visual order; nothing is balanced or reassigned.
- **Type anywhere, on every route:** with no field focused and no row selected, a printable key starts a
  note. **Ctrl+V with an image, on every route**, adds it to the draft as a removable thumbnail. On
  Investments or Settings the text lands in a one-line field in the masthead and the masthead prints
  "Saved to notes · Undo"; in notepad mode the capture slip stays under the bar on every route.
- One draft, persisted across reload, route and mode.
- **`#tag` typed in a note becomes a tag** and leaves the text; `#lake` completes to an existing
  `lakehouse`, an unknown word creates the tag. The hint line shows what Enter will do
  ("Enter saves with #lakehouse"). `@due` is read only when the note is saved as a to-do.
- Slip: text, then screenshots at full slip width. In the desk layouts a screenshot is capped at 140 px
  high, cropped from the top-left, with a hairline edge; click opens it full size. Notepad mode shows it
  uncapped. It is one slip component with one property changed.
- Footer, left: time, the note's tags as mono grey `#words`, "+ tag", "delete" (the last two on hover in
  the desk, always in notepad mode; delete is undoable). Right: **"Copy"** then "To-do →". The footer
  wraps as a unit when a note has many tags, so the two actions stay together and inside the slip.
- **Copy** puts the note's text only, never the image, on the clipboard. It is a grey word, lighter than
  "To-do →" (regular weight, secondary ink, no arrow), so the primary gesture still reads first. After a
  click the word reads "Copied" in primary ink and stays that way until the next click or key press
  anywhere: a quiet confirmation with no toast and no timer. Image-only notes have no Copy. `c` copies
  the selected note.
- Notes are edited in place by clicking the text.

### Triage: promote
- Every slip prints **"To-do →"**. One click, or `t` on a selected slip, creates the to-do at once.
- The slip becomes a **receipt** in the same position: "→ TO DO · where it went", the editable title,
  "note + image attached", Due as words, Tags as words, Undo, Close. Ignoring it is a valid finish. It
  has no timer; it stays until the next wall action, Close, or leaving the page.
- The note leaves the notes column and travels with the to-do. The to-do row says "note + image" in mono
  grey; opening the row shows the original slip and screenshot; "Return to notes" puts it back at its
  original place in the order.
- Title = first sentence of the note, tokens removed.
- **The note's tags carry over to the to-do.**
- Drag the words "To-do →" onto a tag heading to add that tag, or onto "Due" for today. Feedback is
  an accent underline on the heading only. Not offered in notepad mode.

### Triage: to-dos
- **Due** group first (late + today), then one group per tag (a to-do is listed under its first tag), then
  "Untagged". Tags other than the group's own print after the title as mono grey `#words`; a group
  heading and every `#word` is a one-click filter. Dates right-aligned in mono: "1 d late" accent, "today" bold, later dates grey.
- "Add a to-do" accepts **`#tag @due`** (several tags allowed) with a mono preview under the line before
  Enter.
- Checking strikes the row in place for the session; on next load it folds into "DONE EARLIER · n".
- Clicking a title opens the row inline: editable title, word pickers, the source note, Return to notes,
  Delete (undoable).

### Keyboard
- **Selection is entered by keyboard only**: `↓` with nothing focused (first to-do; first note in notepad
  mode), `↓` in an empty capture or add field, or Tab. A mouse press on a row never selects it, so after
  any click, typing still starts a note.
- **While a row is selected, keys are verbs only**; other letters do nothing. `j`/`k` or arrows move,
  `←`/`→` switch between to-dos and notes, `u` undoes, `/` goes to Go, **Esc leaves selection and typing
  starts a note again**. To-do: `x` or Space done, Enter opens, Del deletes. Note: `t` makes it a to-do,
  `c` copies its text, `#` opens its tags, Enter edits, Del deletes. `#` on a to-do opens it at its tags.
- With nothing focused, **Esc clears an active tag filter**.
- The selection is a 2 px accent hairline at the row's left. Key hints, ending in "esc to type", print at
  the right of the column label only while that column holds the selection, and are the first thing
  dropped when the label is short of room. Full list in Settings › Keyboard.
- Undo is one level: promote, return, deletes, shortcut removal. Offered as `u`, on the receipt, and as a
  mono line under the capture slip that stays until the next change.

### Notepad mode (≤ 820 px, or forced)
- Order, always: one-line sticky bar → capture slip → one optional panel → notes stream.
- Bar: clock; "until 11:30 · next 12:00 *subject*" (times fixed, only the subject truncates);
  "To do · 3 due" with "3 due" in accent, or "To do · 8" when nothing is due; "Go"; and "Full view" only
  when the mode was forced. The three toggles are underlined like every other text control. I left out
  `+` / `–` markers: the bar is already full at 480 px.
- **Tag line:** directly under the capture slip, one line of the tags with counts; tap to filter, "clear"
  at its end when a filter is on. Each slip shows its tags and "+ tag" in the footer.
- Capture is auto-focused on entering the mode and never moves; panels (the same Day agenda, To do, Go +
  routes + theme) open below it.
- Promote, receipt, Undo, tokens and keyboard selection work the same. Routes open under the capture slip
  with a "← Notes" link.

### Tags and the filter (Addendum 1)

**Decision: tags replace projects.** A to-do's "project" is now simply its first tag; notes carry the same
tags; there is one vocabulary for both.
- Why: a project was already just a word attached to a to-do. Notes need the same word (a meeting note
  about the migration belongs with the migration to-dos), and promote must carry it across. Two concepts
  would mean two pickers on every receipt, two filters, and a rule for how they combine, for no extra
  ability: "show me the lakehouse work" is one filter either way.
- Rejected, tags alongside projects: keeps strict one-project grouping, but doubles the chrome on slips
  and receipts and leaves notes with tags while to-dos have both. Rejected, flat to-do list with tags only
  as words: loses the grouped scan the brief asked for; listing under the first tag keeps it.
- Cost accepted: a to-do with two tags is listed once, under the first; the second is a `#word` on the row.

**How tags look.** Words only. On items: mono grey `#lakehouse`. In the index and as group headings: the
bare word. A selected tag is primary ink, semibold, underlined in ink. No pills, no colours; accent keeps
its single meaning.

**Applying tags.**
- At capture: type `#tag` in the note or in "Add a to-do". Prefix completion, new tags created on the fly.
- While a filter is on, everything captured gets the filter's tags, and the hint says so. Otherwise a
  note saved under a filter would vanish the moment it was saved. It also makes "filter to a project,
  then take meeting notes" tag the whole session for free.
- After the fact, on a note: "+ tag" in the footer (or `#` on the selected slip) opens the tag words inside
  the slip; click to toggle, "+ new" to add, Done to close (`tagging-*.png`).
- After the fact, on a to-do: open the row; Tags sits under Due as the same toggle words. The promote
  receipt has it too.
- Drag "To-do →" onto a tag heading to promote and tag in one gesture.

**Where the filter lives.**

| Layout | Filter control |
|---|---|
| ≥ 1200 | "TAGS" block in the rail under the shortcuts: one word per row with a count (notes + open to-dos). |
| 821–1199 | A second line under the shortcut links: TAGS word count word count …. |
| ≤ 820 notepad | One line directly under the capture slip. |
| Everywhere | Click any `#word` on a slip or to-do row, or a to-do group heading. Keyboard: `/` then `#co` + Enter. |

**Filtered state** (`filter-*.png`, `notepad-filter-*.png`, `w960-filter-light.png`).
- Both column labels say so: `TO DO · #lakehouse · 3 of 8 · clear` and `NOTES · #lakehouse · 3 of 6 ·
  clear`. The "n of m" is the reminder that things are hidden.
- Non-matching notes and to-dos are hidden; groups with nothing left disappear. Day, Go and strips are
  untouched. A promote receipt always stays visible.
- Several tags can be selected; an item shows if it has **any** of them. Rejected "all of them": most
  items carry one tag, so an AND of two tags would nearly always be empty.
- Empty result: "No notes tagged #x." / "No open to-dos tagged #x."
- **Clearing:** "clear" in either label or beside TAGS, click the selected tag again, or Esc with nothing
  focused. The filter is session state and is not persisted, so the page never opens filtered.
- In notepad mode the To do panel is filtered too; the bar's due count stays global.

**State model implications (for the app specification).**
- `note.tags: string[]` and `todo.tags: string[]` replace `todo.project`. Order matters on a to-do (first
  tag = group). A migration maps an old project to one tag.
- `tags: string[]` is the ordered vocabulary (creation order drives group and index order). Tags are
  lower-case tokens matching `[a-z0-9_-]+`. Tags with no notes and no open to-dos are hidden from the
  index but still offered in pickers. Renaming and deleting tags is not designed in this round.
- Note text no longer contains its `#tags`; they are extracted on save.
- `filter: string[]` is view state, not stored.
- Promote copies the note's tags to the to-do; returning a to-do to notes restores the note with the tags
  it had when promoted.
- Copy reads `note.text` only.

### Empty states
One quiet sentence each: no events, no to-dos ("Nothing to do. Add one above, or send a note here with
To-do →."), no notes ("No notes. Type anywhere, or paste a screenshot."), no shortcuts.

## Rules for adding a section

1. A section is **a route** with one word in the masthead nav **and an alias in Go** (`inv` + Enter).
2. It may place **one strip** on home: one line under the Go and Today zones, label in the rail's column,
   about five figures, the whole line links to the route.
3. Inside its route it uses the list grammar only: 30 px headline, mono caps labels, hairline-ruled rows,
   mono figures. **No surfaces**, no shadows, no new colours.
4. Accent means "needs you now". Direction of a number is a sign, not a colour.
5. Capture is global: typing or pasting on the route goes to the notes draft. A section never adds its own
   input to home; to feed to-dos it promotes notes.
6. In notepad mode it opens under the capture slip, is listed in the Go panel, and its strip is hidden.

## Demo states (URL hash)

Combine with `&`. Any `state=` boots from fresh sample data and never writes storage. Without `state=`
the page persists notes, to-dos, tags, shortcuts, draft, open groups, last-used and theme.

| Hash | Shows |
|---|---|
| `state=home` | default desk, 10:50, an event running |
| `state=home&now=08:50` | full morning: tick, all eight events, long subject, overlap indent, three gaps |
| `state=home&now=13:10` | in a gap: tick + "free 50 min" |
| `state=home&now=17:30` | after the last event |
| `state=earlier` | Earlier fold expanded |
| `state=group-open` · `go-focus` · `go` · `go-section` | groups open · aliases visible · `db p` · `inv` |
| `state=edit-shortcuts` | rail in edit mode |
| `state=draft` | capture with text, tokens and a pasted screenshot |
| `state=receipt` (alias `promote`) · `receipt-filled` | a note just promoted, receipt |
| `state=promoted` · `todo-open` | a to-do open with its source note and screenshot |
| `state=cursor-todo` · `cursor-note` | keyboard selection, key hints in the label |
| `state=token` | "Add a to-do" with `#cost @fri` and its preview |
| `state=filter` · `filter-two` | tag filter active: `#lakehouse` · `#cost` or `#team` |
| `state=tagging` | tag words open on a note, after the fact |
| `state=copied` | a note just copied: "Copied" in its footer |
| `state=drag` | a tag heading as drop target |
| `state=note-deleted` · `done` | Undo line · two to-dos checked in place |
| `state=empty-day` · `no-notes` · `no-todos` · `empty-all` | empty states |
| `state=route-capture` | Investments with a note typed in the masthead |
| `route=investments` · `route=settings` | secondary routes |
| `theme=dark` · `theme=light` | force theme |
| `mode=notepad` | force notepad mode at any width (shows "Full view") |
| `panel=day` · `panel=todos` · `panel=go` | notepad mode with that panel open |
| `now=HH:MM` | move the pinned clock (default 10:50, Fri 13 Nov 2026) |
| `reset=1` | discard stored data and reseed |

Width renders in `shots/`: `w1920`, `w1366x768`, `w1360`, `w1280x720` (default and 08:50), `w1200`,
`w960` (default, 08:50, edit), `w821`, `w820-notepad`, `w700-notepad`, `forced-notepad-1440`.

## Changes from previous round (round 1 → round 2)

| Finding | Verdict | What changed |
|---|---|---|
| R1-01 overlap truncation | accept, via R1-08 | No truncation path left: every event is a full-width row; the overlapping one is indented. |
| R1-02 half-screen widths | accept merged | Notepad breakpoint 640 → 820. 821–1199 is a designed two-column layout with the rail as a line of links; Due is on screen at 960×900. |
| R1-03 notes order | accept merged | One column, newest first, at every width; no column assignment. Screenshots full width capped at 140 px (reviewer's form, not my side thumbnail). Receipt and returned notes keep their place. |
| R1-04 breaks at 1280 | accept merged | Ranges and floors as specified; Day stacks above To do from 1200 to 1359; labels cannot wrap; slip footer wraps before "To-do →" can leave the slip; headline is one line. |
| R1-05 row verbs and `/` | accept merged | `/` works from a selected row. Mouse never enters selection. Inside selection, non-verb letters do nothing; Esc returns to typing; hint adds "esc to type". |
| R1-06 "now" repeated, declined after 17 | accept | Declined sits in chronological place. Time printed once; the now marker has no label. Running row stays bold (see open question). |
| R1-07 notepad bar | accept merged | "To do · 3 due", underlined toggles, subject-only truncation, "Full view" when forced. No `+`/`–` (does not fit at 480). |
| R1-08 agenda as the one calendar | accept merged | Proportional timeline, hour grid, adaptive scale, overlap columns, now-line and declined footnote removed. One agenda component with indent for overlap, gap rows, Earlier fold, tick for "now in a gap". |

| Addendum 1, tags (req. 10) | user requirement | Tags replace projects on to-dos and are added to notes; `#tag` at capture, "+ tag" and pickers after the fact; tags carry on promote; tag index in the rail / a line in mid and notepad layouts; filtered state named in both column labels with "n of m" and clear; Go accepts `#tag`; Esc clears. |
| Addendum 1, copy (req. 11) | user requirement | "Copy" word left of "To-do →" in every slip footer; text only; "Copied" until the next click or key; `c` on a selected note. |
| Running event row | settled by the user | Stays bold. No longer an open question. |

Kept from the review's strengths: zero-ceremony capture on every route, one-gesture promote with in-place
receipt, the Go rail (aliases on focus, last-used link, sections as targets), notepad mode with panels
below capture, the visual language and the native-looking Investments strip and route.

### Two places where I departed from the verdict's letter, for the judge to confirm
1. **Subject clamp is three lines, not two.** The specification says two lines then ellipsis; the
   acceptance conditions say the long subject must be readable in full at every width. In every
   render I took the 77-character demo subject fits in two lines, but at 1360 (`w1360-light.png`, 08:50)
   it fills the second line exactly, so a fallback font or a slightly longer subject would be cut. I set
   the clamp to three lines as a margin so the acceptance condition cannot fail; no row in the shots
   actually uses a third line.
2. **The section strip moved from the page foot to the foot of the Go + Today zones.** Not in the
   verdict. With Notes now one long column, a page-foot strip would sit below every note and never be
   seen. Nothing was added; the same line sits under the left two zones (in the two-column range, under
   Today). At 1440×900 it is below the fold when To do is long, as before round 1.

## Known stubs and mockup notes

- Shortcut links open in a new tab here; the real start page should navigate in place.
- The clock is pinned; the real app re-renders Now/Next, the fold, gaps and the tick each minute.
- Pasted images are downscaled to 1100 px JPEG in `localStorage`; the real app should store blobs on disk
  or in IndexedDB.
- Settings: theme, shortcut editing and reset are live; calendar source, clock format and the Enter
  preference are described only. Investments data is static.
- Undo is a single snapshot, not a history.
- Dragging "To-do →" uses native HTML drag and drop; the drag state in the shots is simulated.
- The 480 px shots go through a 480 px iframe because headless Edge will not lay out a window narrower
  than about 500 px.
- Clipboard writes need a secure context or user gesture; the mockup falls back to `execCommand('copy')`
  when `navigator.clipboard` is refused (as it may be on `file://`).
- Not exercised by hand this round: native drag and drop, the date picker popup, real clipboard paste and copy, and
  the mouse-does-not-select rule (implemented with `mousedown` + `preventDefault`).
