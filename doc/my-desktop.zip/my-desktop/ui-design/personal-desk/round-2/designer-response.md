# Round 2 — designer response to blind findings

Written from `findings-blind.md` only (I have not opened `review.md`). I looked at the reviewer's renders
`w1280tall.png` and `w1280draft.png` and checked each claim against the round-2 code and my own shots. No
file other than this one was changed.

| Finding | Position | Short answer |
|---|---|---|
| R2-01 "To-do →" wraps on two-tag notes | agree | Real, and my own doing: hidden controls still reserve width. |
| R2-02 hidden "first tag" grouping | agree | A second organising concept came back through the side door. |
| R2-03 two-tag filter | agree on the label, partial on capture | "any" must be said; stamping all selected tags is wrong for a union. |
| R2-04 capture hint wraps | agree | Visible in `w1280draft.png` and my `draft-light.png`. |
| R2-05 orphaned tag line | agree | Visible in my `home-light.png`. |
| R2-06 `#prefix` auto-resolves | partial | Completion is useful; doing it silently is not. |
| R2-07 strip wraps at 1280 | agree | Visible in `w1280tall.png`. |
| R2-08 flat due-ordered list | agree, with one addition for the user to decide | It removes the hidden rule; an explicit "by tag" view keeps grouping available. |

---

## R2-01 — "To-do →" drops to its own line on notes with two tags

**Why it was designed this way.** Addendum 1 arrived mid-round and I put tags, "+ tag" and Copy into the
existing one-row footer. To satisfy the round-1 rule that "To-do →" never leaves the slip, I let the footer
wrap. "+ tag" and "delete" are hidden with `opacity: 0` so the row does not shift on hover.

**Is the problem real: agree.** `w1280tall.png` shows it on "Prod DBU spike…": Copy stays top right and
"To-do →" lands bottom left. The cause is exactly as described: the two invisible controls keep about 90 px
of width. I satisfied the letter of the round-1 rule (inside the slip) and broke its point (the primary
gesture is always in the same place). The scrollbar observation is also fair: my headless shots hide
scrollbars, so at 1440 I was 5 px away from the same failure without seeing it.

**Proposed fix.**
- Footer becomes two cells, `1fr auto`, aligned on the first line. Right cell: `Copy` and `To-do →`,
  `white-space: nowrap`, never wraps, always bottom-right of the slip. Left cell: time, then tags; only this
  cell wraps.
- "+ tag" and "delete" take no width at rest in the desk layouts (`display: none`, shown on slip hover or
  focus). When they appear they flow at the end of the left cell and may wrap there; the right cell does not
  move. In notepad mode they are always shown, in the left cell.
- Long tag runs: the left cell shows tags on as many lines as it needs; the actions stay on line one.
- Add a real-scrollbar check to my process: take the desk shots at 1425 and 1265 wide as well.

---

## R2-02 — To-do groups are decided by a hidden "first tag"

**Why it was designed this way.** The original brief asked for to-dos grouped under a project, and the
addendum asked for one organising concept. I kept the grouped look by listing each to-do under its first
tag, and wrote that down as "cost accepted".

**Is the problem real: agree.** I underrated it. The reviewer's live case is decisive: a note typed with
`#newtag #cost`, then given `lakehouse`, sits under NEWTAG forever, and nothing on screen says why or lets
the user change it. "First tag" is a project by another name, set by typing order. There is no PROD
heading although the rail says `prod 2`, so the headings and the rail disagree about what exists. I also
left the implementer without rules for removal of the heading tag or heading order.

**Proposed fix.** Remove the hidden rule rather than document it: adopt R2-08. If grouping were kept
instead, the minimum honest version would be a to-do repeated under *every* tag it has (see R2-08, the
optional "by tag" view), never a single privileged one.

---

## R2-03 — Two-tag filter does not say "any", and capture stamps both tags

**Why it was designed this way.** I chose union because most items carry one tag, so an intersection of
two tags is nearly always empty. I stamped the filter's tags on new captures so a note saved under a
filter would not vanish on save.

**Is the problem real: agree on the label, partial on capture.**
- Label: `#cost #team` does read as "both". Agree.
- Capture: the vanish problem I was solving is real, and with one selected tag the stamping is right and
  useful (filter to a project, take meeting notes). With two or more it is wrong: the list means "either",
  capture means "both", and the note gets a tag it may have nothing to do with.

**Proposed fix.**
- Labels print the union in words: `TO DO · #cost or #team · 3 of 8 · clear`.
- Capture stamps a tag **only when exactly one tag is selected**; the hint then reads "Enter saves with
  #cost" as now.
- With two or more selected, nothing is stamped and the hint says so: "Enter saves · no tag added".
- To keep the save visible in that case: anything created in the current view stays shown until the filter
  next changes, whatever its tags. One rule, also covering a note typed with a different `#tag` under a
  single-tag filter.

---

## R2-04 — Capture hint wraps into three ragged lines

**Why it was designed this way.** The hint shares one row with "Save as to-do" and "Save note". At rest the
hint is short; I extended its text for tokens without giving it more room.

**Is the problem real: agree.** `w1280draft.png` shows "Enter saves with / #lakehouse · Ctrl+Enter /
to-do, due Mon 16" in a ~150 px column beside the two actions. That is the moment the user checks whether
the tokens were understood.

**Proposed fix.**
- Once the draft has content, the footer is two rows: the hint on its own full-width line, the two actions
  right-aligned on the line below.
- Shorter text built from parts that are each `nowrap`, so a break can only fall at a separator:
  `saves with #lakehouse` · `as to-do: due Mon 16`. "Enter" and "Ctrl+Enter" move into the action words'
  tooltips and the rest-state hint, where they already are.

---

## R2-05 — Secondary tag orphaned on its own line in to-do rows

**Why it was designed this way.** Tags are inline after the title, each `nowrap`, so they wrap like words.
When the title exactly fills the line, the tag is the word that wraps.

**Is the problem real: agree.** In my own `home-light.png` "Tag untagged job clusters in Prod" is followed
by a lone `#prod` line, and three DUE rows are two lines because of a repeated tag.

**Proposed fix.** Bind the tags to the last word of the title: the last word and the tag run sit in one
`nowrap` span, so a tag can never be alone on a line; at worst the last word moves down with it. With
R2-08 every row shows its tags once, in this same position, so there is one rule for all rows.

---

## R2-06 — `#prefix` silently resolves to an existing tag

**Why it was designed this way.** Speed: `#lake` is quicker than `#lakehouse` in a meeting, and it
prevents near-duplicate tags from typos. The hint shows the resolved tag before saving.

**Is the problem real: partial.** Completion is worth keeping. But the reviewer is right on both counts: a
tag that is a prefix of an existing one cannot be created from capture at all, and the resolution is only
visible to someone reading the hint. A capture surface should save what was typed.

**Proposed fix.** Make completion explicit and optional.
- An exact match always wins.
- While the caret is in a `#word` that is a proper prefix of exactly one existing tag, the hint shows
  `#lake → lakehouse · Tab`. Tab replaces the word in the text. With several candidates the hint lists
  them and Tab cycles.
- Without Tab, Enter saves exactly the word typed; if it is new the hint says `new tag #lake` beforehand.
- Same rule in "Add a to-do" and in Go's `#` filter (where prefix match stays automatic, because that is a
  search, not a write).

---

## R2-07 — Investments strip wraps its labels at 1280

**Why it was designed this way.** The strip was laid out at 1440 as one flex row with no wrap rules, then
moved in round 2 from the page foot to the narrower Go + Today span.

**Is the problem real: agree.** `w1280tall.png` shows "today / +0.62%", the tickers on two lines and
"as of / 10:45 →". It breaks the settled no-wrap rule on the one example meant to prove the section system.

**Proposed fix.** Give the strip a rule, and write it into the section rules:
- every item is `nowrap`; the strip is one line, always;
- order of giving way: the detail list (tickers) is clipped from the right with no ellipsis first, then
  dropped entirely; label, headline figure, change and the "as of … →" link always remain;
- rule 2 for sections becomes: "one line; label, one headline figure, one change figure are guaranteed;
  further figures show only if they fit".

---

## R2-08 — Bold alternative: flat, due-ordered to-do list; tags only filter

**Why grouping was kept.** Requirement 3 originally said to-dos can be grouped under a project, the
addendum said tags may replace that grouping, and I read "replace" as "the groups become tag groups".

**Assessment.**

| | Gained with a flat list | Lost |
|---|---|---|
| 1 Task-flow (25) | "See what is due" becomes the list's only order; no hunting across headings; a multi-tag to-do is simply one row with its tags. | Scanning "everything for lakehouse" needs one click (the filter) instead of zero. |
| 3 Hierarchy & calm (15) | Two headings instead of five for eight items; at 1280 and 960, where To do sits under Day, more due items above the fold. | The list loses some internal rhythm; undated items form a long tail. |
| 5 Extensibility (15) | The rule is statable in one line: ordered by due date, filtered by tag. R2-02 disappears; the implementer needs no heading logic. | — |
| 6 Discoverability (5) | Rail counts and row tags agree; nothing is hidden. | — |
| Requirement "tags organise to-dos" | Tags still organise: every row shows them, any tag is a one-click view, counts are in the rail, capture under a filter files into it. | A standing grouped overview by tag is no longer the default. If the user's mental picture is "my to-dos, by project", the default view no longer draws it. |

**My view: adopt the flat list as the default, and keep grouping as an explicit view, not a hidden rule.**

1. **Default: by due.** Headings: `DUE` (late and today, accent as now), then `LATER` (dated ascending,
   then undated), then the `DONE EARLIER` fold. Each row: checkbox, title with its tags bound to the last
   word (R2-05), due date right-aligned.
2. **Filter** as now, with the labels from R2-03. Under a single-tag filter the list *is* that tag's group.
3. **Optional view word in the To do label: `by due · by tag`.** "By tag" groups under tag headings in the
   rail's order, plus `UNTAGGED`, and **a to-do with two tags appears under both**. That is the only
   grouping that has no privileged tag; the repeated row is the same item (checking one checks both). The
   choice is remembered. This is the part I would put to the user: it costs two words of chrome and a
   second render path, and it exists only because the requirement speaks of grouping. If the user is
   content with "tags filter", it should be left out.
4. **Consequences elsewhere.**
   - Receipt header reads `→ TO DO · #newtag #cost` (all tags), not one heading name.
   - Dragging "To-do →" to file a note: the drop targets become the tag words in the rail (always present,
     including tags with no open to-do), plus the `DUE` heading. This also fixes a limit I had accepted
     before (only headings on screen were targets).
   - Tag order on a to-do stops meaning anything; `todo.tags` becomes a set in the state model.

Risk I see in the flat default: with twenty or thirty to-dos, `LATER` becomes one long run. The filter and
the optional "by tag" view are the answer to that; a third heading (`NO DATE`) could be added if the tail
proves hard to read, but I would not add it speculatively.
